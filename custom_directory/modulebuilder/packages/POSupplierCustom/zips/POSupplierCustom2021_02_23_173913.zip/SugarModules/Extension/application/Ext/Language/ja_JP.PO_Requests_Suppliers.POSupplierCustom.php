<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'アナリスト',
  'Competitor' => '競合他社',
  'Customer' => '顧客',
  'Integrator' => 'インテグレーター',
  'Investor' => '投資家',
  'Partner' => 'パートナー',
  'Press' => 'プレス',
  'Prospect' => '見込み顧客',
  'Reseller' => 'リセラー',
  'Other' => 'その他',
  '' => '',
);