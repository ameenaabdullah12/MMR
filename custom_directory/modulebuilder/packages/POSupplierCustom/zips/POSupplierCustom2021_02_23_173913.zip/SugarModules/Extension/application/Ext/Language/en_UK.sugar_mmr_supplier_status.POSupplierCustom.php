<?php 
$app_list_strings['mmr_supplier_status'] = array (
  '' => '',
  'Web' => 'Web',
  'Draft' => 'Draft',
  'Awaiting Approval' => 'Awaiting Approval',
  'Approved' => 'Approved',
  'DO NOT USE' => 'DO NOT USE',
);