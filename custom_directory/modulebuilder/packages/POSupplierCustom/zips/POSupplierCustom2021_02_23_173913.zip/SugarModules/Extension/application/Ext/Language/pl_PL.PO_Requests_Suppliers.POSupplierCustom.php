<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analityk',
  'Competitor' => 'Konkurencja',
  'Customer' => 'Klient',
  'Integrator' => 'Integrator',
  'Investor' => 'Inwestor',
  'Partner' => 'Partner',
  'Press' => 'Prasa',
  'Prospect' => 'Potencjalny klient',
  'Reseller' => 'Sprzedawca',
  'Other' => 'Inne',
  '' => '',
);