<?php 
$app_list_strings['mmr_method_of_payment'] = array (
  '' => '',
  'WIRE TRANSFER' => 'Wire Transfer',
  'Cheque' => 'Cheque',
  'DDR' => 'DDR',
  'BACS' => 'BACS',
);