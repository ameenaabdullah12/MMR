<?php 
$app_list_strings['currency_dropdown'] = array (
  '' => '',
  'GBP' => 'GBP',
  'USD' => 'USD',
  'PRC' => 'PRC',
  'EUR' => 'EUR',
  'ZAR' => 'ZAR',
  'INR' => 'INR',
  'SGD' => 'SGD',
  'JPY' => 'JPY',
);$app_list_strings['default_dim_db_c_list'] = array (
  '' => '',
  'UK' => 'EMEA',
  'US' => 'AMER',
  'CHINA' => 'APAC',
);