<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analyst',
  'Competitor' => 'Competitor',
  'Customer' => 'Customer',
  'Integrator' => 'Integrator',
  'Investor' => 'Investor',
  'Partner' => 'Partner',
  'Press' => 'Press',
  'Prospect' => 'Prospect',
  'Reseller' => 'Reseller',
  '' => '',
  'Other' => 'Other',
);