<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Αναλυτής',
  'Competitor' => 'Ανταγωνιστής',
  'Customer' => 'Πελάτης',
  'Integrator' => 'Ολοκληρωτής',
  'Investor' => 'Επενδυτής',
  'Partner' => 'Συνεργάτης',
  'Press' => 'Τύπος',
  'Prospect' => 'Δυνητικός πελάτης',
  'Reseller' => 'Μεταπωλητής',
  'Other' => 'Άλλο:',
  '' => '',
);