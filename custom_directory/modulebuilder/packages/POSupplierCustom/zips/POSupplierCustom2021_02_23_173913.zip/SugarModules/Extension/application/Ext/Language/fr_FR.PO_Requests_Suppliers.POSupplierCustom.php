<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analyste',
  'Competitor' => 'Concurrent',
  'Customer' => 'Client',
  'Integrator' => 'Intégrateur',
  'Investor' => 'Investisseur',
  'Partner' => 'Partenaire',
  'Press' => 'Presse',
  'Prospect' => 'Prospect',
  'Reseller' => 'Revendeur',
  'Other' => 'Autre',
  '' => '',
);