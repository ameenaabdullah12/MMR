<?php
 // created: 2021-02-09 14:23:25
$dictionary['a_supplier']['fields']['billing_address_city']['required']=true;
$dictionary['a_supplier']['fields']['billing_address_city']['audited']=false;
$dictionary['a_supplier']['fields']['billing_address_city']['massupdate']=false;
$dictionary['a_supplier']['fields']['billing_address_city']['comments']='The city used for billing address';
$dictionary['a_supplier']['fields']['billing_address_city']['duplicate_merge']='enabled';
$dictionary['a_supplier']['fields']['billing_address_city']['duplicate_merge_dom_value']='1';
$dictionary['a_supplier']['fields']['billing_address_city']['merge_filter']='disabled';
$dictionary['a_supplier']['fields']['billing_address_city']['unified_search']=false;
$dictionary['a_supplier']['fields']['billing_address_city']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['billing_address_city']['calculated']=false;

 ?>