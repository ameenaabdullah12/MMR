<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['status_c']['labelValue']='Status';
$dictionary['a_supplier']['fields']['status_c']['dependency']='';
$dictionary['a_supplier']['fields']['status_c']['visibility_grid']='';

 ?>