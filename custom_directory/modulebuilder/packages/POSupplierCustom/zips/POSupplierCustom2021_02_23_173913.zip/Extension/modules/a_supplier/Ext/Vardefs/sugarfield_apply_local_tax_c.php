<?php
 // created: 2021-02-23 11:25:31
$dictionary['a_supplier']['fields']['apply_local_tax_c']['labelValue']='Apply Local Tax';
$dictionary['a_supplier']['fields']['apply_local_tax_c']['enforced']='';
$dictionary['a_supplier']['fields']['apply_local_tax_c']['dependency']='';

 ?>