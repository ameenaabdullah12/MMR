<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['terms_text_c']['duplicate_merge_dom_value']=0;
$dictionary['a_supplier']['fields']['terms_text_c']['labelValue']='Terms Text';
$dictionary['a_supplier']['fields']['terms_text_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['terms_text_c']['calculated']='true';
$dictionary['a_supplier']['fields']['terms_text_c']['formula']='getDropdownValue("mmr_due_date_type",$due_date_type_c)';
$dictionary['a_supplier']['fields']['terms_text_c']['enforced']='true';
$dictionary['a_supplier']['fields']['terms_text_c']['dependency']='';

 ?>