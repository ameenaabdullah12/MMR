<?php
 // created: 2021-02-09 14:22:22
$dictionary['a_supplier']['fields']['name']['len']='150';
$dictionary['a_supplier']['fields']['name']['massupdate']=false;
$dictionary['a_supplier']['fields']['name']['comments']='Name of the Company';
$dictionary['a_supplier']['fields']['name']['duplicate_merge']='enabled';
$dictionary['a_supplier']['fields']['name']['duplicate_merge_dom_value']='1';
$dictionary['a_supplier']['fields']['name']['merge_filter']='disabled';
$dictionary['a_supplier']['fields']['name']['unified_search']=false;
$dictionary['a_supplier']['fields']['name']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.75',
  'searchable' => true,
);
$dictionary['a_supplier']['fields']['name']['calculated']=false;

 ?>