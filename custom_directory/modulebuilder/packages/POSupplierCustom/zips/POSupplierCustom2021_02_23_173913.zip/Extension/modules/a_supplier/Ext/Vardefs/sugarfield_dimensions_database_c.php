<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['dimensions_database_c']['labelValue']='Dimensions Database';
$dictionary['a_supplier']['fields']['dimensions_database_c']['dependency']='';
$dictionary['a_supplier']['fields']['dimensions_database_c']['visibility_grid']='';

 ?>