<?php
 // created: 2021-02-23 11:25:31
$dictionary['a_supplier']['fields']['aged_0_to_30_c']['labelValue']='Aged 0 to 30';
$dictionary['a_supplier']['fields']['aged_0_to_30_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_0_to_30_c']['dependency']='';

 ?>