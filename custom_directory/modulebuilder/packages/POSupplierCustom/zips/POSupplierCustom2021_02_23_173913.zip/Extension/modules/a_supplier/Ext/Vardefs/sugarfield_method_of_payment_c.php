<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['method_of_payment_c']['labelValue']='Method Of Payment';
$dictionary['a_supplier']['fields']['method_of_payment_c']['dependency']='';
$dictionary['a_supplier']['fields']['method_of_payment_c']['visibility_grid']='';

 ?>