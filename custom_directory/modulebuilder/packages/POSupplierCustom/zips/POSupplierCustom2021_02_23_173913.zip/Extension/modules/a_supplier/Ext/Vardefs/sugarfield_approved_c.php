<?php
 // created: 2021-02-23 11:25:31
$dictionary['a_supplier']['fields']['approved_c']['labelValue']='Approved';
$dictionary['a_supplier']['fields']['approved_c']['enforced']='';
$dictionary['a_supplier']['fields']['approved_c']['dependency']='';

 ?>