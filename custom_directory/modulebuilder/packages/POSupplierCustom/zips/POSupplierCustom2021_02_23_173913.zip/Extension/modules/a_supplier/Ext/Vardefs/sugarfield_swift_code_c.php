<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['swift_code_c']['labelValue']='Swift Code';
$dictionary['a_supplier']['fields']['swift_code_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['swift_code_c']['enforced']='';
$dictionary['a_supplier']['fields']['swift_code_c']['dependency']='';

 ?>