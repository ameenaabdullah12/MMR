<?php

$mod_strings['LBL_FILTER_SUPPLIER'] = 'Suppliers by Database';