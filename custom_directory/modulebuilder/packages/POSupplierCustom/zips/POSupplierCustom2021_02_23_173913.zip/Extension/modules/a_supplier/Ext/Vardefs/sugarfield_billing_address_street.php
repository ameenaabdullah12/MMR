<?php
 // created: 2021-02-09 14:23:08
$dictionary['a_supplier']['fields']['billing_address_street']['required']=true;
$dictionary['a_supplier']['fields']['billing_address_street']['audited']=false;
$dictionary['a_supplier']['fields']['billing_address_street']['massupdate']=false;
$dictionary['a_supplier']['fields']['billing_address_street']['comments']='The street address used for billing address';
$dictionary['a_supplier']['fields']['billing_address_street']['duplicate_merge']='enabled';
$dictionary['a_supplier']['fields']['billing_address_street']['duplicate_merge_dom_value']='1';
$dictionary['a_supplier']['fields']['billing_address_street']['merge_filter']='disabled';
$dictionary['a_supplier']['fields']['billing_address_street']['unified_search']=false;
$dictionary['a_supplier']['fields']['billing_address_street']['full_text_search']=array (
  'enabled' => true,
  'boost' => '0.26',
  'searchable' => true,
);
$dictionary['a_supplier']['fields']['billing_address_street']['calculated']=false;
$dictionary['a_supplier']['fields']['billing_address_street']['rows']='4';
$dictionary['a_supplier']['fields']['billing_address_street']['cols']='20';

 ?>