<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['bank_account_number_c']['labelValue']='Bank Account Number';
$dictionary['a_supplier']['fields']['bank_account_number_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['bank_account_number_c']['enforced']='';
$dictionary['a_supplier']['fields']['bank_account_number_c']['dependency']='';

 ?>