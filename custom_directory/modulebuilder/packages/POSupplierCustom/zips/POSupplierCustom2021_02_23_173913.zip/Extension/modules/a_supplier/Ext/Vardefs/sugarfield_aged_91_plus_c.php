<?php
 // created: 2021-02-23 11:25:31
$dictionary['a_supplier']['fields']['aged_91_plus_c']['labelValue']='Aged 91 Plus';
$dictionary['a_supplier']['fields']['aged_91_plus_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_91_plus_c']['dependency']='';

 ?>