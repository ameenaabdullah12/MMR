<?php
 // created: 2023-01-04 17:41:34
$dictionary['a_supplier']['fields']['emissions_scope_c']['labelValue']='Emissions Scope';
$dictionary['a_supplier']['fields']['emissions_scope_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['emissions_scope_c']['enforced']='';
$dictionary['a_supplier']['fields']['emissions_scope_c']['dependency']='';

 ?>