<?php
 // created: 2023-01-04 17:39:45
$dictionary['a_supplier']['fields']['supplier_overcode_c']['labelValue']='Supplier Overcode';
$dictionary['a_supplier']['fields']['supplier_overcode_c']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1',
  'searchable' => true,
);
$dictionary['a_supplier']['fields']['supplier_overcode_c']['enforced']='';
$dictionary['a_supplier']['fields']['supplier_overcode_c']['dependency']='';

 ?>