<?php
 // created: 2021-02-09 10:24:36
$dictionary['a_supplier']['fields']['billing_address_country']['audited']=false;
$dictionary['a_supplier']['fields']['billing_address_country']['massupdate']=true;
$dictionary['a_supplier']['fields']['billing_address_country']['help']='Billing Country';
$dictionary['a_supplier']['fields']['billing_address_country']['comments']='The country used for the billing address';
$dictionary['a_supplier']['fields']['billing_address_country']['duplicate_merge']='enabled';
$dictionary['a_supplier']['fields']['billing_address_country']['duplicate_merge_dom_value']='1';
$dictionary['a_supplier']['fields']['billing_address_country']['merge_filter']='disabled';
$dictionary['a_supplier']['fields']['billing_address_country']['unified_search']=false;
$dictionary['a_supplier']['fields']['billing_address_country']['calculated']=false;
$dictionary['a_supplier']['fields']['billing_address_country']['dependency']=false;

 ?>