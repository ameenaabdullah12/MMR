<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['sync_check_c']['labelValue']='Sync Check';
$dictionary['a_supplier']['fields']['sync_check_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['sync_check_c']['enforced']='';
$dictionary['a_supplier']['fields']['sync_check_c']['dependency']='';

 ?>