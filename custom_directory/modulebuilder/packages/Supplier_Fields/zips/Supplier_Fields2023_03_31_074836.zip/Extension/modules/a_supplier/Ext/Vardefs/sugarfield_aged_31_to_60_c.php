<?php
 // created: 2021-02-23 11:25:31
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['labelValue']='Aged 31 to 60';
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['dependency']='';

 ?>