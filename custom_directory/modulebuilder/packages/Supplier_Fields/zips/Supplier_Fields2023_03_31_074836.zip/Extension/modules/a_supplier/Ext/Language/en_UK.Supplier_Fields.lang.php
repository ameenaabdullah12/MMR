<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_AGED_0_TO_30'] = 'Aged 0 to 30';
$mod_strings['LBL_AGED_31_TO_60'] = 'Aged 31 to 60';
$mod_strings['LBL_AGED_61_TO_90'] = 'Aged 61 to 90';
$mod_strings['LBL_AGED_91_PLUS'] = 'Aged 91 Plus';
$mod_strings['LBL_BALANCE'] = 'Balance';
$mod_strings['LBL_DIMENSIONS_DATABASE'] = 'Dimensions Database';
$mod_strings['LBL_EMAIL'] = 'Email';
$mod_strings['LBL_ON_STOP'] = 'On Stop?';
$mod_strings['LBL_TERMS'] = 'Terms';
$mod_strings['LBL_SUPPLIER_CODE'] = 'Supplier Code';
$mod_strings['LBL_SYNC_CHECK'] = 'Sync Check';
$mod_strings['LBL_RECORDVIEW_PANEL1'] = 'Finance';
$mod_strings['LBL_A_DEFAULT_CURRENCY'] = 'Default Currency';
$mod_strings['LBL_SORT_KEY'] = 'Supplier Type';
$mod_strings['LBL_MMR_CONTACT_EMAIL'] = 'MMR Contact Email';
$mod_strings['LBL_WEB_SUPPLIER_TYPE'] = 'Web Supplier Type';
$mod_strings['LBL_SUPPLIER_OVERCODE'] = 'Supplier Overcode';
$mod_strings['LBL_EMISSIONS_SCOPE'] = 'Emissions Scope';
$mod_strings['LBL_SCOPE_SUB_CATEGORY'] = 'Scope sub-category';
$mod_strings['LBL_RECORDVIEW_PANEL5'] = 'More Information';
$mod_strings['LBL_RECORDVIEW_PANEL6'] = 'More Information';
