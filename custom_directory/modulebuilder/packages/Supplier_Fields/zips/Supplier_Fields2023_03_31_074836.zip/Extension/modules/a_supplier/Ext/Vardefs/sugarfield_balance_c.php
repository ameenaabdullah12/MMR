<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['balance_c']['labelValue']='Balance';
$dictionary['a_supplier']['fields']['balance_c']['enforced']='';
$dictionary['a_supplier']['fields']['balance_c']['dependency']='';

 ?>