<?php
 // created: 2021-03-02 14:35:44
$dictionary['a_supplier']['fields']['mmr_contact_email_c']['labelValue']='MMR Contact Email';
$dictionary['a_supplier']['fields']['mmr_contact_email_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['mmr_contact_email_c']['enforced']='';
$dictionary['a_supplier']['fields']['mmr_contact_email_c']['dependency']='';

 ?>