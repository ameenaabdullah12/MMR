<?php
 // created: 2023-01-04 17:42:35
$dictionary['a_supplier']['fields']['scope_sub_category_c']['labelValue']='Scope sub-category';
$dictionary['a_supplier']['fields']['scope_sub_category_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['scope_sub_category_c']['enforced']='';
$dictionary['a_supplier']['fields']['scope_sub_category_c']['dependency']='';

 ?>