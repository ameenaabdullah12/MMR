<?php
 // created: 2021-02-23 11:25:33
$dictionary['a_supplier']['fields']['vat_registration_number_c']['labelValue']='VAT Registration Number';
$dictionary['a_supplier']['fields']['vat_registration_number_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['vat_registration_number_c']['enforced']='';
$dictionary['a_supplier']['fields']['vat_registration_number_c']['dependency']='';

 ?>