<?php
$dictionary['a_supplier']['fields']['c_primary_key']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['approved_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['supplier_code_c']['duplicate_on_record_copy'] = 'no';

$dictionary['a_supplier']['fields']['balance_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['aged_0_to_30_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['aged_91_plus_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['terms_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['sync_check_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['supplier_code_c']['duplicate_on_record_copy'] = 'no';
$dictionary['a_supplier']['fields']['supplier_code_c']['duplicate_on_record_copy'] = 'no';
