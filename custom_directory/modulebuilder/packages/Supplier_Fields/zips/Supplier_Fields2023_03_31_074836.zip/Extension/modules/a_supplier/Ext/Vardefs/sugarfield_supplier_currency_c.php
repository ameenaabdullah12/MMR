<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['supplier_currency_c']['labelValue']='Supplier Currency';
$dictionary['a_supplier']['fields']['supplier_currency_c']['dependency']='';
$dictionary['a_supplier']['fields']['supplier_currency_c']['visibility_grid']='';

 ?>