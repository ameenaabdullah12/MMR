<?php 
$app_list_strings['mmr_due_date_type'] = array (
  '' => '',
  0 => 'Days from Invoice Date',
  3 => 'Days from EOIM',
);