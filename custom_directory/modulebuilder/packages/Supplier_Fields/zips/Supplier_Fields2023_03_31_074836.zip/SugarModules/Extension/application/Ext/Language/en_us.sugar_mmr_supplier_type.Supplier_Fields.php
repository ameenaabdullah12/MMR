<?php 
$app_list_strings['mmr_supplier_type'] = array (
  '' => '',
  'FIELDWORK' => 'Fieldwork',
  'SAMPLE' => 'Sample',
  'TRANSLATION' => 'Translation',
  'DATA PROCESSING' => 'Data Processing',
  'SURVEY PROGRAMMING' => 'Survey Programming',
  'LOGISTICS' => 'Logistics',
  'EQUIPMENT HIRE' => 'Equipment Hire',
  'VENUE HIRE' => 'Venue Hire',
  'MARKETING' => 'Marketing',
  'IT' => 'IT',
  'FREELANCERS' => 'Freelancers',
  'OTHERS' => 'Others',
);