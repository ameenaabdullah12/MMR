<?php 
$app_list_strings['currency_dropdown'] = array (
  '' => '',
  'GBP' => 'GBP',
  'USD' => 'USD',
  'PRC' => 'PRC',
  'EUR' => 'EUR',
  'ZAR' => 'ZAR',
  'INR' => 'INR',
  'SGD' => 'SGD',
  'JPY' => 'JPY',
  'BRL' => 'BRL',
  'CHF' => 'CHF',
);