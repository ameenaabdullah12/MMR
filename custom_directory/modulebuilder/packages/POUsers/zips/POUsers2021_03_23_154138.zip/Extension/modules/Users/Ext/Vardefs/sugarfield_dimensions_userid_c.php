<?php
 // created: 2017-08-22 17:30:58
$dictionary['User']['fields']['dimensions_userid_c']['enforced']='';
$dictionary['User']['fields']['dimensions_userid_c']['dependency']='';

 ?>