<?php
 // created: 2021-01-21 17:06:46
$dictionary['User']['fields']['approval_level_gbp_c']['labelValue']='Approval Level GBP';
$dictionary['User']['fields']['approval_level_gbp_c']['enforced']='';
$dictionary['User']['fields']['approval_level_gbp_c']['dependency']='';

 ?>