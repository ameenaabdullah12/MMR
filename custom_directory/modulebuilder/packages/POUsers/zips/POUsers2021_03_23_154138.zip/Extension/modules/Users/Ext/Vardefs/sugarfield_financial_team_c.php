<?php
 // created: 2017-08-22 17:30:58
$dictionary['User']['fields']['financial_team_c']['dependency']='';
$dictionary['User']['fields']['financial_team_c']['visibility_grid']='';

 ?>