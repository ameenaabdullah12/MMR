<?php
 // created: 2019-07-08 14:49:18
$dictionary['User']['fields']['approver_c']['labelValue']='Approver?';
$dictionary['User']['fields']['approver_c']['enforced']='';
$dictionary['User']['fields']['approver_c']['dependency']='';

 ?>