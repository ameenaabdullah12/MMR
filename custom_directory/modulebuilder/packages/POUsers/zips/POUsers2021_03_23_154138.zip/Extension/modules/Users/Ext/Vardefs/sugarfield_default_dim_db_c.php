<?php
 // created: 2017-08-22 17:30:58
$dictionary['User']['fields']['default_dim_db_c']['dependency']='';
$dictionary['User']['fields']['default_dim_db_c']['visibility_grid']='';

 ?>