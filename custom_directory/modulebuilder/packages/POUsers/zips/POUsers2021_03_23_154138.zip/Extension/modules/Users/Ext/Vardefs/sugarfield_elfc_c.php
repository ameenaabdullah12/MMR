<?php
 // created: 2019-06-03 16:36:34
$dictionary['User']['fields']['elfc_c']['labelValue']='ELFC';
$dictionary['User']['fields']['elfc_c']['dependency']='';
$dictionary['User']['fields']['elfc_c']['visibility_grid']='';

 ?>