<?php
 // created: 2020-08-06 17:22:13
$dictionary['User']['fields']['dimensions_database_c']['labelValue']='Dimensions Database';
$dictionary['User']['fields']['dimensions_database_c']['dependency']='';
$dictionary['User']['fields']['dimensions_database_c']['visibility_grid']='';

 ?>