<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Users/Ext/Language/en_UK.mmr.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Users/Ext/Language/en_UK.mmr.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_DEFAULT_DIM_DB'] = 'Default Dimensions Database';
$mod_strings['LBL_FINANCIAL_TEAM'] = 'Financial Team';
$mod_strings['LBL_DIMENSIONS_USERID'] = 'Dimensions UserID';
$mod_strings['LBL_A_DIMENSIONS_USERID'] = 'Dimensions ID';


?>
<?php
// Merged from custom/Extension/modules/Users/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_DEFAULT_DIM_DB'] = 'Default Dimensions Database';
$mod_strings['LBL_FINANCIAL_TEAM'] = 'Financial Team';
$mod_strings['LBL_DIMENSIONS_USERID'] = 'Dimensions UserID';
$mod_strings['LBL_A_DIMENSIONS_USERID'] = 'Dimensions ID';



?>
<?php
// Merged from custom/Extension/modules/Users/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_DEFAULT_DIM_DB'] = 'Default Dimensions Database';
$mod_strings['LBL_FINANCIAL_TEAM'] = 'Financial Team';
$mod_strings['LBL_DIMENSIONS_USERID'] = 'Dimensions UserID';
$mod_strings['LBL_A_DIMENSIONS_USERID'] = 'Dimensions ID';


?>
