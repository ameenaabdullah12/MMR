<?php
 // created: 2019-06-03 18:22:41
$dictionary['User']['fields']['email']['audited']=true;
$dictionary['User']['fields']['email']['massupdate']=true;
$dictionary['User']['fields']['email']['duplicate_merge']='enabled';
$dictionary['User']['fields']['email']['duplicate_merge_dom_value']='1';
$dictionary['User']['fields']['email']['merge_filter']='disabled';
$dictionary['User']['fields']['email']['unified_search']=false;
$dictionary['User']['fields']['email']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1',
  'searchable' => true,
);
$dictionary['User']['fields']['email']['calculated']=false;

 ?>