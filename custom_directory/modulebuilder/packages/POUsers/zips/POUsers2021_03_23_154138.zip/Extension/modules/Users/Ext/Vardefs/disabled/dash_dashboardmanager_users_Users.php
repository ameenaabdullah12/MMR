<?php
 // created: 2017-08-22 16:49:47
$dictionary['User']['fields']['dash_dashboardmanager_users']['name'] = 'dash_dashboardmanager_users';
$dictionary['User']['fields']['dash_dashboardmanager_users']['type'] = 'link';
$dictionary['User']['fields']['dash_dashboardmanager_users']['relationship'] = 'dash_dashboardmanager_users';
$dictionary['User']['fields']['dash_dashboardmanager_users']['source'] = 'non-db';
$dictionary['User']['fields']['dash_dashboardmanager_users']['vname'] = 'LBL_DASH_DASHBOARDMANAGER_USERS_FROM_DASH_DASHBOARDMANAGER_TITLE';
$dictionary['User']['fields']['dash_dashboardmanager_users']['id_name'] = 'dash_dashboardmanager_usersdash_dashboardmanager_ida';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['name'] = 'dash_dashboardmanager_users_name';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['type'] = 'relate';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['source'] = 'non-db';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['vname'] = 'LBL_DASH_DASHBOARDMANAGER_USERS_FROM_DASH_DASHBOARDMANAGER_TITLE';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['save'] = true;
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['id_name'] = 'dash_dashboardmanager_usersdash_dashboardmanager_ida';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['link'] = 'dash_dashboardmanager_users';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['table'] = 'dash_dashboardmanager';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['module'] = 'dash_DashboardManager';
$dictionary['User']['fields']['dash_dashboardmanager_users_name']['rname'] = 'name';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['name'] = 'dash_dashboardmanager_usersdash_dashboardmanager_ida';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['type'] = 'id';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['relationship'] = 'dash_dashboardmanager_users';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['source'] = 'non-db';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['reportable'] = false;
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['side'] = 'right';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['vname'] = 'LBL_DASH_DASHBOARDMANAGER_USERS_FROM_USERS_TITLE';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['link'] = 'dash_dashboardmanager_users';
$dictionary['User']['fields']['dash_dashboardmanager_usersdash_dashboardmanager_ida']['rname'] = 'id';
