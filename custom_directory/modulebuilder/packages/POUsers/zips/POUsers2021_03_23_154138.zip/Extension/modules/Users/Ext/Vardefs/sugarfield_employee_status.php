<?php
 // created: 2020-09-11 15:22:30
$dictionary['User']['fields']['employee_status']['default']='Active';
$dictionary['User']['fields']['employee_status']['audited']=false;
$dictionary['User']['fields']['employee_status']['massupdate']=true;
$dictionary['User']['fields']['employee_status']['duplicate_merge']='enabled';
$dictionary['User']['fields']['employee_status']['duplicate_merge_dom_value']='1';
$dictionary['User']['fields']['employee_status']['merge_filter']='disabled';
$dictionary['User']['fields']['employee_status']['unified_search']=false;
$dictionary['User']['fields']['employee_status']['calculated']=false;
$dictionary['User']['fields']['employee_status']['dependency']=false;

 ?>