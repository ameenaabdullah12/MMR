<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/




/**
 * This file is where the user authentication occurs. No redirection should happen in this file.
 *
 */
class IdMSugarAuthenticateUser{

    /**
     * Does the actual authentication of the user and returns an id that will be used
     * to load the current user (loadUserOnSession)
     *
     * @param STRING $name
     * @param STRING $password
     * @param STRING $fallback - is this authentication a fallback from a failed authentication
     * @return STRING id - used for loading the user
     */
    function authenticateUser($name, $password, $fallback=false, $passwordEncrypted=false)
    {        
        global $sugar_config;
        
        $GLOBALS['log']->debug("Custom Authentication Access UK: called authenticateUser for user_name: ". $name);        
        $row = self::findUser($name, "(portal_only IS NULL OR portal_only !='1') AND (is_group IS NULL OR is_group !='1') AND status !='Inactive'");
        $GLOBALS['log']->debug("Custom Authentication Access UK: called authenticateUser row: ". print_r($row, 1));        
	      
        if (empty ($row) || !empty($row['external_auth_only']))
        {
            return '';
        }
        else 
        {
            //if super user or password set -> authenticate with aCloudCRM 
            if (($row['id'] == '1') || ($row['user_hash'] != null && $row['user_hash'] != ''))
            {
                if ($row['id'] == '1')
                {
                    $GLOBALS['log']->debug("Custom Authentication Access UK: Checking password for Super User ID = 1");
                }
                else
                {
                    $GLOBALS['log']->debug("Custom Authentication Access UK: Checking password for normal user with user_hash set.");
                }
                
                if (!$passwordEncrypted) {
                    $password = IdMSugarAuthenticate::encodePassword($password);
		}
                
                $row = User::findUserPassword($name, $password, "(portal_only IS NULL OR portal_only !='1') AND (is_group IS NULL OR is_group !='1') AND status !='Inactive'");
    
                // set the ID in the seed user.  This can be used for retrieving the full user record later
                //if it's falling back on Sugar Authentication after the login failed on an external authentication return empty if the user has external_auth_disabled for them
                if (empty ($row) || !empty($row['external_auth_only'])) {
                    return '';
                } else {
                    return $row['id'];
                }
            } 
            else // if not super admin user and no user_hash set
            {
                
                if ($passwordEncrypted)
                {
                    $GLOBALS['log']->debug("Custom Authentication Access UK: Unable to authenticate user against aCloud as password is already hashed. Suspect login attempt originated from mobile or office plugin.");
                    return '';
                }
                //else authenticate with aCloudWS 
                $url = $sugar_config['acloudws_url'].$sugar_config['acloud_authenticatecredentials'];              
                $parameters = array();
                $parameters['EmailAddress'] = $name;
                $parameters['Password'] = $password;
                $result = self::callaCloudAPI($url, $parameters);
            
                $GLOBALS['log']->debug("Custom Authentication Access UK: called aCloud WS authenticatecredentials result: ". print_r($result, 1));
                
                if($result != NULL && $result->User != NULL && ($row['id'] == $result->User->Id)) { 
                    $GLOBALS['log']->debug("Custom Authentication Access UK: Authentication with aCloud WS succeess");                    
                    return $row['id'];
                } elseif ($result != NULL && $result->UserId != NULL && ($row['id'] == $result->UserId)) { 
                    $GLOBALS['log']->debug("Custom Authentication Access UK: Authentication with aCloud WS succeess");                    
                    return $row['id'];
                }else 
                {
                    if ($result == NULL) {
                        $GLOBALS['log']->debug("Custom Authentication Access UK: Authentication with aCloud WS failed for:" .$row['id'] ." acloud: result == NULL");
                    } else {
                            if ($result->User != NULL) {
                                    $GLOBALS['log']->debug("Custom Authentication Access UK: Authentication with aCloud WS failed for:" .$row['id'] ." acloud User->Id: ".$result->User->Id );
                            } else {
                                    $GLOBALS['log']->debug("Custom Authentication Access UK: Authentication with aCloud WS failed for:" .$row['id'] ." acloud UserId: ".$result->UserId );
                            }
                    }
                    return '';

                }
            }
        }
    }
    
    /**
     * Find user 
     * @param string $name Username
     * @param string $password MD5-encoded password
     * @param string $where Limiting query
     * @return the matching User of false if not found
     */
    public function findUser($name, $where = '')
    {
        global $db;
            $name = $db->quote($name);
            $query = "SELECT * from users where user_name='$name'";
            if(!empty($where)) {
                $query .= " AND $where";
            }
            $result = $db->limitQuery($query,0,1,false);
            if(!empty($result)) {
                $row = $db->fetchByAssoc($result);		    
                    return $row;		    
            }
            return false;
    }    
  
    /**
    *
    **/
    public static function callaCloudAPI($url, $parameters) 
    {        
        // Open a curl session for making the call 
        $curl = curl_init($url); 
        // Tell curl to use HTTP POST 
        curl_setopt($curl, CURLOPT_POST, true); 
        // Tell curl not to return headers, but do return the response 
        $headers = array(
                "Content-type: text/json",
                "Accept: text/json",            
            ); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);     
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2); 
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers); 
        curl_setopt($curl, CURLOPT_HEADER, false); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
        // Set the POST arguments to pass to the Sugar server         
        $json = json_encode($parameters);       
        $postArgs = $json;
        
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postArgs); 
        // Make the REST call, returning the result 
        $response = curl_exec($curl);        
        
        // Close the connection 
        curl_close($curl);
        // Convert the result from JSON format to a PHP array 
        $result = json_decode($response); 
        // Echo out the session id 

        return $result;
    }
    
	/**
	 * Checks if a user is a sugarLogin user
	 * which implies they should use the sugar authentication to login
	 *
	 * @param STRING $name
	 * @param STRIUNG $password
	 * @return boolean
	 */
	function isSugarLogin($name, $password)
	{
	    $row = User::findUserPassword($name, $password, "(portal_only IS NULL OR portal_only !='1') AND (is_group IS NULL OR is_group !='1') AND status !='Inactive' AND sugar_login=1");
	    return !empty($row);
	}

	/**
	 * this is called when a user logs in
	 *
	 * @param STRING $name
	 * @param STRING $password
	 * @param STRING $fallback - is this authentication a fallback from a failed authentication
	 * @return boolean
	 */
	function loadUserOnLogin($name, $password, $fallback = false, $PARAMS = array()) {
		global $login_error;

		$GLOBALS['log']->debug("Starting user load for ". $name);
		if(empty($name) || empty($password)) return false;
		$input_hash = $password;
		$passwordEncrypted = false;
		if (!empty($PARAMS) && isset($PARAMS['passwordEncrypted']) && $PARAMS['passwordEncrypted']) {
			$passwordEncrypted = true;
		}// if

		$user_id = $this->authenticateUser($name, $input_hash, $fallback, $passwordEncrypted);
		if(empty($user_id)) {
			$GLOBALS['log']->fatal('SECURITY: User authentication for '.$name.' failed');
			return false;
		}
		$this->loadUserOnSession($user_id);
		return true;
	}
	/**
	 * Loads the current user bassed on the given user_id
	 *
	 * @param STRING $user_id
	 * @return boolean
	 */
	function loadUserOnSession($user_id=''){   
		if(!empty($user_id)){
			$_SESSION['authenticated_user_id'] = $user_id;
		}

		if(!empty($_SESSION['authenticated_user_id']) || !empty($user_id)){
			$GLOBALS['current_user'] = new User();
			if($GLOBALS['current_user']->retrieve($_SESSION['authenticated_user_id'])){

				return true;
			}
		}
		return false;

	}

}

?>