<?php
$viewdefs['Users'] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'selection-list' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_PANEL_1',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'name',
                'label' => 'LBL_NAME',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
              ),
              1 => 
              array (
                'name' => 'user_name',
                'label' => 'LBL_USER_NAME',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
              ),
              2 => 
              array (
                'name' => 'title',
                'label' => 'LBL_TITLE',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
              ),
              3 => 
              array (
                'name' => 'department',
                'label' => 'LBL_DEPARTMENT',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
              ),
              4 => 
              array (
                'name' => 'email',
                'label' => 'LBL_EMAIL',
                'enabled' => true,
                'default' => false,
                'sortable' => true,
              ),
              5 => 
              array (
                'name' => 'phone_work',
                'label' => 'LBL_OFFICE_PHONE',
                'enabled' => true,
                'default' => false,
                'sortable' => true,
              ),
              6 => 
              array (
                'name' => 'status',
                'label' => 'LBL_STATUS',
                'enabled' => true,
                'default' => false,
                'sortable' => true,
              ),
              7 => 
              array (
                'name' => 'dimensions_database_c',
                'label' => 'LBL_DIMENSIONS_DATABASE_C',
                'enabled' => true,
                'default' => false,
              ),
              8 => 
              array (
                'name' => 'approver_c',
                'label' => 'LBL_APPROVER',
                'enabled' => true,
                'default' => false,
              ),
              9 => 
              array (
                'name' => 'approval_level_gbp_c',
                'label' => 'LBL_APPROVAL_LEVEL_GBP',
                'enabled' => true,
                'default' => false,
              ),
              10 => 
              array (
                'name' => 'is_admin',
                'label' => 'LBL_IS_ADMIN',
                'enabled' => true,
                'default' => false,
                'sortable' => true,
              ),
            ),
          ),
        ),
      ),
    ),
  ),
);
