<?php
$viewdefs['Users'] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'list' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_PANEL_1',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'name',
                'label' => 'LBL_NAME',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
                'width' => '30',
              ),
              1 => 
              array (
                'name' => 'user_name',
                'label' => 'LBL_USER_NAME',
                'sortable' => true,
                'width' => '5',
                'default' => true,
                'enabled' => true,
              ),
              2 => 
              array (
                'name' => 'title',
                'label' => 'LBL_TITLE',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
                'width' => '15',
              ),
              3 => 
              array (
                'name' => 'email1',
                'label' => 'LBL_EMAIL_ADDRESS',
                'enabled' => true,
                'width' => '30',
                'default' => true,
              ),
              4 => 
              array (
                'name' => 'department',
                'label' => 'LBL_DEPARTMENT',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
                'width' => '15',
              ),
              5 => 
              array (
                'name' => 'approver_c',
                'label' => 'LBL_APPROVER',
                'enabled' => true,
                'default' => true,
              ),
              6 => 
              array (
                'name' => 'status',
                'label' => 'LBL_STATUS',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
                'width' => '10',
              ),
              7 => 
              array (
                'name' => 'date_entered',
                'label' => 'LBL_DATE_ENTERED',
                'enabled' => true,
                'readonly' => true,
                'width' => '10',
                'default' => true,
              ),
              8 => 
              array (
                'name' => 'is_admin',
                'label' => 'LBL_IS_ADMIN',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
                'width' => '10',
              ),
              9 => 
              array (
                'name' => 'date_modified',
                'label' => 'LBL_DATE_MODIFIED',
                'enabled' => true,
                'readonly' => true,
                'width' => '10',
                'default' => true,
              ),
              10 => 
              array (
                'name' => 'last_login',
                'label' => 'LBL_LAST_LOGIN',
                'enabled' => true,
                'readonly' => true,
                'default' => true,
                'width' => '10',
              ),
              11 => 
              array (
                'name' => 'pwd_last_changed',
                'label' => 'LBL_PSW_MODIFIED',
                'enabled' => true,
                'width' => '10',
                'default' => true,
              ),
              12 => 
              array (
                'name' => 'employee_status',
                'label' => 'LBL_EMPLOYEE_STATUS',
                'enabled' => true,
                'default' => true,
                'width' => '10',
              ),
              13 => 
              array (
                'name' => 'phone_work',
                'label' => 'LBL_OFFICE_PHONE',
                'default' => false,
                'enabled' => true,
                'sortable' => true,
                'width' => '25',
              ),
              14 => 
              array (
                'name' => 'is_group',
                'label' => 'LBL_GROUP_USER',
                'enabled' => true,
                'width' => '10',
                'default' => false,
              ),
              15 => 
              array (
                'name' => 'email',
                'label' => 'LBL_EMAIL',
                'enabled' => true,
                'default' => false,
                'sortable' => true,
                'width' => '30',
              ),
            ),
          ),
        ),
      ),
    ),
  ),
);
