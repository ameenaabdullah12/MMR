<?php 
$app_list_strings['dom_email_link_type'] = array (
  'sugar' => 'aCloud CRM Email Client',
);