<?php 
$app_list_strings['employee_status_dom'] = array (
  'Active' => 'Aktivan',
  'Terminated' => 'Otpušten',
  'Leave of Absence' => 'Dopust',
  '' => '',
);