<?php 
$app_list_strings['EFLC_list'] = array (
  '' => '',
  'EFLC' => 'EFLC',
);