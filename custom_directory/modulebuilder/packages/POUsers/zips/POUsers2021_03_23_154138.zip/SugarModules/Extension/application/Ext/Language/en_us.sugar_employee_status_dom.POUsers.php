<?php 
$app_list_strings['employee_status_dom'] = array (
  'Active' => 'Active',
  'Terminated' => 'Terminated',
  'Leave of Absence' => 'Leave of Absence',
  '' => '',
);