<?php 
$app_list_strings['employee_status_dom'] = array (
  'Active' => 'ใช้งาน',
  'Terminated' => 'ยุติ',
  'Leave of Absence' => 'ลาหยุด',
  '' => '',
);