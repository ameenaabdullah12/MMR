<?php
 // created: 2017-08-22 16:50:42
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts']['name'] = 'a_invoicerequest_accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts']['type'] = 'link';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts']['relationship'] = 'a_invoicerequest_accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts']['vname'] = 'LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_ACCOUNTS_TITLE';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts']['id_name'] = 'a_invoicerequest_accountsaccounts_ida';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['name'] = 'a_invoicerequest_accounts_name';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['type'] = 'relate';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['vname'] = 'LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_ACCOUNTS_TITLE';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['save'] = true;
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['id_name'] = 'a_invoicerequest_accountsaccounts_ida';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['link'] = 'a_invoicerequest_accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['table'] = 'accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['module'] = 'Accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accounts_name']['rname'] = 'name';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['name'] = 'a_invoicerequest_accountsaccounts_ida';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['type'] = 'id';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['relationship'] = 'a_invoicerequest_accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['reportable'] = false;
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['side'] = 'right';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['vname'] = 'LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['link'] = 'a_invoicerequest_accounts';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_accountsaccounts_ida']['rname'] = 'id';
