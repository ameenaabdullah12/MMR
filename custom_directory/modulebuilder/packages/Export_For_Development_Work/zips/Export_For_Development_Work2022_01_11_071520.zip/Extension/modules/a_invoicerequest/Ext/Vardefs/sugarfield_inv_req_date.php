<?php

/* This file was updated by 7_FixCustomFieldsForFTS */
$dictionary['a_invoicerequest']['fields']['inv_req_date']['display_default'] = 'now';
$dictionary['a_invoicerequest']['fields']['inv_req_date']['full_text_search'] = array (
  'boost' => 1,
  'enabled' => true,
);
