<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/ProductTemplates/Ext/Language/en_US.mmr.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/ProductTemplates/Ext/Language/en_US.mmr.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_PRICE_LINES'] = 'Price Lines';


?>
<?php
// Merged from custom/Extension/modules/ProductTemplates/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_PRICE_LINES'] = 'Price Lines';



?>
<?php
// Merged from custom/Extension/modules/ProductTemplates/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_PRICE_LINES'] = 'Price Lines';


?>
