<?php
$mod_strings['LBL_SUPPLY_CHAIN_PART_ONLY'] = 'Supply Chain Part Number';
$mod_strings['LBL_SUPPLY_CHAIN_PART_REVISION'] = 'Supply Chain Revision Number';
