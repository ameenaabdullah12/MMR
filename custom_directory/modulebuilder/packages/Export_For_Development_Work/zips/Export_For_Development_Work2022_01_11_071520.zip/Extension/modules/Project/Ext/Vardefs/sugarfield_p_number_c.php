<?php
 // created: 2017-10-02 10:49:49
$dictionary['Project']['fields']['p_number_c']['labelValue']='P-Number';
$dictionary['Project']['fields']['p_number_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Project']['fields']['p_number_c']['enforced']='';
$dictionary['Project']['fields']['p_number_c']['dependency']='';

 ?>