<?php
 // created: 2017-08-22 16:49:38
$dictionary['ProductTemplate']['fields']['name']['len'] = '80';
$dictionary['ProductTemplate']['fields']['name']['comments'] = 'Name of the product';
$dictionary['ProductTemplate']['fields']['name']['merge_filter'] = 'disabled';
$dictionary['ProductTemplate']['fields']['name']['calculated'] = false;
$dictionary['ProductTemplate']['fields']['name']['full_text_search']['enabled'] = true;
$dictionary['ProductTemplate']['fields']['name']['full_text_search']['searchable'] = true;
$dictionary['ProductTemplate']['fields']['name']['full_text_search']['boost'] = 1.55;

