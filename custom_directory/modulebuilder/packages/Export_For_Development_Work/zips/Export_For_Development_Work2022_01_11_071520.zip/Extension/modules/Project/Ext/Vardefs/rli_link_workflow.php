<?php
$dictionary['Project']['fields']['revenuelineitems']['workflow'] = true;