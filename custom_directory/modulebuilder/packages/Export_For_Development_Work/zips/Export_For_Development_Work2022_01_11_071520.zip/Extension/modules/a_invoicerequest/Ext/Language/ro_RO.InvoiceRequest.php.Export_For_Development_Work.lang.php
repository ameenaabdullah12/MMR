<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/ro_RO.InvoiceRequest.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/ro_RO.InvoiceRequest.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_PROJECT_TITLE'] = 'Project';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Companies ID';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Contacts ID';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_A_INVOICEREQUEST_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Project ID';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE'] = 'Project';

?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_PROJECT_TITLE'] = 'Project';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Companies ID';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Contacts ID';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_A_INVOICEREQUEST_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Project ID';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE'] = 'Project';


?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_PROJECT_TITLE'] = 'Project';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Companies ID';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_A_INVOICEREQUEST_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Contacts ID';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_A_INVOICEREQUEST_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE_ID'] = 'Project ID';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE'] = 'Project';

?>
