<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_PROJECT'] = 'Create Project';
$mod_strings['LBL_MODULE_NAME'] = 'Projectss';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Project';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Project';
$mod_strings['LNK_PROJECT_LIST'] = 'View Projects List';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Project List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Project Search';
$mod_strings['LBL_P_NUMBER'] = 'P-Number';
$mod_strings['LBL_PROJECT_SUBPANEL_TITLE'] = 'Projectss';
