<?php
 // created: 2021-12-02 11:57:49
$dictionary['a_invoicerequest']['fields']['cost_of_research_c']['labelValue']='Total value of project';
$dictionary['a_invoicerequest']['fields']['cost_of_research_c']['enforced']='';
$dictionary['a_invoicerequest']['fields']['cost_of_research_c']['dependency']='';
$dictionary['a_invoicerequest']['fields']['cost_of_research_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>