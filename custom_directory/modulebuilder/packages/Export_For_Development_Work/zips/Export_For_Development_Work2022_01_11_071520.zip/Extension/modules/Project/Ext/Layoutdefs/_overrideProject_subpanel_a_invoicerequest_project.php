<?php
//auto-generated file DO NOT EDIT
$layout_defs['Project']['subpanel_setup']['a_invoicerequest_project']['override_subpanel_name'] = 'Project_subpanel_a_invoicerequest_project';
?>