<?php
 // created: 2017-08-22 16:49:38
$dictionary['ProductTemplate']['fields']['weight']['len'] = '15,5';
$dictionary['ProductTemplate']['fields']['weight']['comments'] = 'Weight of the product';
$dictionary['ProductTemplate']['fields']['weight']['merge_filter'] = 'disabled';
$dictionary['ProductTemplate']['fields']['weight']['calculated'] = false;
$dictionary['ProductTemplate']['fields']['weight']['enable_range_search'] = false;
$dictionary['ProductTemplate']['fields']['weight']['precision'] = '5';

