<?php

    $hook_array['before_save'][] = Array(
        1, 
        'New auto increment number', 
        'custom/modules/a_invoicerequest/auto_increment.php', 
        'increment', 
        'autoIncrement'
    );