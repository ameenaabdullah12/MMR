<?php
 // created: 2021-02-23 11:25:32
$dictionary['a_supplier']['fields']['due_date_type_c']['labelValue']='Due Date Type';
$dictionary['a_supplier']['fields']['due_date_type_c']['dependency']='';
$dictionary['a_supplier']['fields']['due_date_type_c']['visibility_grid']='';

 ?>