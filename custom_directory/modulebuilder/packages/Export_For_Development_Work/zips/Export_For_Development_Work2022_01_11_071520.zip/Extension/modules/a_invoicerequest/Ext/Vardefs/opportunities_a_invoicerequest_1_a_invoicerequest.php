<?php
 // created: 2017-08-22 16:50:43
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1']['name'] = 'opportunities_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1']['type'] = 'link';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1']['relationship'] = 'opportunities_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1']['vname'] = 'LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_OPPORTUNITIES_TITLE';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1']['id_name'] = 'opportunities_a_invoicerequest_1opportunities_ida';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['name'] = 'opportunities_a_invoicerequest_1_name';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['type'] = 'relate';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['vname'] = 'LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_OPPORTUNITIES_TITLE';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['save'] = true;
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['id_name'] = 'opportunities_a_invoicerequest_1opportunities_ida';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['link'] = 'opportunities_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['table'] = 'opportunities';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['module'] = 'Opportunities';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1_name']['rname'] = 'name';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['name'] = 'opportunities_a_invoicerequest_1opportunities_ida';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['type'] = 'id';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['relationship'] = 'opportunities_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['reportable'] = false;
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['side'] = 'right';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['vname'] = 'LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_A_INVOICEREQUEST_TITLE';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['link'] = 'opportunities_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['opportunities_a_invoicerequest_1opportunities_ida']['rname'] = 'id';
