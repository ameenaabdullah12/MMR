<?php
// created: 2015-08-28 16:55:03
$dictionary["Prospect"]["fields"]["docusign_status_prospects"] = array(
    'name'         => 'docusign_status_prospects',
    'type'         => 'link',
    'relationship' => 'docusign_status_prospects',
    'source'       => 'non-db',
    'module'       => 'WSYS_docusign_status',
    'bean_name'    => 'WSYS_docusign_status',
    'vname'        => 'LBL_DOCUSIGN_STATUS_PROSPECTS_FROM_WSYS_DOCUSIGN_STATUS_TITLE',
    'id_name'      => 'docusign_status_prospects_docusign_status_ida',
);
