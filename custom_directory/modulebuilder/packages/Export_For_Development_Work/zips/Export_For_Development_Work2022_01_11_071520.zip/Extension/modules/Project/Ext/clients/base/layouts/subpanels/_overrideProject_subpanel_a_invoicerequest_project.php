<?php
// created: 2017-08-22 17:00:57
$viewdefs['Project']['base']['layout']['subpanels']['components'][] = array (
  'override_subpanel_list_view' => 
  array (
    'view' => 'subpanel-for-project',
    'link' => 'a_invoicerequest_project',
  ),
);