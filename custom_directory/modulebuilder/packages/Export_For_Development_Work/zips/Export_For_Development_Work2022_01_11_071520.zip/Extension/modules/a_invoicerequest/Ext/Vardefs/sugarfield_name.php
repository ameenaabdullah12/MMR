<?php
 // created: 2017-08-23 11:06:23
$dictionary['a_invoicerequest']['fields']['name']['importable']='false';
$dictionary['a_invoicerequest']['fields']['name']['duplicate_merge']='disabled';
$dictionary['a_invoicerequest']['fields']['name']['duplicate_merge_dom_value']=0;
$dictionary['a_invoicerequest']['fields']['name']['merge_filter']='disabled';
$dictionary['a_invoicerequest']['fields']['name']['calculated']='true';
$dictionary['a_invoicerequest']['fields']['name']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '3',
  'searchable' => false,
);
$dictionary['a_invoicerequest']['fields']['name']['massupdate']=false;
$dictionary['a_invoicerequest']['fields']['name']['formula']='"Request No"';
$dictionary['a_invoicerequest']['fields']['name']['enforced']=true;

 ?>