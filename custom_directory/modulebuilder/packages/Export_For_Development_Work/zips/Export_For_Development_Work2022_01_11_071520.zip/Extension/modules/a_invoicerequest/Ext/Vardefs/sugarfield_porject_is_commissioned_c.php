<?php
 // created: 2017-08-22 17:31:00
$dictionary['a_invoicerequest']['fields']['porject_is_commissioned_c']['enforced']='';
$dictionary['a_invoicerequest']['fields']['porject_is_commissioned_c']['dependency']='';

 ?>