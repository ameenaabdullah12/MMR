<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_RECORDVIEW_PANEL1'] = 'DO NOT EDIT';
$mod_strings['LBL_RECORDVIEW_PANEL2'] = 'Invoice Details';
$mod_strings['LBL_NAME'] = 'Request No';
$mod_strings['LBL_PROJ_COMMISSIONED_DATE'] = 'Proj Commissioned Date';
$mod_strings['LBL_DO_NOT_EDIT'] = '-DO NOT EDIT A REQUEST ONCE YOU HAVE ALREADY RAISED IT THE FIRST TIME - IF ANYTHING NEEDS TO BE CORRECTED PLEASE EMAIL A.SALESINVOICES@MMR-RESEARCH.COM ';
$mod_strings['LBL_DO_NOT_EDIT_2'] = ' DO NOT EDIT A REQUEST ONCE YOU HAVE ALREADY RAISED IT THE FIRST TIME - IF ANYTHING NEEDS TO BE CORRECTED PLEASE EMAIL A.SALESINVOICES@MMR-RESEARCH.COM ';
$mod_strings['LBL_AMOUNT'] = 'Amount line 1';
$mod_strings['LBL_CURRENCY'] = 'LBL_CURRENCY';
$mod_strings['LBL_COST_OF_RESEARCH'] = 'Total value of project';
