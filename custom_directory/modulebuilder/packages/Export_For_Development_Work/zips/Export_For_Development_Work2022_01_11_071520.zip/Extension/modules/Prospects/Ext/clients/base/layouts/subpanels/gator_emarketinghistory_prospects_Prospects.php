<?php
// created: 2015-07-09 14:25:22
$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);