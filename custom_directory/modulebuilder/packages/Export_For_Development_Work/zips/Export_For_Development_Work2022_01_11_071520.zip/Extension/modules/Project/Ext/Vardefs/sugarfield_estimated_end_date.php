<?php
 // created: 2017-01-06 15:55:12
$dictionary['Project']['fields']['estimated_end_date']['required']=false;

 ?>