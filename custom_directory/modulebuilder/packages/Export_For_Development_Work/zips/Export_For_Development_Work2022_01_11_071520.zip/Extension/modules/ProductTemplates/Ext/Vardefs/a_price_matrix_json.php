<?php
$dictionary['ProductTemplate']['fields']['a_price_matrix_json'] = array (
    'name' => 'a_price_matrix_json',
    'vname' => 'LBL_PRICE_MATRIX_JSON',
    'type' => 'longtext',
    'comment' => 'Price Matrix JSON text',
    'audited' => false,
    'required' => false,
    'reportable' => false,
);