<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Contracts/Ext/Language/en_UK.mmr.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Contracts/Ext/Language/en_UK.mmr.php
 
 // created: 2017-08-22 17:15:43
$mod_strings['LBL_QUOTES_SUBPANEL_TITLE'] = 'Invoice Requestsx';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Company Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Company Name';
$mod_strings['LBL_OPPORTUNITY'] = 'Project';


?>
<?php
// Merged from custom/Extension/modules/Contracts/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:43
$mod_strings['LBL_QUOTES_SUBPANEL_TITLE'] = 'Invoice Requestsx';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Company Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Company Name';
$mod_strings['LBL_OPPORTUNITY'] = 'Project';



?>
<?php
// Merged from custom/Extension/modules/Contracts/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:43
$mod_strings['LBL_QUOTES_SUBPANEL_TITLE'] = 'Invoice Requestsx';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Company Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Company Name';
$mod_strings['LBL_OPPORTUNITY'] = 'Project';


?>
