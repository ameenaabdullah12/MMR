<?php
 // created: 2021-02-23 11:25:31
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['labelValue']='Aged 61 to 90';
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['dependency']='';

 ?>