<?php
// created: 2021-05-14 06:23:41
$viewdefs['a_supplier']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_A_SUPPLIER_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'a_supplier_documents_1',
  ),
);