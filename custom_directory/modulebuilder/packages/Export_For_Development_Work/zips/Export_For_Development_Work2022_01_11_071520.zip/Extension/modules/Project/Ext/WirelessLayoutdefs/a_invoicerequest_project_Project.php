<?php
 // created: 2014-07-04 11:58:11
$layout_defs["Project"]["subpanel_setup"]['a_invoicerequest_project'] = array (
  'order' => 100,
  'module' => 'a_invoicerequest',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE',
  'get_subpanel_data' => 'a_invoicerequest_project',
);
