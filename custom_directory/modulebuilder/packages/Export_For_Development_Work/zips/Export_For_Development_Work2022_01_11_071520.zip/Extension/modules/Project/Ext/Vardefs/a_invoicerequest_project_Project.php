<?php
// created: 2014-07-04 11:58:11
$dictionary["Project"]["fields"]["a_invoicerequest_project"] = array (
  'name' => 'a_invoicerequest_project',
  'type' => 'link',
  'relationship' => 'a_invoicerequest_project',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE',
);
