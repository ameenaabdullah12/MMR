<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_ADDRESS_TITLE'] = 'Addresses';
$mod_strings['LBL_A_INVOICEREQUEST_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Companies';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_PROJECT_TITLE'] = 'Project';
