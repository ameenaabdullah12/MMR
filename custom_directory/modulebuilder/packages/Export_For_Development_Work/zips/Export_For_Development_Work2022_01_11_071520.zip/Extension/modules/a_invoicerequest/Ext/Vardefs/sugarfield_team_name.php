<?php
 // created: 2017-08-22 16:49:38
$dictionary['a_invoicerequest']['fields']['team_name']['dependency'] = 'not(equal(related($opportunities_a_invoicerequest_1,"commissioned_date_c"),""))';

