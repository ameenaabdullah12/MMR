<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Project/Ext/Language/en_UK.mmr.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Project/Ext/Language/en_UK.mmr.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_QUOTES_SUBPANEL_TITLE'] = 'Invoice Requestsx';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Companies';
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Projects';
$mod_strings['LBL_OPPORTUNITIES'] = 'Projects';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE'] = 'Invoice Request';


?>
<?php
// Merged from custom/Extension/modules/Project/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_QUOTES_SUBPANEL_TITLE'] = 'Invoice Requestsx';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Companies';
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Projects';
$mod_strings['LBL_OPPORTUNITIES'] = 'Projects';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE'] = 'Invoice Request';



?>
<?php
// Merged from custom/Extension/modules/Project/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_QUOTES_SUBPANEL_TITLE'] = 'Invoice Requestsx';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Companies';
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Projects';
$mod_strings['LBL_OPPORTUNITIES'] = 'Projects';
$mod_strings['LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE'] = 'Invoice Request';


?>
