<?php
 // created: 2017-08-22 17:30:58
$dictionary['ProductTemplate']['fields']['stk_status_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['ProductTemplate']['fields']['stk_status_c']['enforced']='';
$dictionary['ProductTemplate']['fields']['stk_status_c']['dependency']='';

 ?>