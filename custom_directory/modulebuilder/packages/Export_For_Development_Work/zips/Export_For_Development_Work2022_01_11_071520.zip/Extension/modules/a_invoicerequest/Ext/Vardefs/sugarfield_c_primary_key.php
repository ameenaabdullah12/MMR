<?php

/* This file was updated by 7_FixCustomFieldsForFTS */
$dictionary['a_invoicerequest']['fields']['c_primary_key']['autoinc_next'] = '2';
$dictionary['a_invoicerequest']['fields']['c_primary_key']['full_text_search'] = array (
  'boost' => 1,
  'enabled' => true,
);
