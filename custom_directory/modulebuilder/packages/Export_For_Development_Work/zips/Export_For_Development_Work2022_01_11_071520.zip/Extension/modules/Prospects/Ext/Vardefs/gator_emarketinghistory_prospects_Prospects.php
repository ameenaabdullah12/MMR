<?php
// created: 2015-07-10 14:40:05
$dictionary["Prospect"]["fields"]["gator_emarketinghistory_prospects"] = array (
  'name' => 'gator_emarketinghistory_prospects',
  'type' => 'link',
  'relationship' => 'gator_emarketinghistory_prospects',
  'source' => 'non-db',
  'module' => 'GATOR_EmarketingHistory',
  'bean_name' => 'GATOR_EmarketingHistory',
  'vname' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_PROSPECTS_TITLE',
  'id_name' => 'prospect_id',
  'link-type' => 'many',
  'side' => 'left',
);
