<?php
 // created: 2017-08-22 16:49:38
$dictionary['a_invoicerequest']['fields']['amount2']['help'] = '';
$dictionary['a_invoicerequest']['fields']['amount2']['comments'] = '';
$dictionary['a_invoicerequest']['fields']['amount2']['type'] = 'decimal';
$dictionary['a_invoicerequest']['fields']['amount2']['len'] = '18';
$dictionary['a_invoicerequest']['fields']['amount2']['precision'] = '2';
$dictionary['a_invoicerequest']['fields']['amount2']['default'] = '0.00';

