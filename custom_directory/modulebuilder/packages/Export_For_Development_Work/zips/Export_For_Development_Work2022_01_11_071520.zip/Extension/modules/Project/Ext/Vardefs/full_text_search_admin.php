<?php
 // created: 2019-06-05 16:06:23
$dictionary['Project']['full_text_search']=false;
