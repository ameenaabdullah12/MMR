<?php
 // created: 2017-01-06 15:55:00
$dictionary['Project']['fields']['estimated_start_date']['required']=false;

 ?>