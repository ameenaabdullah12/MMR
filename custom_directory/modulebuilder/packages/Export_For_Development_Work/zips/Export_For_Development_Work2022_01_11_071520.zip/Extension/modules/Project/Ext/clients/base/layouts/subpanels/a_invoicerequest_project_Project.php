<?php
// created: 2017-08-22 17:00:57
$viewdefs['Project']['base']['layout']['subpanels']['components'][] = array (
  'label' => 'LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE',
  'context' => 
  array (
    'link' => 'a_invoicerequest_project',
  ),
  'layout' => 'subpanel',
);