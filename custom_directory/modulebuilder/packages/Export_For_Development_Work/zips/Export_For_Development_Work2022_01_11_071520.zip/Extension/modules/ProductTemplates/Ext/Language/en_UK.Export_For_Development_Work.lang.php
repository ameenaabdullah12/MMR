<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_PRODUCT_ID'] = 'Quoted Line Item ID:';
$mod_strings['LBL_MODULE_NAME'] = 'Product Catalog';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Product Catalogue';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Create Item';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Product Catalogue List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Product Catalogue Search';
