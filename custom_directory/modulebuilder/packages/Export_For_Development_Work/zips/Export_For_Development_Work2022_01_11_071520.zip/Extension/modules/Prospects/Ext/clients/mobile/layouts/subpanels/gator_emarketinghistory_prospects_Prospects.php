<?php
// created: 2015-07-09 14:25:27
$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);

$viewdefs['Prospects']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'context' => 
  array (
    'link' => 'gator_emarketinghistory_prospects',
  ),
);