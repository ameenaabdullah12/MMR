<?php
 // created: 2015-07-10 14:40:06
$layout_defs["Prospects"]["subpanel_setup"]['gator_emarketinghistory_prospects'] = array (
  'order' => 100,
  'module' => 'GATOR_EmarketingHistory',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_GATOR_EMARKETINGHISTORY_PROSPECTS_FROM_GATOR_EMARKETINGHISTORY_TITLE',
  'get_subpanel_data' => 'gator_emarketinghistory_prospects',
);
