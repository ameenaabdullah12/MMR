<?php
 // created: 2017-09-22 12:47:20
$dictionary['a_invoicerequest']['fields']['amount']['help']='Must be greater than 0';
$dictionary['a_invoicerequest']['fields']['amount']['comments']='Must be greater than 0';
$dictionary['a_invoicerequest']['fields']['amount']['type']='decimal';
$dictionary['a_invoicerequest']['fields']['amount']['len']='18';
$dictionary['a_invoicerequest']['fields']['amount']['precision']=2;
$dictionary['a_invoicerequest']['fields']['amount']['default']='';
$dictionary['a_invoicerequest']['fields']['amount']['required']=true;
$dictionary['a_invoicerequest']['fields']['amount']['massupdate']=false;

 ?>