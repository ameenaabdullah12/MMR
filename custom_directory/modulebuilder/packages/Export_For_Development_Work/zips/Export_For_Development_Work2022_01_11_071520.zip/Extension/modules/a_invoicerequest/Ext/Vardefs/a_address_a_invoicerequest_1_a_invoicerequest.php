<?php
 // created: 2017-08-22 16:50:43
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1']['name'] = 'a_address_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1']['type'] = 'link';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1']['relationship'] = 'a_address_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1']['vname'] = 'LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_ADDRESS_TITLE';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1']['id_name'] = 'a_address_a_invoicerequest_1a_address_ida';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['name'] = 'a_address_a_invoicerequest_1_name';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['type'] = 'relate';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['vname'] = 'LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_ADDRESS_TITLE';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['save'] = true;
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['id_name'] = 'a_address_a_invoicerequest_1a_address_ida';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['link'] = 'a_address_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['table'] = 'a_address';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['module'] = 'a_address';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1_name']['rname'] = 'name';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['name'] = 'a_address_a_invoicerequest_1a_address_ida';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['type'] = 'id';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['relationship'] = 'a_address_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['reportable'] = false;
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['side'] = 'right';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['vname'] = 'LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_INVOICEREQUEST_TITLE';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['link'] = 'a_address_a_invoicerequest_1';
$dictionary['a_invoicerequest']['fields']['a_address_a_invoicerequest_1a_address_ida']['rname'] = 'id';
