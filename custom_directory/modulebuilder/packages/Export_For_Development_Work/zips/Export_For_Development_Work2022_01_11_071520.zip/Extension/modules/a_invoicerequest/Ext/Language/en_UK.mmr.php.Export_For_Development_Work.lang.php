<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/en_UK.mmr.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/en_UK.mmr.php
 
 // created: 2017-08-22 17:15:45
$mod_strings['LBL_CLIENT_PO'] = 'Client PO Number';
$mod_strings['LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_ADDRESS_TITLE'] = 'Billing Account';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Billing Contact';
$mod_strings['LBL_VAT_RATE'] = 'Vat Rate';
$mod_strings['LBL_INV_REQ_DATE'] = 'Date';
$mod_strings['LBL_OVERCODE_NAME'] = 'Client';
$mod_strings['LBL_AMOUNT'] = 'Amount line 1';
$mod_strings['LBL_DETAIL'] = 'Detail line 1';
$mod_strings['LBL_DETAIL2'] = 'Extra Chargeables';
$mod_strings['LBL_NOTES_ACCOUNTS'] = 'Notes for Accounts';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Line 1';
$mod_strings['LBL_QUICKCREATE_PANEL3'] = 'Line 1';
$mod_strings['LBL_INVOICE_TYPE'] = 'Invoice Type';
$mod_strings['LBL_CURRENCY_LIST'] = 'Currency';
$mod_strings['LBL_TOTAL'] = 'Total';
$mod_strings['LBL_AMOUNT2'] = 'Amount line 2';
$mod_strings['LBL_AMOUNT3'] = 'Amount line 3';
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'Requested By';
$mod_strings['LBL_NAME'] = 'Request No';
$mod_strings['LBL_A_PRIMARY_KEY'] = 'No';
$mod_strings['LBL_INVOICE_NO'] = 'Invoice No';
$mod_strings['LBL_INVOICE_DATE'] = 'Invoice Date';
$mod_strings['LBL_COST_OF_RESEARCH'] = 'Cost of research';
$mod_strings['LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_OPPORTUNITIES_TITLE'] = 'Project';
$mod_strings['LBL_ACCESS_DENIED'] = 'Access denied';
$mod_strings['LBL_INVOICED_AMOUNT'] = 'Invoiced Amount';
$mod_strings['LBL_QUICKCREATE_PANEL4'] = 'DO NOT EDIT';
$mod_strings['LBL_DETAILVIEW_PANEL4'] = 'DO NOT EDIT';
$mod_strings['LBL_NOT_COMMISSIONED'] = 'Not Commissioned';
$mod_strings['LBL_DETAIL3'] = 'Detail line 3';
$mod_strings['LBL_TEAMS'] = 'Teams';
$mod_strings['LBL_PROJ_COMMISSIONED_DATE'] = 'Proj Commissioned Date';
$mod_strings['LBL_PORJECT_IS_COMMISSIONED'] = 'Porject Is Commissioned';


?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:45
$mod_strings['LBL_CLIENT_PO'] = 'Client PO Number';
$mod_strings['LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_ADDRESS_TITLE'] = 'Billing Account';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Billing Contact';
$mod_strings['LBL_VAT_RATE'] = 'Vat Rate';
$mod_strings['LBL_INV_REQ_DATE'] = 'Date';
$mod_strings['LBL_OVERCODE_NAME'] = 'Client';
$mod_strings['LBL_AMOUNT'] = 'Amount line 1';
$mod_strings['LBL_DETAIL'] = 'Detail line 1';
$mod_strings['LBL_DETAIL2'] = 'Extra Chargeables';
$mod_strings['LBL_NOTES_ACCOUNTS'] = 'Notes for Accounts';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Line 1';
$mod_strings['LBL_QUICKCREATE_PANEL3'] = 'Line 1';
$mod_strings['LBL_INVOICE_TYPE'] = 'Invoice Type';
$mod_strings['LBL_CURRENCY_LIST'] = 'Currency';
$mod_strings['LBL_TOTAL'] = 'Total';
$mod_strings['LBL_AMOUNT2'] = 'Amount line 2';
$mod_strings['LBL_AMOUNT3'] = 'Amount line 3';
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'Requested By';
$mod_strings['LBL_NAME'] = 'Request No';
$mod_strings['LBL_A_PRIMARY_KEY'] = 'No';
$mod_strings['LBL_INVOICE_NO'] = 'Invoice No';
$mod_strings['LBL_INVOICE_DATE'] = 'Invoice Date';
$mod_strings['LBL_COST_OF_RESEARCH'] = 'Cost of research';
$mod_strings['LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_OPPORTUNITIES_TITLE'] = 'Project';
$mod_strings['LBL_ACCESS_DENIED'] = 'Access denied';
$mod_strings['LBL_INVOICED_AMOUNT'] = 'Invoiced Amount';
$mod_strings['LBL_QUICKCREATE_PANEL4'] = 'DO NOT EDIT';
$mod_strings['LBL_DETAILVIEW_PANEL4'] = 'DO NOT EDIT';
$mod_strings['LBL_NOT_COMMISSIONED'] = 'Not Commissioned';
$mod_strings['LBL_DETAIL3'] = 'Detail line 3';
$mod_strings['LBL_TEAMS'] = 'Teams';
$mod_strings['LBL_PROJ_COMMISSIONED_DATE'] = 'Proj Commissioned Date';
$mod_strings['LBL_PORJECT_IS_COMMISSIONED'] = 'Porject Is Commissioned';



?>
<?php
// Merged from custom/Extension/modules/a_invoicerequest/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:45
$mod_strings['LBL_CLIENT_PO'] = 'Client PO Number';
$mod_strings['LBL_A_ADDRESS_A_INVOICEREQUEST_1_FROM_A_ADDRESS_TITLE'] = 'Billing Account';
$mod_strings['LBL_A_INVOICEREQUEST_CONTACTS_FROM_CONTACTS_TITLE'] = 'Billing Contact';
$mod_strings['LBL_VAT_RATE'] = 'Vat Rate';
$mod_strings['LBL_INV_REQ_DATE'] = 'Date';
$mod_strings['LBL_OVERCODE_NAME'] = 'Client';
$mod_strings['LBL_AMOUNT'] = 'Amount line 1';
$mod_strings['LBL_DETAIL'] = 'Detail line 1';
$mod_strings['LBL_DETAIL2'] = 'Extra Chargeables';
$mod_strings['LBL_NOTES_ACCOUNTS'] = 'Notes for Accounts';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Line 1';
$mod_strings['LBL_QUICKCREATE_PANEL3'] = 'Line 1';
$mod_strings['LBL_INVOICE_TYPE'] = 'Invoice Type';
$mod_strings['LBL_CURRENCY_LIST'] = 'Currency';
$mod_strings['LBL_TOTAL'] = 'Total';
$mod_strings['LBL_AMOUNT2'] = 'Amount line 2';
$mod_strings['LBL_AMOUNT3'] = 'Amount line 3';
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'Requested By';
$mod_strings['LBL_NAME'] = 'Request No';
$mod_strings['LBL_A_PRIMARY_KEY'] = 'No';
$mod_strings['LBL_INVOICE_NO'] = 'Invoice No';
$mod_strings['LBL_INVOICE_DATE'] = 'Invoice Date';
$mod_strings['LBL_COST_OF_RESEARCH'] = 'Cost of research';
$mod_strings['LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_OPPORTUNITIES_TITLE'] = 'Project';
$mod_strings['LBL_ACCESS_DENIED'] = 'Access denied';
$mod_strings['LBL_INVOICED_AMOUNT'] = 'Invoiced Amount';
$mod_strings['LBL_QUICKCREATE_PANEL4'] = 'DO NOT EDIT';
$mod_strings['LBL_DETAILVIEW_PANEL4'] = 'DO NOT EDIT';
$mod_strings['LBL_NOT_COMMISSIONED'] = 'Not Commissioned';
$mod_strings['LBL_DETAIL3'] = 'Detail line 3';
$mod_strings['LBL_TEAMS'] = 'Teams';
$mod_strings['LBL_PROJ_COMMISSIONED_DATE'] = 'Proj Commissioned Date';
$mod_strings['LBL_PORJECT_IS_COMMISSIONED'] = 'Porject Is Commissioned';


?>
