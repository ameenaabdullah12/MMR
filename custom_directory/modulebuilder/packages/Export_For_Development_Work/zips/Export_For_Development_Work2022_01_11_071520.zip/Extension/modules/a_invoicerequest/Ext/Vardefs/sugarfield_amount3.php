<?php
 // created: 2017-08-22 16:49:38
$dictionary['a_invoicerequest']['fields']['amount3']['help'] = '';
$dictionary['a_invoicerequest']['fields']['amount3']['comments'] = '';
$dictionary['a_invoicerequest']['fields']['amount3']['type'] = 'decimal';
$dictionary['a_invoicerequest']['fields']['amount3']['len'] = '18';
$dictionary['a_invoicerequest']['fields']['amount3']['precision'] = '2';
$dictionary['a_invoicerequest']['fields']['amount3']['default'] = '0.00';

