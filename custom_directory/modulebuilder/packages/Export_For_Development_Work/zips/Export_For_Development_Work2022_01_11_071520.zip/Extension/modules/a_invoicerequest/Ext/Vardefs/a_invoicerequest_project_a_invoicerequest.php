<?php
 // created: 2017-08-22 16:50:43
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project']['name'] = 'a_invoicerequest_project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project']['type'] = 'link';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project']['relationship'] = 'a_invoicerequest_project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project']['vname'] = 'LBL_A_INVOICEREQUEST_PROJECT_FROM_PROJECT_TITLE';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project']['id_name'] = 'a_invoicerequest_projectproject_ida';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['name'] = 'a_invoicerequest_project_name';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['type'] = 'relate';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['vname'] = 'LBL_A_INVOICEREQUEST_PROJECT_FROM_PROJECT_TITLE';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['save'] = true;
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['id_name'] = 'a_invoicerequest_projectproject_ida';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['link'] = 'a_invoicerequest_project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['table'] = 'project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['module'] = 'Project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_project_name']['rname'] = 'name';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['name'] = 'a_invoicerequest_projectproject_ida';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['type'] = 'id';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['relationship'] = 'a_invoicerequest_project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['source'] = 'non-db';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['reportable'] = false;
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['side'] = 'right';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['vname'] = 'LBL_A_INVOICEREQUEST_PROJECT_FROM_A_INVOICEREQUEST_TITLE';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['link'] = 'a_invoicerequest_project';
$dictionary['a_invoicerequest']['fields']['a_invoicerequest_projectproject_ida']['rname'] = 'id';
