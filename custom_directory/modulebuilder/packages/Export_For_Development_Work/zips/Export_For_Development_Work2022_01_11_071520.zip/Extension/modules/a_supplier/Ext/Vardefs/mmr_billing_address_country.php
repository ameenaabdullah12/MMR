<?php
$dictionary['a_supplier']['fields']['billing_address_country']['type'] = 'enum';
$dictionary['a_supplier']['fields']['billing_address_country']['options'] = 'mmr_country';

 ?>