<?php
 // created: 2021-11-18 11:51:41
$dictionary['a_invoicerequest']['fields']['do_not_edit_c']['labelValue']='-DO NOT EDIT A REQUEST ONCE YOU HAVE ALREADY RAISED IT THE FIRST TIME - IF ANYTHING NEEDS TO BE CORRECTED PLEASE EMAIL A.SALESINVOICES@MMR-RESEARCH.COM ';
$dictionary['a_invoicerequest']['fields']['do_not_edit_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_invoicerequest']['fields']['do_not_edit_c']['enforced']='';
$dictionary['a_invoicerequest']['fields']['do_not_edit_c']['dependency']='not(equal("",$c_primary_key))';

 ?>