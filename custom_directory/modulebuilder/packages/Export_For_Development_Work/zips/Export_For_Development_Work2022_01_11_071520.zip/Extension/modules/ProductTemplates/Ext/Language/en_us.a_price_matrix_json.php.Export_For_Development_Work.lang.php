<?php
$mod_strings['LBL_PRICE_MATRIX_JSON'] = 'Price Matrix JSON Data';
