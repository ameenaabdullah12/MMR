<?php
// created: 2021-05-14 06:23:41
$dictionary["a_supplier"]["fields"]["a_supplier_documents_1"] = array (
  'name' => 'a_supplier_documents_1',
  'type' => 'link',
  'relationship' => 'a_supplier_documents_1',
  'source' => 'non-db',
  'module' => 'Documents',
  'bean_name' => 'Document',
  'vname' => 'LBL_A_SUPPLIER_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
  'id_name' => 'a_supplier_documents_1documents_idb',
);
