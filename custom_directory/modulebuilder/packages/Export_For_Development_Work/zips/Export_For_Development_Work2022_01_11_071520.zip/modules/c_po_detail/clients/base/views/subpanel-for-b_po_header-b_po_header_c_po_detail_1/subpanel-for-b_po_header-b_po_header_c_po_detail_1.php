<?php
// created: 2021-03-25 10:39:42
$viewdefs['c_po_detail']['base']['view']['subpanel-for-b_po_header-b_po_header_c_po_detail_1'] = array (
  'panels' => 
  array (
    0 => 
    array (
      'name' => 'panel_header',
      'label' => 'LBL_PANEL_1',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'name',
          'label' => 'LBL_LIST_SALE_NAME',
          'enabled' => true,
          'default' => true,
          'link' => true,
          'width' => 'small',
        ),
        1 => 
        array (
          'name' => 'description',
          'label' => 'LBL_DESCRIPTION',
          'enabled' => true,
          'sortable' => false,
          'default' => true,
        ),
        2 => 
        array (
          'name' => 'price_c',
          'label' => 'LBL_PRICE',
          'enabled' => true,
          'related_fields' => 
          array (
            0 => 'currency_id',
            1 => 'base_rate',
          ),
          'currency_format' => true,
          'default' => true,
          'width' => 'small',
        ),
        3 => 
        array (
          'name' => 'total_received_value_c',
          'label' => 'LBL_TOTAL_RECEIVED_VALUE',
          'enabled' => true,
          'related_fields' => 
          array (
            0 => 'currency_id',
            1 => 'base_rate',
          ),
          'currency_format' => true,
          'default' => true,
          'width' => 'small',
        ),
        4 => 
        array (
          'name' => 'status_c',
          'label' => 'LBL_STATUS',
          'enabled' => true,
          'default' => true,
          'width' => 'xsmall',
        ),
        5 => 
        array (
          'name' => 'rcv_message_c',
          'label' => 'LBL_RCV_MESSAGE',
          'enabled' => true,
          'default' => true,
          'width' => 'medium',
        ),
        6 => 
        array (
          'name' => 'opportunities_c_po_detail_1_name',
          'label' => 'LBL_OPPORTUNITIES_C_PO_DETAIL_1_FROM_OPPORTUNITIES_TITLE',
          'enabled' => true,
          'id' => 'OPPORTUNITIES_C_PO_DETAIL_1OPPORTUNITIES_IDA',
          'link' => true,
          'sortable' => false,
          'width' => 'medium',
          'default' => true,
        ),
        7 => 
        array (
          'name' => 'cost_centre_c',
          'label' => 'LBL_COST_CENTRE',
          'enabled' => true,
          'width' => 'small',
          'default' => true,
        ),
        8 => 
        array (
          'name' => 'dimensions_received_value_c',
          'label' => 'LBL_DIMENSIONS_RECEIVED_VALUE',
          'enabled' => true,
          'related_fields' => 
          array (
            0 => 'currency_id',
            1 => 'base_rate',
          ),
          'currency_format' => true,
          'default' => true,
          'width' => 'xxsmall',
        ),
        9 => 
        array (
          'name' => 'check_received_value_c',
          'label' => 'LBL_CHECK_RECEIVED_VALUE',
          'enabled' => true,
          'width' => 'xxsmall',
          'default' => true,
        ),
        10 => 
        array (
          'name' => 'price_check_c',
          'label' => 'LBL_PRICE_CHECK',
          'enabled' => true,
          'default' => true,
        ),
        11 => 
        array (
          'name' => 'project_status_calc_c',
          'label' => 'LBL_PROJECT_STATUS_CALC',
          'enabled' => true,
          'default' => true,
        ),
        12 => 
        array (
          'name' => 'project_status_error_c',
          'label' => 'LBL_PROJECT_STATUS_ERROR',
          'enabled' => true,
          'sortable' => false,
          'default' => true,
        ),
        13 => 
        array (
          'name' => 'cancel_line_c',
          'label' => 'LBL_CANCEL_LINE',
          'enabled' => true,
          'default' => true,
        ),
      ),
    ),
  ),
  'type' => 'subpanel-list',
);