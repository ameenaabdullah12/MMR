<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => '分析師',
  'Competitor' => '競爭對手',
  'Customer' => '客戶',
  'Integrator' => '整合商',
  'Investor' => '投資者',
  'Partner' => '合作夥伴',
  'Press' => '新聞媒體',
  'Prospect' => '潛在客戶',
  'Reseller' => '經銷商',
  'Other' => '其他',
  '' => '',
);