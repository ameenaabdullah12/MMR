<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analist',
  'Competitor' => 'Concurrent',
  'Customer' => 'Klant',
  'Integrator' => 'Integreerder',
  'Investor' => 'Investeerder',
  'Partner' => 'Partner',
  'Press' => 'Pers',
  'Prospect' => 'Verwachting',
  'Reseller' => 'Wederverkoper',
  'Other' => 'Anders',
  '' => '',
);