<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analista',
  'Competitor' => 'Competidor',
  'Customer' => 'Cliente',
  'Integrator' => 'Integrador',
  'Investor' => 'Inversor',
  'Partner' => 'Socio',
  'Press' => 'Prensa',
  'Prospect' => 'Prospecto',
  'Reseller' => 'Revendedor',
  'Other' => 'Otro',
  '' => '',
);