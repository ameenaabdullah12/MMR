<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'นักวิเคราะห์',
  'Competitor' => 'คู่แข่ง',
  'Customer' => 'ลูกค้า',
  'Integrator' => 'ผู้รวมระบบ',
  'Investor' => 'นักลงทุน',
  'Partner' => 'คู่ค้า',
  'Press' => 'สื่อมวลชน',
  'Prospect' => 'ลูกค้าเป้าหมาย',
  'Reseller' => 'ผู้ค้าปลีก',
  'Other' => 'อื่นๆ',
  '' => '',
);