<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analista',
  'Competitor' => 'Competidor',
  'Customer' => 'Cliente',
  'Integrator' => 'Integrador',
  'Investor' => 'Inversor',
  'Partner' => 'Colaborador',
  'Press' => 'Prensa',
  'Prospect' => 'Prospecto',
  'Reseller' => 'Revendedor',
  'Other' => 'Otro',
  '' => '',
);