<?php
 // created: 2019-12-18 09:10:25
$dictionary['a_supplier']['fields']['on_stop_c']['labelValue']='On Stop?';
$dictionary['a_supplier']['fields']['on_stop_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['on_stop_c']['enforced']='';
$dictionary['a_supplier']['fields']['on_stop_c']['dependency']='';

 ?>