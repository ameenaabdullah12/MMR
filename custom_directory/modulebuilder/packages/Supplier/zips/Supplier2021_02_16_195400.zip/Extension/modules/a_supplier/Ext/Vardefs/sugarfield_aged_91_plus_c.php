<?php
 // created: 2019-12-18 09:05:23
$dictionary['a_supplier']['fields']['aged_91_plus_c']['labelValue']='Aged 91 Plus';
$dictionary['a_supplier']['fields']['aged_91_plus_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_91_plus_c']['dependency']='';

 ?>