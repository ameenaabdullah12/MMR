<?php
 // created: 2019-12-18 09:07:13
$dictionary['a_supplier']['fields']['dimensions_database_c']['labelValue']='Dimensions Database';
$dictionary['a_supplier']['fields']['dimensions_database_c']['dependency']='';
$dictionary['a_supplier']['fields']['dimensions_database_c']['visibility_grid']='';

 ?>