<?php
$dictionary['a_supplier']['fields']['a_default_currency'] = array (
	'required' => false,
	'name' => 'a_default_currency',
	'vname' => 'LBL_A_DEFAULT_CURRENCY',
	'type' => 'vatcurrencylookup',
	'dbtype' => 'varchar',
	'default' => '-99',
	'audited' => false,
	'merge_filter' => 'enabled',
	'len' => 100,
	'options' => '',
	'comment' => ''
);
?>
