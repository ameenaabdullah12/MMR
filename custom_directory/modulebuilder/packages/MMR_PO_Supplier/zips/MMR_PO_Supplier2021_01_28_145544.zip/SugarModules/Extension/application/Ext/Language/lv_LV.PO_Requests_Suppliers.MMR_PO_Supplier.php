<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analītiķis',
  'Competitor' => 'Konkurents',
  'Customer' => 'Klients',
  'Integrator' => 'Integrators',
  'Investor' => 'Investors',
  'Partner' => 'Partneris',
  'Press' => 'Prese',
  'Prospect' => 'Potenciāls klients',
  'Reseller' => 'Izplatītājs',
  'Other' => 'Cits',
  '' => '',
);