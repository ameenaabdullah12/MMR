<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Анализатор',
  'Competitor' => 'Конкурент',
  'Customer' => 'Клиент',
  'Integrator' => 'Интегратор',
  'Investor' => 'Инвеститор',
  'Partner' => 'Партньор',
  'Press' => 'Медиа',
  'Prospect' => 'В процес на преговори',
  'Reseller' => 'Дистрибутор',
  'Other' => 'Други',
  '' => '',
);