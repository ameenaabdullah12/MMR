<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analitičar',
  'Competitor' => 'Konkurent',
  'Customer' => 'Klijent',
  'Integrator' => 'Integrator',
  'Investor' => 'Investitor',
  'Partner' => 'Partner',
  'Press' => 'Tisak',
  'Prospect' => 'Potenc. klijent',
  'Reseller' => 'Prodavač',
  'Other' => 'Ostalo',
  '' => '',
);