<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'אנליסט',
  'Competitor' => 'מתחרה',
  'Customer' => 'לקוח',
  'Integrator' => 'אינטגרטור',
  'Investor' => 'משקיע',
  'Partner' => 'שותף',
  'Press' => 'עיתונות',
  'Prospect' => 'תחזית',
  'Reseller' => 'ריסיילר',
  'Other' => 'אחר',
  '' => '',
);