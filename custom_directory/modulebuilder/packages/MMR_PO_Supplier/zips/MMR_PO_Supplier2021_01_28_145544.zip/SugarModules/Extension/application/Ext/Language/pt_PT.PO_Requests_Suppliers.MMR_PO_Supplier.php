<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analista',
  'Competitor' => 'Concorrente',
  'Customer' => 'Cliente',
  'Integrator' => 'Integrador',
  'Investor' => 'Investidor',
  'Partner' => 'Parceiro',
  'Press' => 'Imprensa',
  'Prospect' => 'Potencial',
  'Reseller' => 'Revendedor',
  'Other' => 'Outro',
  '' => '',
);