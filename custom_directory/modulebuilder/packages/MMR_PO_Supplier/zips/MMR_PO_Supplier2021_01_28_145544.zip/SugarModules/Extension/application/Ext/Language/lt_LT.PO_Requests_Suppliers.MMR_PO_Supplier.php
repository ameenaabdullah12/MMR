<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analitikas',
  'Competitor' => 'Konkurentas',
  'Customer' => 'Klientas',
  'Integrator' => 'Integruotojas',
  'Investor' => 'Investuotojas',
  'Partner' => 'Partneris',
  'Press' => 'Press',
  'Prospect' => 'Perspektyva',
  'Reseller' => 'Pardavėjas',
  'Other' => 'Kita',
  '' => '',
);