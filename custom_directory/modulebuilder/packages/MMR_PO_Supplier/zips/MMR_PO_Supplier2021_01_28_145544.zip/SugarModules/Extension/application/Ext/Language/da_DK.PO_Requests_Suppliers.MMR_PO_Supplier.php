<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analytiker',
  'Competitor' => 'Konkurrent',
  'Customer' => 'Kunde',
  'Integrator' => 'Integrator',
  'Investor' => 'Investor',
  'Partner' => 'Partner',
  'Press' => 'Press',
  'Prospect' => 'Potentiel kunde',
  'Reseller' => 'Forhandler',
  'Other' => 'Andet',
  '' => '',
);