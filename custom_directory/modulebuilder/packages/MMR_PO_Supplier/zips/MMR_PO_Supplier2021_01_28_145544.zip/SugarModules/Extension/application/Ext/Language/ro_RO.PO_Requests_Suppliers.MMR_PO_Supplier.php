<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analist',
  'Competitor' => 'Concurent',
  'Customer' => 'Client',
  'Integrator' => 'Integrator',
  'Investor' => 'Investitor',
  'Partner' => 'Partener',
  'Press' => 'Presă',
  'Prospect' => 'Client potenţial',
  'Reseller' => 'Distribuitor',
  'Other' => 'Altul',
  '' => '',
);