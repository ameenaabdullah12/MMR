<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analytik',
  'Competitor' => 'Konkurencia',
  'Customer' => 'Zákazník',
  'Integrator' => 'Integrator',
  'Investor' => 'Investor',
  'Partner' => 'Partner',
  'Press' => 'Tlač',
  'Prospect' => 'Potenciálny zákazník',
  'Reseller' => 'Predajca',
  'Other' => 'Iné',
  '' => '',
);