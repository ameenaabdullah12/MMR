<?php
 // created: 2019-12-18 09:04:07
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['labelValue']='Aged 31 to 60';
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_31_to_60_c']['dependency']='';

 ?>