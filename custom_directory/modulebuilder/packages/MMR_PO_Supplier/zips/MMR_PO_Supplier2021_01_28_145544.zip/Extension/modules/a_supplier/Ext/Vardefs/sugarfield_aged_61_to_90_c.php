<?php
 // created: 2019-12-18 09:04:38
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['labelValue']='Aged 61 to 90';
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['enforced']='';
$dictionary['a_supplier']['fields']['aged_61_to_90_c']['dependency']='';

 ?>