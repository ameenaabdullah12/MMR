<?php
 // created: 2019-12-18 09:05:56
$dictionary['a_supplier']['fields']['balance_c']['labelValue']='Balance';
$dictionary['a_supplier']['fields']['balance_c']['enforced']='';
$dictionary['a_supplier']['fields']['balance_c']['dependency']='';

 ?>