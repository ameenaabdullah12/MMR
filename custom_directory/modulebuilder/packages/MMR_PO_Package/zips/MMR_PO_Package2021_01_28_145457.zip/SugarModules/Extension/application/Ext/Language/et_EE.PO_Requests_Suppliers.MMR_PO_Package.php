<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analüütik',
  'Competitor' => 'Konkurent',
  'Customer' => 'Klient',
  'Integrator' => 'Integraator',
  'Investor' => 'Investor',
  'Partner' => 'Partner',
  'Press' => 'Press',
  'Prospect' => 'Potentsiaalne klient',
  'Reseller' => 'Edasimüüja',
  'Other' => 'Muu',
  '' => '',
);