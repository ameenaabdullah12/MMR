<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'المحلل',
  'Competitor' => 'المنافس',
  'Customer' => 'العميل',
  'Integrator' => 'الموحد',
  'Investor' => 'المستثمر',
  'Partner' => 'الشريك',
  'Press' => 'الصحافه',
  'Prospect' => 'العميل المتوقع',
  'Reseller' => 'الموزع',
  'Other' => 'أخرى',
  '' => '',
);