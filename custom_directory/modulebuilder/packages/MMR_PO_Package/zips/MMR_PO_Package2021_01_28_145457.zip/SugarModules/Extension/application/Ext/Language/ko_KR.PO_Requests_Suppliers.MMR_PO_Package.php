<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => '분석가',
  'Competitor' => '경쟁업체',
  'Customer' => '소비자',
  'Integrator' => '통합자',
  'Investor' => '투자자',
  'Partner' => '협력자',
  'Press' => '누르기',
  'Prospect' => '예상',
  'Reseller' => '재판매자',
  'Other' => '기타',
  '' => '',
);