<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analist',
  'Competitor' => 'Konkurrent',
  'Customer' => 'Klient',
  'Integrator' => 'Llogaritar',
  'Investor' => 'Investitor',
  'Partner' => 'Partner',
  'Press' => 'Shtypi',
  'Prospect' => 'Perspektive',
  'Reseller' => 'Rishitës',
  'Other' => 'Tjetër',
  '' => '',
);