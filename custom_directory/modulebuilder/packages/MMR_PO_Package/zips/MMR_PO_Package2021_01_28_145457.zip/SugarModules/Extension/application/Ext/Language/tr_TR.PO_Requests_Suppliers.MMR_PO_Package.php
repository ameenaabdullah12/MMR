<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analist',
  'Competitor' => 'Rakip',
  'Customer' => 'Müşteri',
  'Integrator' => 'Entegratör',
  'Investor' => 'Yatırımcı',
  'Partner' => 'Ortak',
  'Press' => 'Basın',
  'Prospect' => 'Potansiyel Müşteri',
  'Reseller' => 'Satıcı',
  'Other' => 'Diğer',
  '' => '',
);