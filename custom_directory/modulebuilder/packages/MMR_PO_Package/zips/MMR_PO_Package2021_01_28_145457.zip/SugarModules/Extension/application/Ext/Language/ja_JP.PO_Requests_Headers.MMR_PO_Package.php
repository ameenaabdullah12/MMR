<?php 
$app_list_strings['b_po_header_type_dom'] = array (
  'Existing Business' => '既存ビジネス',
  'New Business' => '新規ビジネス',
  '' => '',
);