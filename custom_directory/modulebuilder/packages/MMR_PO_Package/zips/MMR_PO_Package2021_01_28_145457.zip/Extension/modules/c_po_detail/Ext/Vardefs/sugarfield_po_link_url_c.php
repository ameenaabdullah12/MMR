<?php
 // created: 2020-10-16 09:55:21
$dictionary['c_po_detail']['fields']['po_link_url_c']['labelValue']='po link url';
$dictionary['c_po_detail']['fields']['po_link_url_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['c_po_detail']['fields']['po_link_url_c']['dependency']='';

 ?>