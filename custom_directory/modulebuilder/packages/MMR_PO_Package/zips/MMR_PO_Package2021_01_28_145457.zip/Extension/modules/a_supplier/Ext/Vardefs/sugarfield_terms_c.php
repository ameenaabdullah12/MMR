<?php
 // created: 2019-12-18 09:11:07
$dictionary['a_supplier']['fields']['terms_c']['labelValue']='Terms';
$dictionary['a_supplier']['fields']['terms_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['terms_c']['enforced']='';
$dictionary['a_supplier']['fields']['terms_c']['dependency']='';

 ?>