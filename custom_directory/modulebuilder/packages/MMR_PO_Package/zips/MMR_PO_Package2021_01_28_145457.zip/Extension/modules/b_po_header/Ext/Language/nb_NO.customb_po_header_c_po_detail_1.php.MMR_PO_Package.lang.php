<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/b_po_header/Ext/Language/nb_NO.customb_po_header_c_po_detail_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Opportunities';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE'] = 'Suppliers';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Suppliers';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE'] = 'Purchase Order Details';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_B_PO_HEADER_TITLE'] = 'Purchase Order Details';

?>
<?php
// Merged from custom/Extension/modules/b_po_header/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Opportunities';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE'] = 'Suppliers';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Suppliers';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE'] = 'Purchase Order Details';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_B_PO_HEADER_TITLE'] = 'Purchase Order Details';

?>
