<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/a_supplier/Ext/Language/he_IL.customa_supplier_b_po_header_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Purchase Orders';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE'] = 'Purchase Orders';

?>
<?php
// Merged from custom/Extension/modules/a_supplier/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Purchase Orders';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE'] = 'Purchase Orders';

?>
