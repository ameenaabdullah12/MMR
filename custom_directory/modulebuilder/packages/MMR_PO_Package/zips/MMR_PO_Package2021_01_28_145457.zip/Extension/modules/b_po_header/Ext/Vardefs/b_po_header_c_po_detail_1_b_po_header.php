<?php
// created: 2019-12-18 15:27:03
$dictionary["b_po_header"]["fields"]["b_po_header_c_po_detail_1"] = array (
  'name' => 'b_po_header_c_po_detail_1',
  'type' => 'link',
  'relationship' => 'b_po_header_c_po_detail_1',
  'source' => 'non-db',
  'module' => 'c_po_detail',
  'bean_name' => 'c_po_detail',
  'vname' => 'LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_B_PO_HEADER_TITLE',
  'id_name' => 'b_po_header_c_po_detail_1b_po_header_ida',
  'link-type' => 'many',
  'side' => 'left',
);
