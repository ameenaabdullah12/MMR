<?php
 // created: 2020-04-16 14:06:33
$dictionary['b_po_header']['fields']['auto_number']['len']='11';
$dictionary['b_po_header']['fields']['auto_number']['audited']=false;
$dictionary['b_po_header']['fields']['auto_number']['massupdate']=false;
$dictionary['b_po_header']['fields']['auto_number']['comments']='Purchase Order Auto Number';
$dictionary['b_po_header']['fields']['auto_number']['merge_filter']='disabled';
$dictionary['b_po_header']['fields']['auto_number']['unified_search']=false;
$dictionary['b_po_header']['fields']['auto_number']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.25',
  'searchable' => true,
);
$dictionary['b_po_header']['fields']['auto_number']['calculated']=false;
$dictionary['b_po_header']['fields']['auto_number']['enable_range_search']=false;
$dictionary['b_po_header']['fields']['auto_number']['autoinc_next']='20';
$dictionary['b_po_header']['fields']['auto_number']['min']=false;
$dictionary['b_po_header']['fields']['auto_number']['max']=false;
$dictionary['b_po_header']['fields']['auto_number']['disable_num_format']='1';

 ?>