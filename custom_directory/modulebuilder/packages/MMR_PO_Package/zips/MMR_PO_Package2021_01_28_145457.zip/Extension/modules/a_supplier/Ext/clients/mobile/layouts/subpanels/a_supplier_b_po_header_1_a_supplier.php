<?php
// created: 2019-12-18 15:25:55
$viewdefs['a_supplier']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE',
  'context' => 
  array (
    'link' => 'a_supplier_b_po_header_1',
  ),
);