<?php
//auto-generated file DO NOT EDIT
$viewdefs['b_po_header']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'b_po_header_c_po_detail_1',
  'view' => 'subpanel-for-b_po_header-b_po_header_c_po_detail_1',
);
