<?php
//auto-generated file DO NOT EDIT
$layout_defs['b_po_header']['subpanel_setup']['b_po_header_c_po_detail_1']['override_subpanel_name'] = 'b_po_header_subpanel_b_po_header_c_po_detail_1';
?>