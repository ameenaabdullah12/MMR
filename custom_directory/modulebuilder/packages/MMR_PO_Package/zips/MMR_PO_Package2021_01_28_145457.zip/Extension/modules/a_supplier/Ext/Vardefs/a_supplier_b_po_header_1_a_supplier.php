<?php
// created: 2019-12-18 15:25:55
$dictionary["a_supplier"]["fields"]["a_supplier_b_po_header_1"] = array (
  'name' => 'a_supplier_b_po_header_1',
  'type' => 'link',
  'relationship' => 'a_supplier_b_po_header_1',
  'source' => 'non-db',
  'module' => 'b_po_header',
  'bean_name' => 'b_po_header',
  'vname' => 'LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE',
  'id_name' => 'a_supplier_b_po_header_1a_supplier_ida',
  'link-type' => 'many',
  'side' => 'left',
);
