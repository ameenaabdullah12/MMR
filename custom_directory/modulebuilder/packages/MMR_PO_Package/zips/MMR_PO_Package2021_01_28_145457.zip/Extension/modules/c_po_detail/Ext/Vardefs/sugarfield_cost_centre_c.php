<?php
 // created: 2020-04-30 09:57:42
$dictionary['c_po_detail']['fields']['cost_centre_c']['labelValue']='Cost Centre';
$dictionary['c_po_detail']['fields']['cost_centre_c']['dependency']='equal($c_po_detail_type,"Project")';
$dictionary['c_po_detail']['fields']['cost_centre_c']['visibility_grid']='';

 ?>