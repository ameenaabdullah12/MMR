<?php
 // created: 2019-12-18 15:27:03
$layout_defs["b_po_header"]["subpanel_setup"]['b_po_header_c_po_detail_1'] = array (
  'order' => 100,
  'module' => 'c_po_detail',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE',
  'get_subpanel_data' => 'b_po_header_c_po_detail_1',
);
