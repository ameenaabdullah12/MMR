<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/c_po_detail/Ext/Language/uk_UA.customb_po_header_c_po_detail_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_C_PO_DETAIL_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE'] = 'Opportunities';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_B_PO_HEADER_TITLE'] = 'Purchase Orders';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE'] = 'Purchase Orders';

?>
<?php
// Merged from custom/Extension/modules/c_po_detail/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_C_PO_DETAIL_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE'] = 'Opportunities';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_B_PO_HEADER_TITLE'] = 'Purchase Orders';
$mod_strings['LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE'] = 'Purchase Orders';

?>
