<?php
 // created: 2019-12-18 14:18:18
$dictionary['b_po_header']['fields']['po_date_c']['labelValue']='PO Date';
$dictionary['b_po_header']['fields']['po_date_c']['enforced']='';
$dictionary['b_po_header']['fields']['po_date_c']['dependency']='';

 ?>