<?php
// created: 2019-12-18 15:27:03
$viewdefs['b_po_header']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_B_PO_HEADER_C_PO_DETAIL_1_FROM_C_PO_DETAIL_TITLE',
  'context' => 
  array (
    'link' => 'b_po_header_c_po_detail_1',
  ),
);