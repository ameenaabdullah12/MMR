<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/b_po_header/Ext/Language/it_it.customa_supplier_b_po_header_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Opportunities';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE'] = 'Suppliers';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Suppliers';

?>
<?php
// Merged from custom/Extension/modules/b_po_header/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Opportunities';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_A_SUPPLIER_TITLE'] = 'Suppliers';
$mod_strings['LBL_A_SUPPLIER_B_PO_HEADER_1_FROM_B_PO_HEADER_TITLE'] = 'Suppliers';

?>
