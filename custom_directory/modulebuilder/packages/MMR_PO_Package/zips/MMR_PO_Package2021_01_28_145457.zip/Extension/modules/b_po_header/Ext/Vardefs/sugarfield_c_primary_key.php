<?php
 // created: 2020-10-28 23:29:24
$dictionary['b_po_header']['fields']['c_primary_key']['audited']=true;

 ?>