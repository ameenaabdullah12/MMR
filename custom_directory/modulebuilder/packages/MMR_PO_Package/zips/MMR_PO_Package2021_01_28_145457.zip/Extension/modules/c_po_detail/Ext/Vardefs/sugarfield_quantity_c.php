<?php
 // created: 2020-02-06 16:18:59
$dictionary['c_po_detail']['fields']['quantity_c']['duplicate_merge_dom_value']=0;
$dictionary['c_po_detail']['fields']['quantity_c']['labelValue']='Quantity';
$dictionary['c_po_detail']['fields']['quantity_c']['calculated']='true';
$dictionary['c_po_detail']['fields']['quantity_c']['formula']='1.0';
$dictionary['c_po_detail']['fields']['quantity_c']['enforced']='true';
$dictionary['c_po_detail']['fields']['quantity_c']['dependency']='';

 ?>