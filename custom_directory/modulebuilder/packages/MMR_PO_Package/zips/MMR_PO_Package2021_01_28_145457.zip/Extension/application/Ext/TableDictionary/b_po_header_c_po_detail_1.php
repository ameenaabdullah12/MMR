<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/b_po_header_c_po_detail_1MetaData.php');

?>