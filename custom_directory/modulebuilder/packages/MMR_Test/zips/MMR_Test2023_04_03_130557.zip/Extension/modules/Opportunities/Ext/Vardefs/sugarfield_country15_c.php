<?php
 // created: 2017-09-13 12:38:07
$dictionary['Opportunity']['fields']['country15_c']['labelValue']='Country 15';
$dictionary['Opportunity']['fields']['country15_c']['dependency']='greaterThan(strlen($country14_c),0)';
$dictionary['Opportunity']['fields']['country15_c']['visibility_grid']='';

 ?>