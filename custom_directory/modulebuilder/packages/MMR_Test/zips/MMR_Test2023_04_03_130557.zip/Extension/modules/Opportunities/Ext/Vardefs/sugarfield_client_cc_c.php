<?php
 // created: 2023-02-06 18:32:54
$dictionary['Opportunity']['fields']['client_cc_c']['labelValue']='Client Consumer Centre';
$dictionary['Opportunity']['fields']['client_cc_c']['dependency']='';
$dictionary['Opportunity']['fields']['client_cc_c']['visibility_grid']=array (
  'trigger' => 'project_function_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Quant' => 
    array (
    ),
    'Qual' => 
    array (
    ),
    'Sensory_Qual' => 
    array (
    ),
    'Sensory' => 
    array (
    ),
    'Client_CC' => 
    array (
      0 => '',
      1 => 'CIC',
      2 => 'GIC',
    ),
  ),
);

 ?>