<?php
// created: 2017-06-30 15:14:59
$dictionary["Opportunity"]["fields"]["udef_detailcosts_opportunities"] = array (
  'name' => 'udef_detailcosts_opportunities',
  'type' => 'link',
  'relationship' => 'udef_detailcosts_opportunities',
  'source' => 'non-db',
  'module' => 'udef_detailcosts',
  'bean_name' => 'udef_detailcosts',
  'vname' => 'LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'udef_detailcosts_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
