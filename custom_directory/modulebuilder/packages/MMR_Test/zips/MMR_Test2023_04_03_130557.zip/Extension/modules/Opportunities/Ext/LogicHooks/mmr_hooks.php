<?php

$hook_array['before_save'][] = Array(150,'Update record to sync','custom/modules/Opportunities/opp_hooks.php','updateOpportunity','update_record_to_sync');
