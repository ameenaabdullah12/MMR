<?php
 // created: 2022-05-17 12:54:53
$dictionary['Opportunity']['fields']['sensorymethod_yesno_c']['labelValue']='Sensory Qual methods required?';
$dictionary['Opportunity']['fields']['sensorymethod_yesno_c']['dependency']='';
$dictionary['Opportunity']['fields']['sensorymethod_yesno_c']['visibility_grid']=array (
  'trigger' => 'sensoryqualyesno_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Yes' => 
    array (
      0 => 'Yes',
      1 => 'No',
    ),
    'No' => 
    array (
      0 => 'No',
    ),
  ),
);

 ?>