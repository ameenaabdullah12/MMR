<?php
 // created: 2017-10-05 13:24:49
$dictionary['Opportunity']['fields']['csq_answering_objectives_c']['labelValue']='Answering objectives';
$dictionary['Opportunity']['fields']['csq_answering_objectives_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_answering_objectives_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_answering_objectives_c']['dependency']='';

 ?>