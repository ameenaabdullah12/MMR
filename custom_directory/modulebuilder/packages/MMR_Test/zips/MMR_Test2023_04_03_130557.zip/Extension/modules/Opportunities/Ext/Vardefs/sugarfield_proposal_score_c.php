<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['proposal_score_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['proposal_score_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['proposal_score_c']['calculated']='1';
$dictionary['Opportunity']['fields']['proposal_score_c']['formula']='add(number($make_case_study_c),number($noteworthy_brand_c),$account_life_stage_c,ifElse(greaterThan($grossprofit_estimate_gbp_c,50000),3,ifElse(greaterThan($grossprofit_estimate_gbp_c,15000),2,1)))';
$dictionary['Opportunity']['fields']['proposal_score_c']['enforced']='1';
$dictionary['Opportunity']['fields']['proposal_score_c']['dependency']='';

 ?>