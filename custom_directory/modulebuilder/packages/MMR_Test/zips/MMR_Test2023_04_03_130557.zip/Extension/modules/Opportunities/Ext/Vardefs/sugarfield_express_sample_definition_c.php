<?php
 // created: 2018-08-07 08:51:42
$dictionary['Opportunity']['fields']['express_sample_definition_c']['labelValue']='express sample definition';
$dictionary['Opportunity']['fields']['express_sample_definition_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['express_sample_definition_c']['enforced']='';
$dictionary['Opportunity']['fields']['express_sample_definition_c']['dependency']='';

 ?>