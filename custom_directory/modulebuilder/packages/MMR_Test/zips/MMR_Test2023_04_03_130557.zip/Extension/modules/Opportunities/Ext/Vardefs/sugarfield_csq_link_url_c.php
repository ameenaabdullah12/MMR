<?php
 // created: 2023-01-05 15:23:36
$dictionary['Opportunity']['fields']['csq_link_url_c']['labelValue']='csq link url';
$dictionary['Opportunity']['fields']['csq_link_url_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_link_url_c']['dependency']='';

 ?>