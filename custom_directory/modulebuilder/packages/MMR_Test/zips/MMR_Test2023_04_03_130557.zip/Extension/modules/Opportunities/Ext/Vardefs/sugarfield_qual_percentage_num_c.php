<?php
 // created: 2017-08-22 17:30:57
$dictionary['Opportunity']['fields']['qual_percentage_num_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['qual_percentage_num_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['qual_percentage_num_c']['calculated']='1';
$dictionary['Opportunity']['fields']['qual_percentage_num_c']['formula']='$qual_percent_c';
$dictionary['Opportunity']['fields']['qual_percentage_num_c']['enforced']='1';
$dictionary['Opportunity']['fields']['qual_percentage_num_c']['dependency']='';

 ?>