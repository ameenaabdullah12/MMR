<?php
 // created: 2017-09-11 12:04:12
$dictionary['Opportunity']['fields']['actual_sales_gbp_c']['labelValue']='Sales Value GBP';
$dictionary['Opportunity']['fields']['actual_sales_gbp_c']['enforced']='';

 ?>