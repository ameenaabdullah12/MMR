<?php
 // created: 2018-08-07 08:50:12
$dictionary['Opportunity']['fields']['express_number_of_concepts_c']['labelValue']='express number of concepts';
$dictionary['Opportunity']['fields']['express_number_of_concepts_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['express_number_of_concepts_c']['enforced']='';
$dictionary['Opportunity']['fields']['express_number_of_concepts_c']['dependency']='';

 ?>