<?php
 // created: 2017-09-13 12:28:45
$dictionary['Opportunity']['fields']['country6_c']['labelValue']='Country 6';
$dictionary['Opportunity']['fields']['country6_c']['dependency']='greaterThan(strlen($country5_c),0)';
$dictionary['Opportunity']['fields']['country6_c']['visibility_grid']='';

 ?>