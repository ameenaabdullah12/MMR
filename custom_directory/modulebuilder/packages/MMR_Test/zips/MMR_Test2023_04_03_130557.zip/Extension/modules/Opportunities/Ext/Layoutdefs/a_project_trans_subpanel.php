<?php
 
$layout_defs['Opportunities']['subpanel_setup']['a_project_trans'] = array(
    'order'             => 130,
    'module'            => 'a_project_trans',
    'get_subpanel_data' => 'a_project_trans',
    'sort_order'        => 'asc',
    'sort_by'           => 'cost_centre_code',
    'subpanel_name'     => 'Opportunities_subpanel_a_project_trans',
    'title_key'         => 'LBL_A_PROJECT_TRANS_SUBPANEL_TITLE',
    'top_buttons'       => array (
    ),
);