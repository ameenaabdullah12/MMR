<?php
 // created: 2018-03-09 13:36:13
$dictionary['Opportunity']['fields']['sensory_qual_c']['labelValue']='Sensory Qual?';
$dictionary['Opportunity']['fields']['sensory_qual_c']['enforced']='';
$dictionary['Opportunity']['fields']['sensory_qual_c']['dependency']='';

 ?>