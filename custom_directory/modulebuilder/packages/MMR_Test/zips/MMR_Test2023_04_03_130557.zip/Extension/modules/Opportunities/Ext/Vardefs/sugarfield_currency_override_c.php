<?php
 // created: 2021-01-07 13:51:15
$dictionary['Opportunity']['fields']['currency_override_c']['labelValue']='Currency Override';
$dictionary['Opportunity']['fields']['currency_override_c']['enforced']='';
$dictionary['Opportunity']['fields']['currency_override_c']['dependency']='';
$dictionary['Opportunity']['fields']['currency_override_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>