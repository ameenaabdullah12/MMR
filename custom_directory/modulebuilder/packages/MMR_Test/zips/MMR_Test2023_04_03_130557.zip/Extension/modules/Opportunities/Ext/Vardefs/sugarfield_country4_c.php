<?php
 // created: 2017-09-13 12:27:10
$dictionary['Opportunity']['fields']['country4_c']['labelValue']='Country 4';
$dictionary['Opportunity']['fields']['country4_c']['dependency']='greaterThan(strlen($country3_c),0)';
$dictionary['Opportunity']['fields']['country4_c']['visibility_grid']='';

 ?>