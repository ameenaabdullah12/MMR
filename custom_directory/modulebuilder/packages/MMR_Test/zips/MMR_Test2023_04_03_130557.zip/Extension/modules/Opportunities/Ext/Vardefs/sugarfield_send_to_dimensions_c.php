<?php
 // created: 2017-08-22 17:30:58
$dictionary['Opportunity']['fields']['send_to_dimensions_c']['enforced']='';
$dictionary['Opportunity']['fields']['send_to_dimensions_c']['dependency']='';

 ?>