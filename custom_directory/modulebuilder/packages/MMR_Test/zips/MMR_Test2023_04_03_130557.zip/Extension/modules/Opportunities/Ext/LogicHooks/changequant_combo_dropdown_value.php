<?php

$hook_array['after_save'][] = array(
    1,
    'after_save example',
    'custom/modules/Opportunities/change_quant_combo_dropdown_value.php',
    'change_quant_combo_dropdown_value',
    'change_quant_combo_dropdown_value'
);
