<?php
 // created: 2022-10-11 11:07:04
$dictionary['Opportunity']['fields']['contractyesno_c']['labelValue']='Client Managed?';
$dictionary['Opportunity']['fields']['contractyesno_c']['dependency']='equal($expert_sensory_checkbox_c,true)';
$dictionary['Opportunity']['fields']['contractyesno_c']['visibility_grid']='';

 ?>