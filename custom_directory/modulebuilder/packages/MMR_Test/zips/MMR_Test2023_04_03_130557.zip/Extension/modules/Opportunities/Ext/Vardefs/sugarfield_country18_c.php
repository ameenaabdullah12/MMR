<?php
 // created: 2017-09-13 12:39:37
$dictionary['Opportunity']['fields']['country18_c']['labelValue']='Country 18';
$dictionary['Opportunity']['fields']['country18_c']['dependency']='greaterThan(strlen($country17_c),0)';
$dictionary['Opportunity']['fields']['country18_c']['visibility_grid']='';

 ?>