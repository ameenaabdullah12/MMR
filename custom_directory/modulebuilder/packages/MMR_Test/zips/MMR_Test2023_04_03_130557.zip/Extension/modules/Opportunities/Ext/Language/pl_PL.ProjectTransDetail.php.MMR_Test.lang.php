<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/pl_PL.ProjectTransDetail.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/pl_PL.ProjectTransDetail.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_UDEF_DETAILSALES_TITLE'] = 'Project sales';
$mod_strings['LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_UDEF_DETAILPENDING_TITLE'] = 'Project outstanding';
$mod_strings['LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_UDEF_DETAILCOSTS_TITLE'] = 'Project costs';

?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_UDEF_DETAILSALES_TITLE'] = 'Project sales';
$mod_strings['LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_UDEF_DETAILPENDING_TITLE'] = 'Project outstanding';
$mod_strings['LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_UDEF_DETAILCOSTS_TITLE'] = 'Project costs';


?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_UDEF_DETAILSALES_TITLE'] = 'Project sales';
$mod_strings['LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_UDEF_DETAILPENDING_TITLE'] = 'Project outstanding';
$mod_strings['LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Projects';
$mod_strings['LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_UDEF_DETAILCOSTS_TITLE'] = 'Project costs';

?>
