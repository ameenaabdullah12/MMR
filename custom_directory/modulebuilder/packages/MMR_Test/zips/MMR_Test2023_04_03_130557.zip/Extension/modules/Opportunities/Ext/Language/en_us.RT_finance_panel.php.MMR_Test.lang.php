<?php
$mod_strings['LBL_RT_FOR_FINANCE_USE']='For Finance Use';
$mod_strings['LBL_SEND_INVOICING_REMINDER_C']='Send invoicing reminder?';