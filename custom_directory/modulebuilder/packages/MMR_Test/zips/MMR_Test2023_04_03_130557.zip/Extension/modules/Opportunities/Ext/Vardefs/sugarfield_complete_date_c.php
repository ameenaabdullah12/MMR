<?php
 // created: 2018-06-04 13:57:49
$dictionary['Opportunity']['fields']['complete_date_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['complete_date_c']['labelValue']='Complete Date';
$dictionary['Opportunity']['fields']['complete_date_c']['enforced']='';
$dictionary['Opportunity']['fields']['complete_date_c']['dependency']='';
$dictionary['Opportunity']['fields']['complete_date_c']['enable_range_search']='1';

 ?>