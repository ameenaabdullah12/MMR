<?php
 // created: 2022-05-16 09:10:44
$dictionary['Opportunity']['fields']['qual_quant_express_combo_c']['massupdate']=false;
$dictionary['Opportunity']['fields']['qual_quant_express_combo_c']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['qual_quant_express_combo_c']['duplicate_merge_dom_value']='0';
$dictionary['Opportunity']['fields']['qual_quant_express_combo_c']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['qual_quant_express_combo_c']['calculated']=false;
$dictionary['Opportunity']['fields']['qual_quant_express_combo_c']['dependency']=false;

 ?>