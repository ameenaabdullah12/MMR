<?php
 // created: 2021-10-21 15:44:23
$dictionary['Opportunity']['fields']['import_tag_c']['labelValue']='Import Tag';
$dictionary['Opportunity']['fields']['import_tag_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['import_tag_c']['enforced']='';
$dictionary['Opportunity']['fields']['import_tag_c']['dependency']='';

 ?>