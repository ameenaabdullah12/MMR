<?php
 // created: 2018-02-08 16:04:08
$dictionary['Opportunity']['fields']['currency_display_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['currency_display_c']['labelValue']='Currency Display';
$dictionary['Opportunity']['fields']['currency_display_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['currency_display_c']['calculated']='1';
$dictionary['Opportunity']['fields']['currency_display_c']['formula']='related($currencies,"symbol")';
$dictionary['Opportunity']['fields']['currency_display_c']['enforced']='1';

 ?>