<?php
 // created: 2022-01-11 13:41:52
$dictionary['Opportunity']['fields']['defined_methods_c']['labelValue']='Defined Methods';
$dictionary['Opportunity']['fields']['defined_methods_c']['dependency']='and(isInList($sales_stage,createList("Posted Proposal","Commissioned","Closed (Debriefed)","Closed (Fully Invoiced)")),isInList($mmr_group_lead_c,createList("","MMR","Huxly")))';
$dictionary['Opportunity']['fields']['defined_methods_c']['visibility_grid']='';

 ?>