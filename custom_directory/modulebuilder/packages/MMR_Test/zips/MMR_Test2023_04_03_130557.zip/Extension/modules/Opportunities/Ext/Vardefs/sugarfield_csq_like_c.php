<?php
 // created: 2017-09-26 09:42:36
$dictionary['Opportunity']['fields']['csq_like_c']['labelValue']='What do you particularly like about working with MMR?';
$dictionary['Opportunity']['fields']['csq_like_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_like_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_like_c']['dependency']='';

 ?>