<?php
// created: 2015-08-28 16:55:03
$layout_defs["Opportunities"]["subpanel_setup"]['docusign_status_cases'] = array(
    'order'             => 100,
    'module'            => 'WSYS_docusign_status',
    'subpanel_name'     => 'default',
    'sort_order'        => 'asc',
    'sort_by'           => 'id',
    'title_key'         => 'LBL_DOCUSIGN_STATUS_OPPORTUNITIES_FROM_WSYS_DOCUSIGN_STATUS_TITLE',
    'get_subpanel_data' => 'docusign_status_opportunities',
    'top_buttons'       => array(
        0 => array(
            'widget_class' => 'SubPanelTopSelectButton',
            'mode'         => 'MultiSelect',
        ),
        1 => array(
            'widget_class' => 'SubPanelTopButtonQuickCreate',
        ),
    ),
);
