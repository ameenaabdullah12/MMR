<?php
 // created: 2018-08-07 08:50:51
$dictionary['Opportunity']['fields']['express_sample_sizes_c']['labelValue']='express sample sizes';
$dictionary['Opportunity']['fields']['express_sample_sizes_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['express_sample_sizes_c']['enforced']='';
$dictionary['Opportunity']['fields']['express_sample_sizes_c']['dependency']='';

 ?>