<?php
 // created: 2021-09-23 12:43:47
$dictionary['Opportunity']['fields']['next_step_history_c']['labelValue']='Next Step History';
$dictionary['Opportunity']['fields']['next_step_history_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['next_step_history_c']['enforced']='';
$dictionary['Opportunity']['fields']['next_step_history_c']['dependency']='';

 ?>