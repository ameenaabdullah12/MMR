<?php
 // created: 2021-03-23 12:23:25
$dictionary['Opportunity']['fields']['mmr_project_lead_c']['labelValue']='Did the project come from an MMR lead?';
$dictionary['Opportunity']['fields']['mmr_project_lead_c']['dependency']='';
$dictionary['Opportunity']['fields']['mmr_project_lead_c']['visibility_grid']=array (
  'trigger' => 'mmr_group_lead_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'MMR' => 
    array (
    ),
    'Cubo' => 
    array (
    ),
    'Huxly' => 
    array (
      0 => '',
      1 => 'Yes',
      2 => 'No',
    ),
  ),
);

 ?>