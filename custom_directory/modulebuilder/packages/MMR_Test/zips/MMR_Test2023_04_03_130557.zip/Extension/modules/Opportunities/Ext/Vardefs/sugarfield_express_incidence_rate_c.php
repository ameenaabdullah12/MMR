<?php
 // created: 2018-08-07 08:52:06
$dictionary['Opportunity']['fields']['express_incidence_rate_c']['labelValue']='express incidence rate';
$dictionary['Opportunity']['fields']['express_incidence_rate_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['express_incidence_rate_c']['enforced']='';
$dictionary['Opportunity']['fields']['express_incidence_rate_c']['dependency']='';

 ?>