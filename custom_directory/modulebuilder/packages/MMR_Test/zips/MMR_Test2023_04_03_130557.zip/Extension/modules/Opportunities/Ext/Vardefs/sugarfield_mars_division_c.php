<?php
 // created: 2023-02-06 18:02:43
$dictionary['Opportunity']['fields']['mars_division_c']['labelValue']='Mars Division';
$dictionary['Opportunity']['fields']['mars_division_c']['dependency']='equal(related($accounts,"name"),"MARS")';
$dictionary['Opportunity']['fields']['mars_division_c']['visibility_grid']='';

 ?>