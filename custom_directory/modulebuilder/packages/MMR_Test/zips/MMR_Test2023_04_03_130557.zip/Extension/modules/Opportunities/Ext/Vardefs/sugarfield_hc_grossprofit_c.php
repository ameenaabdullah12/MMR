<?php
 // created: 2021-12-02 15:10:04
$dictionary['Opportunity']['fields']['hc_grossprofit_c']['labelValue']='Gross Profit (home currency)';
$dictionary['Opportunity']['fields']['hc_grossprofit_c']['enforced']='';
$dictionary['Opportunity']['fields']['hc_grossprofit_c']['dependency']='';

 ?>