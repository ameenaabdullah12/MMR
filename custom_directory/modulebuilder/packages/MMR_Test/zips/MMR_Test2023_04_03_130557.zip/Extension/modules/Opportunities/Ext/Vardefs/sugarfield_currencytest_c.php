<?php
 // created: 2018-02-09 09:17:49
$dictionary['Opportunity']['fields']['currencytest_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['currencytest_c']['labelValue']='currencytest';
$dictionary['Opportunity']['fields']['currencytest_c']['calculated']='true';
$dictionary['Opportunity']['fields']['currencytest_c']['formula']='$grossprofit_display_c';
$dictionary['Opportunity']['fields']['currencytest_c']['enforced']='true';
$dictionary['Opportunity']['fields']['currencytest_c']['dependency']='';
$dictionary['Opportunity']['fields']['currencytest_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>