<?php
$mod_strings['LBL_QUAL_QUANT_EXPRESS_COMBO'] = 'qual_quant_express_combo';
