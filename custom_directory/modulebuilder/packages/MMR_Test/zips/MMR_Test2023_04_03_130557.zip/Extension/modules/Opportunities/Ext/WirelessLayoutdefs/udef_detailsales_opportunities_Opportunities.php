<?php
 // created: 2017-06-30 15:14:59
$layout_defs["Opportunities"]["subpanel_setup"]['udef_detailsales_opportunities'] = array (
  'order' => 100,
  'module' => 'udef_detailsales',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_UDEF_DETAILSALES_TITLE',
  'get_subpanel_data' => 'udef_detailsales_opportunities',
);
