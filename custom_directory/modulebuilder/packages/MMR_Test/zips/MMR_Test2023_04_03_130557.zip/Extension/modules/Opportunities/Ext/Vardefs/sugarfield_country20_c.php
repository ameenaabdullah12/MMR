<?php
 // created: 2017-09-13 12:40:34
$dictionary['Opportunity']['fields']['country20_c']['labelValue']='Country 20';
$dictionary['Opportunity']['fields']['country20_c']['dependency']='greaterThan(strlen($country19_c),0)';
$dictionary['Opportunity']['fields']['country20_c']['visibility_grid']='';

 ?>