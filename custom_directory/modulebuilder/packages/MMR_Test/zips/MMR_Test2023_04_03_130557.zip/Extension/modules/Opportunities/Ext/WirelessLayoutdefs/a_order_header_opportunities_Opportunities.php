<?php
 // created: 2012-11-08 14:03:00
$layout_defs["Opportunities"]["subpanel_setup"]['a_order_header_opportunities'] = array (
  'order' => 100,
  'module' => 'a_order_header',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_A_ORDER_HEADER_OPPORTUNITIES_FROM_A_ORDER_HEADER_TITLE',
  'get_subpanel_data' => 'a_order_header_opportunities',
);
