<?php
 // created: 2022-06-16 12:20:45
$dictionary['Opportunity']['fields']['nova_research_method_c']['labelValue']='Select Nova Research Methodology:';
$dictionary['Opportunity']['fields']['nova_research_method_c']['dependency']='';
$dictionary['Opportunity']['fields']['nova_research_method_c']['visibility_grid']=array (
  'trigger' => 'novayesno_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Yes' => 
    array (
      0 => '',
      1 => 'AR_VR',
      2 => 'Chatbot',
      3 => 'Esync web scraping',
      4 => 'NLP',
      5 => 'Passive metering',
      6 => 'Remesh',
      7 => 'Smart labels',
      8 => 'Voice',
      9 => 'Other',
    ),
    'No' => 
    array (
    ),
  ),
);

 ?>