<?php

$mod_strings['LBL_FILTER_OPPORTUNITY_LIVE'] = 'Active Commissioned Projects';

