<?php
 // created: 2020-10-01 15:31:06
$dictionary['Opportunity']['fields']['commissioned_financial_year_c']['labelValue']='Commissioned Financial Year';
$dictionary['Opportunity']['fields']['commissioned_financial_year_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['commissioned_financial_year_c']['enforced']='';

 ?>