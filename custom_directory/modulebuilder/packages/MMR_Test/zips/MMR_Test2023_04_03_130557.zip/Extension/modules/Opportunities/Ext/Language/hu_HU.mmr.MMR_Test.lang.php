<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_OPPORTUNITIES_PRODUCTS_1_FROM_PRODUCTS_TITLE'] = 'Products';
$mod_strings['LBL_OPPORTUNITIES_A_INVOICEREQUEST_1_FROM_A_INVOICEREQUEST_TITLE'] = 'Invoice Request';
$mod_strings['LBL_A_ORDER_HEADER_OPPORTUNITIES_FROM_A_ORDER_HEADER_TITLE'] = 'Order Header';
$mod_strings['LBL_OPPORTUNITIES_USERS_1_FROM_USERS_TITLE'] = 'Project Team';
$mod_strings['LBL_CONTACTS_OPPORTUNITIES_1_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_MODULE_NAME'] = 'Projects';
