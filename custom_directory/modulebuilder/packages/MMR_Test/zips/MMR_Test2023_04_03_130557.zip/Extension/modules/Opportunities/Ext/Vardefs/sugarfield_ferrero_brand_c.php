<?php
 // created: 2023-02-06 17:59:46
$dictionary['Opportunity']['fields']['ferrero_brand_c']['labelValue']='Select Ferrero brand(s):';
$dictionary['Opportunity']['fields']['ferrero_brand_c']['dependency']='equal(related($accounts,"name"),"FERRERO")';
$dictionary['Opportunity']['fields']['ferrero_brand_c']['visibility_grid']='';

 ?>