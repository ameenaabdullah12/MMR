<?php
 // created: 2017-09-11 12:03:25
$dictionary['Opportunity']['fields']['direct_costs_c']['labelValue']='Direct Costs';
$dictionary['Opportunity']['fields']['direct_costs_c']['enforced']='';

 ?>