<?php
 // created: 2019-07-24 15:55:30
$dictionary['Opportunity']['fields']['qual_percent_from_cost_sheet_c']['labelValue']='qual percent from cost sheet';
$dictionary['Opportunity']['fields']['qual_percent_from_cost_sheet_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['qual_percent_from_cost_sheet_c']['enforced']='';
$dictionary['Opportunity']['fields']['qual_percent_from_cost_sheet_c']['dependency']='';

 ?>