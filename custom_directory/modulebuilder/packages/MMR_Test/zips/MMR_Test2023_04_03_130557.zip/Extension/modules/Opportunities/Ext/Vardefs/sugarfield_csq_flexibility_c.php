<?php
 // created: 2020-07-30 08:02:04
$dictionary['Opportunity']['fields']['csq_flexibility_c']['labelValue']='Flexibility in meeting your needs';
$dictionary['Opportunity']['fields']['csq_flexibility_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_flexibility_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_flexibility_c']['dependency']='';

 ?>