<?php
 // created: 2018-06-14 10:54:53
$dictionary['Opportunity']['fields']['actual_sales_c']['labelValue']='Sales Value';
$dictionary['Opportunity']['fields']['actual_sales_c']['enforced']='';
$dictionary['Opportunity']['fields']['actual_sales_c']['dependency']='';
$dictionary['Opportunity']['fields']['actual_sales_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>