<?php
 // created: 2023-03-27 16:34:46
$dictionary['Opportunity']['fields']['default_dim_db_c']['labelValue']='Default Dimensions database';
$dictionary['Opportunity']['fields']['default_dim_db_c']['dependency']='';
$dictionary['Opportunity']['fields']['default_dim_db_c']['visibility_grid']=array (
  'trigger' => 'mmr_group_lead_c',
  'values' => 
  array (
    '' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'MMR' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
    ),
    'Cubo' => 
    array (
      0 => 'Cubo',
    ),
    'Huxly' => 
    array (
      0 => '',
      1 => 'UK',
      2 => 'US',
      3 => 'CHINA',
    ),
    'Together' => 
    array (
      0 => 'TOG',
    ),
    'Birch' => 
    array (
      0 => 'UK',
    ),
    'Chestnut_New' => 
    array (
      0 => 'UK',
    ),
    'Dragon' => 
    array (
      0 => 'UK',
    ),
    'Poplar' => 
    array (
      0 => 'UK',
    ),
    'Monkey Puzzle' => 
    array (
      0 => 'UK',
    ),
    'Aspen' => 
    array (
      0 => 'UK',
    ),
    'Cherry' => 
    array (
      0 => 'UK',
    ),
    'Cypress' => 
    array (
      0 => 'UK',
    ),
    'Elm New' => 
    array (
      0 => 'UK',
    ),
    'Hazel' => 
    array (
      0 => 'UK',
    ),
    'Pine_New' => 
    array (
      0 => 'UK',
    ),
    'Oak_New' => 
    array (
      0 => 'UK',
    ),
    'Mango' => 
    array (
      0 => 'UK',
    ),
    'Palm' => 
    array (
      0 => 'UK',
    ),
    'Juniper' => 
    array (
      0 => 'UK',
    ),
    'Plane' => 
    array (
      0 => 'UK',
    ),
    'Unallocated' => 
    array (
    ),
    'Bus_Dev' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'Incremental Express' => 
    array (
    ),
    'Huxly US' => 
    array (
      0 => 'US',
    ),
    'Empire' => 
    array (
      0 => 'US',
    ),
    'USSensory' => 
    array (
      0 => 'US',
    ),
    'CIC' => 
    array (
      0 => 'US',
    ),
    'GIC' => 
    array (
      0 => 'US',
    ),
    'Dogwood' => 
    array (
    ),
    'samauma' => 
    array (
      0 => 'BR',
    ),
    'Willow' => 
    array (
      0 => 'CHINA',
    ),
    'Tembusu' => 
    array (
      0 => 'CHINA',
    ),
    'Pipal' => 
    array (
      0 => 'CHINA',
    ),
    'Baobab' => 
    array (
      0 => 'UK',
    ),
    'Marketing' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'Group' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'Automation' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'NOVA' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'DO_NOT_USE_BELOW' => 
    array (
    ),
    'Beech' => 
    array (
    ),
    'Cedar' => 
    array (
      0 => 'UK',
    ),
    'Eucalyptus' => 
    array (
      0 => 'UK',
    ),
    'Brandphonics' => 
    array (
    ),
    'TopGun' => 
    array (
    ),
    'Qual' => 
    array (
      0 => '',
      1 => 'US',
      2 => 'CHINA',
      3 => 'BR',
      4 => 'UK',
      5 => 'SA',
    ),
    'Roadhouse' => 
    array (
    ),
    'BusDev' => 
    array (
    ),
    'Spruce' => 
    array (
    ),
    'Maple_New' => 
    array (
    ),
    'Redwood' => 
    array (
    ),
    'USQual' => 
    array (
      0 => 'US',
    ),
    'BladeRunner' => 
    array (
    ),
    'Chestnut' => 
    array (
    ),
    'Oak' => 
    array (
    ),
    'Pine' => 
    array (
    ),
  ),
);

 ?>