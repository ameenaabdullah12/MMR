<?php
// created: 2017-01-04 14:36:58
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_A_PROJECT_TRANSACTION_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_a_project_transaction_1',
  ),
);