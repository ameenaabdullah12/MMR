<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['proj_import_c']['enforced']='';
$dictionary['Opportunity']['fields']['proj_import_c']['dependency']='';

 ?>