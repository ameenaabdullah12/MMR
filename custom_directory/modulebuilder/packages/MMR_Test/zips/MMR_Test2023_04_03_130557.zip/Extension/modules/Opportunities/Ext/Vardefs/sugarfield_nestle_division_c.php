<?php
 // created: 2023-02-07 17:02:50
$dictionary['Opportunity']['fields']['nestle_division_c']['labelValue']='Nestle Division';
$dictionary['Opportunity']['fields']['nestle_division_c']['dependency']='equal(related($accounts,"name"),"NESTLÉ")';
$dictionary['Opportunity']['fields']['nestle_division_c']['visibility_grid']='';

 ?>