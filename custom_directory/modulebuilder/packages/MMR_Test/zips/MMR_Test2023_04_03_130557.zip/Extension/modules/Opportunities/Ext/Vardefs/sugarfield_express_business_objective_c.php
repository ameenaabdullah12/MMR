<?php
 // created: 2018-08-07 08:49:41
$dictionary['Opportunity']['fields']['express_business_objective_c']['labelValue']='express business objective';
$dictionary['Opportunity']['fields']['express_business_objective_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['express_business_objective_c']['enforced']='';
$dictionary['Opportunity']['fields']['express_business_objective_c']['dependency']='';

 ?>