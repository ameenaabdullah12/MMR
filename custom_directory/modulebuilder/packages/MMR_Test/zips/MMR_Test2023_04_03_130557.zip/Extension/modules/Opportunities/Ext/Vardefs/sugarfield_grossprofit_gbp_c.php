<?php
 // created: 2017-09-11 12:04:23
$dictionary['Opportunity']['fields']['grossprofit_gbp_c']['labelValue']='Gross Profit GBP';
$dictionary['Opportunity']['fields']['grossprofit_gbp_c']['enforced']='';

 ?>