<?php
 // created: 2020-07-30 08:03:44
$dictionary['Opportunity']['fields']['csq_presentation_insights_c']['labelValue']='Presentation and insights ';
$dictionary['Opportunity']['fields']['csq_presentation_insights_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_presentation_insights_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_presentation_insights_c']['dependency']='';

 ?>