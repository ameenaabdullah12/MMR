<?php
 // created: 2017-08-22 17:30:58
$dictionary['Opportunity']['fields']['wip_review_required_c']['enforced']='';
$dictionary['Opportunity']['fields']['wip_review_required_c']['dependency']='';

 ?>