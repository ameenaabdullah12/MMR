<?php
 
$dictionary['Opportunity']['fields']['a_project_trans'] = array(
    'name'         => 'a_project_trans',
    'type'         => 'link',
    'relationship' => 'opportunities_a_project_trans',
    'module'       => 'a_project_trans',
    'bean_name'    => 'a_project_trans',
    'source'       => 'non-db',
    'vname'        => 'LBL_OPPORTUNITY_PROJECT_TRANS',
);