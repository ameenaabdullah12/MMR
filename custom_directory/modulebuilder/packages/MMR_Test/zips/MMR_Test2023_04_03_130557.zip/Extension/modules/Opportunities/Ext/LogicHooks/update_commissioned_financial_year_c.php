<?php
/**
* Set commissioned_financial_year_c in opportunities 
 */
$hook_array['before_save'][] = array(
	//Processing index. For sorting the array.
	count($hook_array['before_save']) + 1,
	'before_save example',
	'custom/modules/Opportunities/update_commissioned_financial_year_c.php',
	'Setcommissioned_financial_year_c',
	'Setcommissioned_financial_year_c'
);
