<?php
 // created: 2023-02-06 22:00:49
$dictionary['Opportunity']['fields']['mars_brand_c']['labelValue']='Mars Brand(s):';
$dictionary['Opportunity']['fields']['mars_brand_c']['dependency']='';
$dictionary['Opportunity']['fields']['mars_brand_c']['visibility_grid']=array (
  'trigger' => 'mars_division_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Petcare' => 
    array (
      0 => '',
      1 => 'NA',
      2 => 'Catsan',
      3 => 'Cesar',
      4 => 'Chappie',
      5 => 'Crave',
      6 => 'Dine',
      7 => 'Dreamies',
      8 => 'Eukanuba',
      9 => 'Greenies',
      10 => 'Iams',
      11 => 'JamesWB',
      12 => 'Kitekat',
      13 => 'Lovebug',
      14 => 'Misfits',
      15 => 'MyDog',
      16 => 'Natusan',
      17 => 'Nutro',
      18 => 'Pedigree',
      19 => 'PerfectFit',
      20 => 'RoyalCanin',
      21 => 'Sheba',
      22 => 'Temptations',
      23 => 'Whiskas',
      24 => 'Other',
    ),
    'Food' => 
    array (
      0 => '',
      1 => 'NA',
      2 => 'BensOriginal',
      3 => 'Dolmio',
      4 => 'Ebly',
      5 => 'KanTong',
      6 => 'MasterFoods',
      7 => 'Miracoli',
      8 => 'Pamesello',
      9 => 'Raris',
      10 => 'Royco',
      11 => 'SeedsOC',
      12 => 'SuzyWan',
      13 => 'TastyBite',
      14 => 'Other',
    ),
    'Confectionary' => 
    array (
      0 => '',
      1 => 'NA',
      2 => 'Five',
      3 => 'Bounty',
      4 => 'Celebrations',
      5 => 'Wrigleys',
      6 => 'Dove',
      7 => 'Galaxy',
      8 => 'MnMs',
      9 => 'Maltesers',
      10 => 'Mars',
      11 => 'MilkyWay',
      12 => 'Skittles',
      13 => 'Snickers',
      14 => 'Starburst',
      15 => 'Twix',
      16 => 'Other',
    ),
  ),
);

 ?>