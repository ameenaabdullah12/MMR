<?php
 // created: 2017-09-26 09:43:32
$dictionary['Opportunity']['fields']['csq_other_comments_c']['labelValue']='Any other comments...?';
$dictionary['Opportunity']['fields']['csq_other_comments_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_other_comments_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_other_comments_c']['dependency']='';

 ?>