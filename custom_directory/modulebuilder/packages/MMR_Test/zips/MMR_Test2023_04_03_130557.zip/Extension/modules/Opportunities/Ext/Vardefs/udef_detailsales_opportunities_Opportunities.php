<?php
// created: 2017-06-30 15:14:58
$dictionary["Opportunity"]["fields"]["udef_detailsales_opportunities"] = array (
  'name' => 'udef_detailsales_opportunities',
  'type' => 'link',
  'relationship' => 'udef_detailsales_opportunities',
  'source' => 'non-db',
  'module' => 'udef_detailsales',
  'bean_name' => 'udef_detailsales',
  'vname' => 'LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'udef_detailsales_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
