<?php
// created: 2017-08-22 17:00:57
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'context' => 
  array (
    'link' => 'a_project_trans',
  ),
  'label' => 'LBL_A_PROJECT_TRANS_SUBPANEL_TITLE',
  'layout' => 'subpanel',
);