<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['direct_cost_gbp_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['direct_cost_gbp_c']['calculated']='1';
$dictionary['Opportunity']['fields']['direct_cost_gbp_c']['formula']='subtract($actual_sales_gbp_c,$grossprofit_gbp_c)';
$dictionary['Opportunity']['fields']['direct_cost_gbp_c']['enforced']='1';
$dictionary['Opportunity']['fields']['direct_cost_gbp_c']['dependency']='';

 ?>