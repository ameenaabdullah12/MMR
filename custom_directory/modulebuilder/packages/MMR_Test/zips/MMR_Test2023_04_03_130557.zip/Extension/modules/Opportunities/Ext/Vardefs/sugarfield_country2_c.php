<?php
 // created: 2017-08-23 08:11:04
$dictionary['Opportunity']['fields']['country2_c']['labelValue']='Country 2';
$dictionary['Opportunity']['fields']['country2_c']['dependency']='greaterThan(strlen($country1_c),0)';
$dictionary['Opportunity']['fields']['country2_c']['visibility_grid']='';

 ?>