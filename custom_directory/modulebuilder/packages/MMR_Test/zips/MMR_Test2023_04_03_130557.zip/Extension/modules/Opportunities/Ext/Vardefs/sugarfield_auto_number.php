<?php
 // created: 2017-08-23 13:16:29
$dictionary['Opportunity']['fields']['auto_number']['disable_num_format']='1';
$dictionary['Opportunity']['fields']['auto_number']['required']=false;
$dictionary['Opportunity']['fields']['auto_number']['massupdate']=false;
$dictionary['Opportunity']['fields']['auto_number']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['auto_number']['len']='30';

 ?>