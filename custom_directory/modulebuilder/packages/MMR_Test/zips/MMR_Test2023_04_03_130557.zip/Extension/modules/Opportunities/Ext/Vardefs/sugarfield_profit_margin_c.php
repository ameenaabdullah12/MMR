<?php
 // created: 2022-02-25 01:14:20
$dictionary['Opportunity']['fields']['profit_margin_c']['labelValue']='Profit Margin %';
$dictionary['Opportunity']['fields']['profit_margin_c']['enforced']='';
$dictionary['Opportunity']['fields']['profit_margin_c']['dependency']='';

 ?>