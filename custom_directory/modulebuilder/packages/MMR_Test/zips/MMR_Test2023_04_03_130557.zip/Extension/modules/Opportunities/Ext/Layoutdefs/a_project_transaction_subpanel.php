<?php
/*
$layout_defs['Opportunities']['subpanel_setup']['a_project_transaction'] = array(
    'order'             => 130,
    'module'            => 'a_project_transaction',
    'sort_order'        => 'asc',
    'sort_by'           => 'tran_date',
    'subpanel_name'     => 'default',
    'title_key'         => 'LBL_A_PROJECT_TRANSACTION_SUBPANEL_TITLE',
    'top_buttons'       => array (),
    'get_subpanel_data' => 'function:get_opportunity_project_transactions',
    'generate_select' => true,
    'function_parameters' => array(
        'import_function_file' => 'custom/modules/Opportunities/customProjectTransactionsSubPanel.php',
        'project_id' => $GLOBALS['app']->controller->bean->a_primary_project_id,
        'return_as_array' => 'true'
    ),
);
*/
