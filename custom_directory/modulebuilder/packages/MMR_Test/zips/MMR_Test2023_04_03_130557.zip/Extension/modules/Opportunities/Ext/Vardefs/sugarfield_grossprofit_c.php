<?php
 // created: 2018-06-14 10:55:17
$dictionary['Opportunity']['fields']['grossprofit_c']['labelValue']='Gross Profit Value';
$dictionary['Opportunity']['fields']['grossprofit_c']['enforced']='';
$dictionary['Opportunity']['fields']['grossprofit_c']['dependency']='';
$dictionary['Opportunity']['fields']['grossprofit_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>