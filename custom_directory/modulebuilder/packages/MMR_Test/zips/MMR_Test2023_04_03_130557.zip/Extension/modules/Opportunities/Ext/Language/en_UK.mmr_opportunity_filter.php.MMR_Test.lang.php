<?php

$mod_strings['LBL_TOGEHER_OPPORTUNITIES']="Together Proposal/Projects";