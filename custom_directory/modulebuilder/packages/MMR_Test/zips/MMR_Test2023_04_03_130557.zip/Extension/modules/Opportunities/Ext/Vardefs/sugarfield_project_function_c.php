<?php
 // created: 2023-02-08 22:30:11
$dictionary['Opportunity']['fields']['project_function_c']['labelValue']='Function';
$dictionary['Opportunity']['fields']['project_function_c']['dependency']='';
$dictionary['Opportunity']['fields']['project_function_c']['visibility_grid']=array (
  'trigger' => 'mmr_group_lead_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'MMR' => 
    array (
      0 => 'Quant',
      1 => 'Qual',
      2 => 'Sensory_Qual',
      3 => 'Sensory',
      4 => 'Client_CC',
    ),
    'Cubo' => 
    array (
    ),
    'Huxly' => 
    array (
      0 => 'Huxly',
    ),
    'Together' => 
    array (
      0 => 'Together',
    ),
  ),
);

 ?>