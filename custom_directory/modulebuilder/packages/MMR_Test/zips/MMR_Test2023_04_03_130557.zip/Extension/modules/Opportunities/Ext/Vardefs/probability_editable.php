<?php

$dictionary['Opportunity']['fields']['probability']['enforced']='false';