<?php
 // created: 2020-10-15 14:18:28
$dictionary['Opportunity']['fields']['expressyesno_c']['labelValue']='Is this an Express project?';
$dictionary['Opportunity']['fields']['expressyesno_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';
$dictionary['Opportunity']['fields']['expressyesno_c']['visibility_grid']='';

 ?>