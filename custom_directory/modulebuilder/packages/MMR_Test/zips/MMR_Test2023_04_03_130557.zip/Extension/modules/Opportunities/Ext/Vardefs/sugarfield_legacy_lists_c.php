<?php
 // created: 2020-10-15 14:56:17
$dictionary['Opportunity']['fields']['legacy_lists_c']['labelValue']='Legacy Lists';
$dictionary['Opportunity']['fields']['legacy_lists_c']['dependency']='';
$dictionary['Opportunity']['fields']['legacy_lists_c']['visibility_grid']='';

 ?>