<?php

    $hook_array['before_save'][] = Array(
        1, 
        'New auto increment number', 
        'custom/modules/Opportunities/auto_increment.php', 
        'increment', 
        'autoIncrement'
    );