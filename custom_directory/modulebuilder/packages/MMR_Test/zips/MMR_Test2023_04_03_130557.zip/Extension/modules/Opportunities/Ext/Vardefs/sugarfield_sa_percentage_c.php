<?php
 // created: 2017-08-22 17:30:58
$dictionary['Opportunity']['fields']['sa_percentage_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['sa_percentage_c']['dependency']='';
$dictionary['Opportunity']['fields']['sa_percentage_c']['visibility_grid']='';

 ?>