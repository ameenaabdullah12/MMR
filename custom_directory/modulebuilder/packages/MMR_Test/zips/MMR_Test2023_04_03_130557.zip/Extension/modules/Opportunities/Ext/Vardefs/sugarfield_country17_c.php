<?php
 // created: 2017-09-13 12:39:01
$dictionary['Opportunity']['fields']['country17_c']['labelValue']='Country 17';
$dictionary['Opportunity']['fields']['country17_c']['dependency']='greaterThan(strlen($country16_c),0)';
$dictionary['Opportunity']['fields']['country17_c']['visibility_grid']='';

 ?>