<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['contact_linked_c']['enforced']='';
$dictionary['Opportunity']['fields']['contact_linked_c']['dependency']='';

 ?>