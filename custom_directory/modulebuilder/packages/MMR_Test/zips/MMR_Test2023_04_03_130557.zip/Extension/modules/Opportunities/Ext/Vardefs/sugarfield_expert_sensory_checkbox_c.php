<?php
 // created: 2020-10-15 11:48:25
$dictionary['Opportunity']['fields']['expert_sensory_checkbox_c']['labelValue']='Expert Sensory?';
$dictionary['Opportunity']['fields']['expert_sensory_checkbox_c']['enforced']='';
$dictionary['Opportunity']['fields']['expert_sensory_checkbox_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';

 ?>