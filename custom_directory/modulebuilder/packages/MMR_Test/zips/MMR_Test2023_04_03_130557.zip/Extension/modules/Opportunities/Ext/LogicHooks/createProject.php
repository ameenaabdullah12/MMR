<?php
    $hook_array['before_save'][] = array(1, 'Convert Opportunity to Project', 'custom/modules/Opportunities/ConvertOppToProject.php', 'ConvertOppToProject', 'Convert');
?>