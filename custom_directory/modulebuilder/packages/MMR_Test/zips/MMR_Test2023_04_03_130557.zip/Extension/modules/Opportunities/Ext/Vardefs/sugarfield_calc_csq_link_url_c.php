<?php
 // created: 2021-02-23 12:10:29
$dictionary['Opportunity']['fields']['calc_csq_link_url_c']['labelValue']='calc csq link url';
$dictionary['Opportunity']['fields']['calc_csq_link_url_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['calc_csq_link_url_c']['dependency']='';

 ?>