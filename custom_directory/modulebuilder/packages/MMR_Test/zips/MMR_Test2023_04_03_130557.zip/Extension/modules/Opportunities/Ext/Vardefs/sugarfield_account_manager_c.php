<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['account_manager_c']['dependency']='';

 ?>