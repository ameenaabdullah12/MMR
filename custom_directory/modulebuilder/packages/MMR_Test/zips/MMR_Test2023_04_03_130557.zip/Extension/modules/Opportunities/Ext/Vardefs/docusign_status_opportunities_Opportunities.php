<?php
// created: 2015-08-28 16:55:03
$dictionary["Opportunity"]["fields"]["docusign_status_opportunities"] = array(
    'name'         => 'docusign_status_opportunities',
    'type'         => 'link',
    'relationship' => 'docusign_status_opportunities',
    'source'       => 'non-db',
    'module'       => 'WSYS_docusign_status',
    'bean_name'    => 'WSYS_docusign_status',
    'vname'        => 'LBL_DOCUSIGN_STATUS_ACCOUNTS_FROM_WSYS_DOCUSIGN_STATUS_TITLE',
    'id_name'      => 'docusign_status_opportunities_docusign_status_ida',
);
