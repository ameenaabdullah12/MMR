<?php
 // created: 2017-09-13 12:31:23
$dictionary['Opportunity']['fields']['country10_c']['labelValue']='Country 10';
$dictionary['Opportunity']['fields']['country10_c']['dependency']='greaterThan(strlen($country9_c),0)';
$dictionary['Opportunity']['fields']['country10_c']['visibility_grid']='';

 ?>