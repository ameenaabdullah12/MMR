<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CLOSED_RLIS'] = '수주 완료된 Revenue Line Items 수량';
$mod_strings['NOTICE_NO_DELETE_CLOSED_RLIS'] = '완료된 Revenue Line Items을 가지고 있는 영업기회는 삭제할수 없습니다.';
