<?php
 // created: 2017-08-22 17:30:57
$dictionary['Opportunity']['fields']['qual_gp_new_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['qual_gp_new_c']['calculated']='1';
$dictionary['Opportunity']['fields']['qual_gp_new_c']['formula']='multiply(divide($qual_percent_new_c,100),$gp_home_integer_c)';
$dictionary['Opportunity']['fields']['qual_gp_new_c']['enforced']='1';
$dictionary['Opportunity']['fields']['qual_gp_new_c']['dependency']='';

 ?>