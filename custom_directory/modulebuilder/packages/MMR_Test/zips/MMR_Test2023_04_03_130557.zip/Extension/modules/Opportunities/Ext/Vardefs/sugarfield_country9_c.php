<?php
 // created: 2017-09-13 12:30:44
$dictionary['Opportunity']['fields']['country9_c']['labelValue']='Country 9';
$dictionary['Opportunity']['fields']['country9_c']['dependency']='greaterThan(strlen($country8_c),0)';
$dictionary['Opportunity']['fields']['country9_c']['visibility_grid']='';

 ?>