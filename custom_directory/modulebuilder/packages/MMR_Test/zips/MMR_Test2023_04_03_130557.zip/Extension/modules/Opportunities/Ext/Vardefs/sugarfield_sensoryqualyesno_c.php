<?php
 // created: 2020-10-15 13:59:50
$dictionary['Opportunity']['fields']['sensoryqualyesno_c']['labelValue']='Does this involve Sensory Qual?';
$dictionary['Opportunity']['fields']['sensoryqualyesno_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';
$dictionary['Opportunity']['fields']['sensoryqualyesno_c']['visibility_grid']='';

 ?>