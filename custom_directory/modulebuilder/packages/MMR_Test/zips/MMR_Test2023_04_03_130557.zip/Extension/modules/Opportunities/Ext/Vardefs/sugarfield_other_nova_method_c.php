<?php
 // created: 2022-06-16 12:30:41
$dictionary['Opportunity']['fields']['other_nova_method_c']['labelValue']='Other Nova Methodology';
$dictionary['Opportunity']['fields']['other_nova_method_c']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1',
  'searchable' => true,
);
$dictionary['Opportunity']['fields']['other_nova_method_c']['enforced']='';
$dictionary['Opportunity']['fields']['other_nova_method_c']['dependency']='equal($nova_research_method_c,"Other")';

 ?>