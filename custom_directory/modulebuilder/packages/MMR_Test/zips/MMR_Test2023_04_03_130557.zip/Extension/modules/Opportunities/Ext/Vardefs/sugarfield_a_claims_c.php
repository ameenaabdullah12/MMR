<?php
 // created: 2019-07-18 13:59:20
$dictionary['Opportunity']['fields']['a_claims_c']['labelValue']='Claims_Not_Used';
$dictionary['Opportunity']['fields']['a_claims_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['a_claims_c']['enforced']='';
$dictionary['Opportunity']['fields']['a_claims_c']['dependency']='';

 ?>