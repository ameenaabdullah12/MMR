<?php
 // created: 2017-09-13 12:37:47
$dictionary['Opportunity']['fields']['country14_c']['labelValue']='Country 14';
$dictionary['Opportunity']['fields']['country14_c']['dependency']='greaterThan(strlen($country13_c),0)';
$dictionary['Opportunity']['fields']['country14_c']['visibility_grid']='';

 ?>