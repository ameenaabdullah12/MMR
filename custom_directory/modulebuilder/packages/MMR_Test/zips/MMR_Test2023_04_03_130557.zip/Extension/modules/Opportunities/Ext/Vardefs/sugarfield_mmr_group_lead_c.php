<?php
 // created: 2021-10-07 11:48:06
$dictionary['Opportunity']['fields']['mmr_group_lead_c']['labelValue']='MMR Brand';
$dictionary['Opportunity']['fields']['mmr_group_lead_c']['dependency']='';
$dictionary['Opportunity']['fields']['mmr_group_lead_c']['visibility_grid']='';

 ?>