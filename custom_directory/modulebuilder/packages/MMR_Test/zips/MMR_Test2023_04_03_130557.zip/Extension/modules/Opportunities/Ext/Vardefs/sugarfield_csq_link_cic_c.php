<?php
 // created: 2021-02-23 11:58:19
$dictionary['Opportunity']['fields']['csq_link_cic_c']['labelValue']='csq link cic';
$dictionary['Opportunity']['fields']['csq_link_cic_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_link_cic_c']['dependency']='';

 ?>