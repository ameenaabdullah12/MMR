<?php
$mod_strings['LBL_PRIMARY_PROJECT_NAME'] = 'Primary Project';
$mod_strings['LBL_PRIMARY_PROJECT_ID'] = 'Primary Project ID';
$mod_strings['LBL_PRIMARY_PROJECTS'] = 'Primary Projects';
$mod_strings['LBL_A_PRIMARY_PROJECT_CODE'] = 'Primary Project Code';
$mod_strings['LBL_A_PROJECT_TRANSACTION_SUBPANEL_TITLE'] = 'Project Transactions';