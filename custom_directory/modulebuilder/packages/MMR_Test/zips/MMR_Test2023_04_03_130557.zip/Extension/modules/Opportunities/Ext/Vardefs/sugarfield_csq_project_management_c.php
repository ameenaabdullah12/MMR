<?php
 // created: 2020-07-30 08:04:04
$dictionary['Opportunity']['fields']['csq_project_management_c']['labelValue']='Project management';
$dictionary['Opportunity']['fields']['csq_project_management_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_project_management_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_project_management_c']['dependency']='';

 ?>