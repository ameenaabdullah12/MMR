<?php
// created: 2017-08-22 17:00:57
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'label' => 'LBL_A_ORDER_HEADER_OPPORTUNITIES_FROM_A_ORDER_HEADER_TITLE',
  'context' => 
  array (
    'link' => 'a_order_header_opportunities',
  ),
  'layout' => 'subpanel',
);