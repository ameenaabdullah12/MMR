<?php
 // created: 2022-11-22 13:10:28
$dictionary['Opportunity']['fields']['escreenyesno_c']['labelValue']='Does this include Bitesized?';
$dictionary['Opportunity']['fields']['escreenyesno_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';
$dictionary['Opportunity']['fields']['escreenyesno_c']['visibility_grid']='';

 ?>