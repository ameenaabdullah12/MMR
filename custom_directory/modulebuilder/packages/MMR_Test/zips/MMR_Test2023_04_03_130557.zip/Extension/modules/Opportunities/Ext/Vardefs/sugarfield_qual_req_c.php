<?php
 // created: 2021-04-01 08:10:16
$dictionary['Opportunity']['fields']['qual_req_c']['labelValue']='Does the project involve an MMR Qual Team?';
$dictionary['Opportunity']['fields']['qual_req_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';
$dictionary['Opportunity']['fields']['qual_req_c']['visibility_grid']='';

 ?>