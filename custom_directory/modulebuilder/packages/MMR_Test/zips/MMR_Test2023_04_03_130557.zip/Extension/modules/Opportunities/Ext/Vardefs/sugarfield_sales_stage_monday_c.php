<?php
 // created: 2023-01-31 15:40:44
$dictionary['Opportunity']['fields']['sales_stage_monday_c']['labelValue']='Sales Stage Monday';
$dictionary['Opportunity']['fields']['sales_stage_monday_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['sales_stage_monday_c']['enforced']='';
$dictionary['Opportunity']['fields']['sales_stage_monday_c']['dependency']='';

 ?>