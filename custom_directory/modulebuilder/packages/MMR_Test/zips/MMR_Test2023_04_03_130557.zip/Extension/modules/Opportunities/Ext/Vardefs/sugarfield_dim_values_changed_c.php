<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['dim_values_changed_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['dim_values_changed_c']['enforced']='';
$dictionary['Opportunity']['fields']['dim_values_changed_c']['dependency']='';

 ?>