<?php
 // created: 2017-09-11 12:03:51
$dictionary['Opportunity']['fields']['committed_cost_c']['labelValue']='Outstanding Supplier PO\'s';
$dictionary['Opportunity']['fields']['committed_cost_c']['enforced']='';

 ?>