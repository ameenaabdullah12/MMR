<?php
 // created: 2017-09-13 12:27:49
$dictionary['Opportunity']['fields']['country5_c']['labelValue']='Country 5';
$dictionary['Opportunity']['fields']['country5_c']['dependency']='greaterThan(strlen($country4_c),0)';
$dictionary['Opportunity']['fields']['country5_c']['visibility_grid']='';

 ?>