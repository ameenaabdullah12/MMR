<?php
 // created: 2017-09-26 09:41:16
$dictionary['Opportunity']['fields']['csq_do_differently_c']['labelValue']='What would you like MMR to do differently on future projects?';
$dictionary['Opportunity']['fields']['csq_do_differently_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_do_differently_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_do_differently_c']['dependency']='';

 ?>