<?php
 // created: 2021-11-11 15:50:24
$dictionary['Opportunity']['fields']['a_forecast_amount']['default']=0.0;
$dictionary['Opportunity']['fields']['a_forecast_amount']['audited']=false;
$dictionary['Opportunity']['fields']['a_forecast_amount']['massupdate']=false;
$dictionary['Opportunity']['fields']['a_forecast_amount']['comments']='Unconverted forecast amount of the opportunity';
$dictionary['Opportunity']['fields']['a_forecast_amount']['importable']='true';
$dictionary['Opportunity']['fields']['a_forecast_amount']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['a_forecast_amount']['duplicate_merge_dom_value']='1';
$dictionary['Opportunity']['fields']['a_forecast_amount']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['a_forecast_amount']['calculated']=false;
$dictionary['Opportunity']['fields']['a_forecast_amount']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);
$dictionary['Opportunity']['fields']['a_forecast_amount']['enable_range_search']='1';

 ?>