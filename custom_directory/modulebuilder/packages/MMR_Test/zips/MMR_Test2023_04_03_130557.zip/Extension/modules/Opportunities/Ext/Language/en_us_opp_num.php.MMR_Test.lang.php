<?php
/**
 * Created by PhpStorm.
 * User: Nagy Zoltan
 * Date: 2018-10-30
 * Time: 14:35
 */
$mod_strings['LBL_OPP_NUM']="Opportunity number";