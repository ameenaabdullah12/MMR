<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['case_study_doc_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['case_study_doc_c']['dependency']='$case_study_c';

 ?>