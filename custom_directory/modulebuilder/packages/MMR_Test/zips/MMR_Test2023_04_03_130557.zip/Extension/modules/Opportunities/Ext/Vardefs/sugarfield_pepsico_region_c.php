<?php
 // created: 2020-01-23 15:19:56
$dictionary['Opportunity']['fields']['pepsico_region_c']['labelValue']='PepsiCo region';
$dictionary['Opportunity']['fields']['pepsico_region_c']['dependency']='equal(related($accounts,"name"),"PEPSICO")';
$dictionary['Opportunity']['fields']['pepsico_region_c']['visibility_grid']='';

 ?>