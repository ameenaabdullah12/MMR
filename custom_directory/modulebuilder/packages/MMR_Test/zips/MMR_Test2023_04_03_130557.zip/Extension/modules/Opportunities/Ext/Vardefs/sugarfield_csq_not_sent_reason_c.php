<?php
 // created: 2018-02-06 10:40:45
$dictionary['Opportunity']['fields']['csq_not_sent_reason_c']['labelValue']='If you are not going to send a CSQ please select a reason:';
$dictionary['Opportunity']['fields']['csq_not_sent_reason_c']['dependency']='isInList($sales_stage,createList("Posted Proposal","Commissioned","Closed (Debriefed)","Closed (Fully Invoiced)"))';
$dictionary['Opportunity']['fields']['csq_not_sent_reason_c']['visibility_grid']='';

 ?>