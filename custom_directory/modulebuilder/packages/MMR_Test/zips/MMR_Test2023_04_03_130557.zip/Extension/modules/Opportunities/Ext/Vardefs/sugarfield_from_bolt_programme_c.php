<?php
 // created: 2019-08-20 14:25:25
$dictionary['Opportunity']['fields']['from_bolt_programme_c']['labelValue']='From Bolt Programme';
$dictionary['Opportunity']['fields']['from_bolt_programme_c']['enforced']='';
$dictionary['Opportunity']['fields']['from_bolt_programme_c']['dependency']='';

 ?>