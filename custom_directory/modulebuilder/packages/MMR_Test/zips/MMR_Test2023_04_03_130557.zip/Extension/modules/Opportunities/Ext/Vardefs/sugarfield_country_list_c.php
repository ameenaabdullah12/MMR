<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['country_list_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['country_list_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['country_list_c']['calculated']='1';
$dictionary['Opportunity']['fields']['country_list_c']['formula']='concat($country1_c,",",$country2_c,",",$country3_c,",",$country4_c,",",$country5_c,",",$country6_c,",",$country7_c,",",$country8_c,",",$country9_c,",",$country10_c,",",$country11_c,",",$country12_c,",",$country13_c,",",$country14_c)';
$dictionary['Opportunity']['fields']['country_list_c']['enforced']='1';
$dictionary['Opportunity']['fields']['country_list_c']['dependency']='';

 ?>