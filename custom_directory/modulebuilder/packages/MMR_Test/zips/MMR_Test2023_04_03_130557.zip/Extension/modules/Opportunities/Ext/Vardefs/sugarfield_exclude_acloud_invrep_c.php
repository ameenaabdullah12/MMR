<?php
 // created: 2020-10-08 10:07:28
$dictionary['Opportunity']['fields']['exclude_acloud_invrep_c']['labelValue']='exclude acloud invrep';
$dictionary['Opportunity']['fields']['exclude_acloud_invrep_c']['dependency']='';
$dictionary['Opportunity']['fields']['exclude_acloud_invrep_c']['visibility_grid']='';

 ?>