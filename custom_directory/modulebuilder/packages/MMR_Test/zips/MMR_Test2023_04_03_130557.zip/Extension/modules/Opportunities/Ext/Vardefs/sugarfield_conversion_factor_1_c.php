<?php
 // created: 2018-05-10 11:38:00
$dictionary['Opportunity']['fields']['conversion_factor_1_c']['labelValue']='Conversion factor';
$dictionary['Opportunity']['fields']['conversion_factor_1_c']['dependency']='';
$dictionary['Opportunity']['fields']['conversion_factor_1_c']['visibility_grid']=array (
  'trigger' => 'sales_stage',
  'values' => 
  array (
    'Unposted Enquiry' => 
    array (
      0 => '0',
    ),
    'Posted Proposal' => 
    array (
      0 => '0',
    ),
    'Commissioned' => 
    array (
      0 => '1',
    ),
    'Closed (Lost Proposal)' => 
    array (
      0 => '0',
    ),
    'Closed (Aborted)' => 
    array (
      0 => '0',
    ),
    'Closed (Debriefed)' => 
    array (
      0 => '1',
    ),
    'Closed (Fully Invoiced)' => 
    array (
      0 => '1',
    ),
    'Marketing' => 
    array (
      0 => '0',
    ),
    'ClosedNoProposal' => 
    array (
      0 => '0',
    ),
  ),
);

 ?>