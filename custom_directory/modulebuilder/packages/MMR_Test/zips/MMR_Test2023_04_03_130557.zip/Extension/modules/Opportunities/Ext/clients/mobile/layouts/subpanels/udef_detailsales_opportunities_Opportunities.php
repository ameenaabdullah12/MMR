<?php
// created: 2017-04-19 14:06:18
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_UDEF_DETAILSALES_TITLE',
  'context' => 
  array (
    'link' => 'udef_detailsales_opportunities',
  ),
);

$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UDEF_DETAILSALES_OPPORTUNITIES_FROM_UDEF_DETAILSALES_TITLE',
  'context' => 
  array (
    'link' => 'udef_detailsales_opportunities',
  ),
);