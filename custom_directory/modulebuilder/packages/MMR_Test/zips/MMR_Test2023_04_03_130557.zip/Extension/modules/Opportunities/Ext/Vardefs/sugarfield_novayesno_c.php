<?php
 // created: 2021-09-23 14:37:08
$dictionary['Opportunity']['fields']['novayesno_c']['labelValue']='Include NOVA team in proposal?';
$dictionary['Opportunity']['fields']['novayesno_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';
$dictionary['Opportunity']['fields']['novayesno_c']['visibility_grid']='';

 ?>