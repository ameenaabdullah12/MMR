<?php
 // created: 2020-10-29 12:05:03
$dictionary['Opportunity']['fields']['sales_stage_orig_c']['labelValue']='Sales Stage Orig';
$dictionary['Opportunity']['fields']['sales_stage_orig_c']['dependency']='';
$dictionary['Opportunity']['fields']['sales_stage_orig_c']['visibility_grid']='';

 ?>