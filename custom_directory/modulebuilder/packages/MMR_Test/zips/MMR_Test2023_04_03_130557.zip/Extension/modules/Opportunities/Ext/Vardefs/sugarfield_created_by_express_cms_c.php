<?php
 // created: 2018-08-16 10:34:38
$dictionary['Opportunity']['fields']['created_by_express_cms_c']['labelValue']='created by express cms';
$dictionary['Opportunity']['fields']['created_by_express_cms_c']['enforced']='';
$dictionary['Opportunity']['fields']['created_by_express_cms_c']['dependency']='';

 ?>