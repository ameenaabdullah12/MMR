<?php
$dictionary['Opportunity']['fields']['renewal'] = null;
$dictionary['Opportunity']['fields']['renewal_parent_name'] = null;