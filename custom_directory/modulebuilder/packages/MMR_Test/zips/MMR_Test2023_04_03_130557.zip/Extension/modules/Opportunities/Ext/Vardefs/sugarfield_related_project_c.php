<?php
 // created: 2017-08-22 17:30:57
$dictionary['Opportunity']['fields']['related_project_c']['dependency']='';

 ?>