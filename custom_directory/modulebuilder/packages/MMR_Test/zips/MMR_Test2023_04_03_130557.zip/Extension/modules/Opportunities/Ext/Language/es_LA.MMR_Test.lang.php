<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_TOTAL_RLIS'] = '# del Total de Revenue Line Items';
$mod_strings['LBL_CLOSED_RLIS'] = '# de Cerradas de Revenue Line Items';
$mod_strings['NOTICE_NO_DELETE_CLOSED_RLIS'] = 'No puede eliminar Oportunidades que contienen cerradas de Revenue Line Items';
