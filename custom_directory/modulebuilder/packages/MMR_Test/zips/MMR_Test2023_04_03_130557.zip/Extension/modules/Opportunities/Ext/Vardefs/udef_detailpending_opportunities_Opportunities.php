<?php
// created: 2017-06-30 15:14:59
$dictionary["Opportunity"]["fields"]["udef_detailpending_opportunities"] = array (
  'name' => 'udef_detailpending_opportunities',
  'type' => 'link',
  'relationship' => 'udef_detailpending_opportunities',
  'source' => 'non-db',
  'module' => 'udef_detailpending',
  'bean_name' => 'udef_detailpending',
  'vname' => 'LBL_UDEF_DETAILPENDING_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'udef_detailpending_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
