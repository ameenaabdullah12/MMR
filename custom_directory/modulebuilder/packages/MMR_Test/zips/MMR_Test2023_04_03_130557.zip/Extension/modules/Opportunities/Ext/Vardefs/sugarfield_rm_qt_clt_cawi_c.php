<?php
 // created: 2023-02-03 16:26:39
$dictionary['Opportunity']['fields']['rm_qt_clt_cawi_c']['labelValue']='Quant CLT CAWI';
$dictionary['Opportunity']['fields']['rm_qt_clt_cawi_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['rm_qt_clt_cawi_c']['enforced']='';
$dictionary['Opportunity']['fields']['rm_qt_clt_cawi_c']['dependency']='';

 ?>