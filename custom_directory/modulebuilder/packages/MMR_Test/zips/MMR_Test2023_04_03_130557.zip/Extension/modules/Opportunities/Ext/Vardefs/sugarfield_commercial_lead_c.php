<?php
 // created: 2020-10-15 14:39:11
$dictionary['Opportunity']['fields']['commercial_lead_c']['labelValue']='Commercial Lead';
$dictionary['Opportunity']['fields']['commercial_lead_c']['dependency']='';

 ?>