<?php
 // created: 2018-06-26 17:01:22
$dictionary['Opportunity']['fields']['sample_size_c']['labelValue']='Sample size';
$dictionary['Opportunity']['fields']['sample_size_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['sample_size_c']['enforced']='';
$dictionary['Opportunity']['fields']['sample_size_c']['dependency']='';

 ?>