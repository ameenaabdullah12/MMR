<?php
 // created: 2020-02-25 23:50:19
$dictionary['Opportunity']['fields']['csq_confirm_mkg_mtrl_c']['labelValue']='Confirm if ok to use for marketing?';
$dictionary['Opportunity']['fields']['csq_confirm_mkg_mtrl_c']['dependency']='';
$dictionary['Opportunity']['fields']['csq_confirm_mkg_mtrl_c']['visibility_grid']='';

 ?>