<?php
 // created: 2021-10-07 12:20:24
$dictionary['Opportunity']['fields']['project_type_c']['labelValue']='Project Type / Brand Pillar';
$dictionary['Opportunity']['fields']['project_type_c']['dependency']='';
$dictionary['Opportunity']['fields']['project_type_c']['visibility_grid']=array (
  'trigger' => 'mmr_group_lead_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'MMR' => 
    array (
    ),
    'Cubo' => 
    array (
    ),
    'Huxly' => 
    array (
    ),
    'Together' => 
    array (
      0 => '',
      1 => 'Brand',
      2 => 'Digital',
      3 => 'Film Photography',
      4 => 'Packaging',
      5 => 'Social',
    ),
  ),
);

 ?>