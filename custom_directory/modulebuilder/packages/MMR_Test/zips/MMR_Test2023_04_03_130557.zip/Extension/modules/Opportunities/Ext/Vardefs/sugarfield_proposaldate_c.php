<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['proposaldate_c']['options']='date_range_search_dom';
$dictionary['Opportunity']['fields']['proposaldate_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['proposaldate_c']['enforced']='';
$dictionary['Opportunity']['fields']['proposaldate_c']['dependency']='';
$dictionary['Opportunity']['fields']['proposaldate_c']['enable_range_search']='1';

 ?>