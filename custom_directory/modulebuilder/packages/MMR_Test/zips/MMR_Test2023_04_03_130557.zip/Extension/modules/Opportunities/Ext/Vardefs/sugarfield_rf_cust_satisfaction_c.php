<?php
 // created: 2019-07-18 13:59:35
$dictionary['Opportunity']['fields']['rf_cust_satisfaction_c']['labelValue']='Claims';
$dictionary['Opportunity']['fields']['rf_cust_satisfaction_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['rf_cust_satisfaction_c']['enforced']='';
$dictionary['Opportunity']['fields']['rf_cust_satisfaction_c']['dependency']='';

 ?>