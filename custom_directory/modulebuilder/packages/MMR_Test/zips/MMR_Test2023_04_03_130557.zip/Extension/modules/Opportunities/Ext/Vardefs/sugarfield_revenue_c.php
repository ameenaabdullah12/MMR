<?php
 // created: 2017-09-14 14:15:13
$dictionary['Opportunity']['fields']['revenue_c']['labelValue']='Estimated Sales';
$dictionary['Opportunity']['fields']['revenue_c']['enforced']='';
$dictionary['Opportunity']['fields']['revenue_c']['dependency']='equal("Unposted Enquiry",$sales_stage)';
$dictionary['Opportunity']['fields']['revenue_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>