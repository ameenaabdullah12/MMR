<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['current_month_stage_3_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['current_month_stage_3_c']['enforced']='';
$dictionary['Opportunity']['fields']['current_month_stage_3_c']['dependency']='';

 ?>