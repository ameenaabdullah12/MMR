<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['debrief_upload_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['debrief_upload_c']['enforced']='';
$dictionary['Opportunity']['fields']['debrief_upload_c']['dependency']='';

 ?>