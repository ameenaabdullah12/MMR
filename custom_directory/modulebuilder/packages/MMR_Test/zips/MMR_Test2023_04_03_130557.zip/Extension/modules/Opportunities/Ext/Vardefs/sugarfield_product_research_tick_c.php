<?php
 // created: 2018-11-15 16:42:06
$dictionary['Opportunity']['fields']['product_research_tick_c']['labelValue']='product research tick';
$dictionary['Opportunity']['fields']['product_research_tick_c']['enforced']='';
$dictionary['Opportunity']['fields']['product_research_tick_c']['dependency']='';

 ?>