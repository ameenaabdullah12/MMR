<?php
 // created: 2017-09-13 12:29:37
$dictionary['Opportunity']['fields']['country7_c']['labelValue']='Country 7';
$dictionary['Opportunity']['fields']['country7_c']['dependency']='greaterThan(strlen($country6_c),0)';
$dictionary['Opportunity']['fields']['country7_c']['visibility_grid']='';

 ?>