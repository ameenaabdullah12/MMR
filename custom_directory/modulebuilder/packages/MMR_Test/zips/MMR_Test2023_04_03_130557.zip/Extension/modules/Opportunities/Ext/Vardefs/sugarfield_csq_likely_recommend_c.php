<?php
 // created: 2020-07-30 08:02:40
$dictionary['Opportunity']['fields']['csq_likely_recommend_c']['labelValue']='How likely would you be to recommend MMR to one of your stakeholder or colleagues?';
$dictionary['Opportunity']['fields']['csq_likely_recommend_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_likely_recommend_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_likely_recommend_c']['dependency']='';

 ?>