<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/en_us.mmr.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/en_us.mmr.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_A_ROLLUP_QUOTE'] = 'Rollup from Quote';
$mod_strings['LBL_A_FORECAST_AMOUNT'] = 'Forecast Amount';
$mod_strings['LBL_A_FORECAST_AMOUNT_USDOLLAR'] = 'Forecast Amount Converted';


?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_A_ROLLUP_QUOTE'] = 'Rollup from Quote';
$mod_strings['LBL_A_FORECAST_AMOUNT'] = 'Forecast Amount';
$mod_strings['LBL_A_FORECAST_AMOUNT_USDOLLAR'] = 'Forecast Amount Converted';



?>
<?php
// Merged from custom/Extension/modules/Opportunities/Ext/Language/temp.php
 
 // created: 2017-08-22 17:15:44
$mod_strings['LBL_A_ROLLUP_QUOTE'] = 'Rollup from Quote';
$mod_strings['LBL_A_FORECAST_AMOUNT'] = 'Forecast Amount';
$mod_strings['LBL_A_FORECAST_AMOUNT_USDOLLAR'] = 'Forecast Amount Converted';


?>
