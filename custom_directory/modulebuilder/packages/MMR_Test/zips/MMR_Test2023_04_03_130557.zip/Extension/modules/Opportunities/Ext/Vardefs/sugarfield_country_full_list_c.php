<?php
 // created: 2019-09-03 08:17:05
$dictionary['Opportunity']['fields']['country_full_list_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['country_full_list_c']['labelValue']='Country List';
$dictionary['Opportunity']['fields']['country_full_list_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['country_full_list_c']['calculated']='1';
$dictionary['Opportunity']['fields']['country_full_list_c']['formula']='concat($country1_c,", ",$country2_c,", ",$country3_c,", ",$country4_c,", ",$country5_c,", ",$country6_c,", ",$country7_c,", ",$country8_c,", ",$country9_c,", ",$country10_c,", ",$country11_c,", ",$country12_c,", ",$country13_c,", ",$country14_c,", ",$country15_c,", ",$country16_c,", ",$country17_c,", ",$country18_c,", ",$country19_c,", ",$country20_c)';
$dictionary['Opportunity']['fields']['country_full_list_c']['enforced']='1';
$dictionary['Opportunity']['fields']['country_full_list_c']['dependency']='';

 ?>