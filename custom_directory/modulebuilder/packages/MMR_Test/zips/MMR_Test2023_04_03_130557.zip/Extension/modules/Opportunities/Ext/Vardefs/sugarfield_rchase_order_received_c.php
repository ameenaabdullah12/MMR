<?php
 // created: 2022-05-16 08:36:27
$dictionary['Opportunity']['fields']['rchase_order_received_c']['labelValue']='rchase order received';
$dictionary['Opportunity']['fields']['rchase_order_received_c']['dependency']='';
$dictionary['Opportunity']['fields']['rchase_order_received_c']['visibility_grid']='';

 ?>