<?php
 // created: 2017-08-22 17:29:57
$dictionary['Opportunity']['fields']['worst_case']['audited']=true;
$dictionary['Opportunity']['fields']['worst_case']['massupdate']=true;
$dictionary['Opportunity']['fields']['worst_case']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['worst_case']['duplicate_merge_dom_value']=1;
$dictionary['Opportunity']['fields']['worst_case']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['worst_case']['calculated']=false;
$dictionary['Opportunity']['fields']['worst_case']['enable_range_search']=false;
$dictionary['Opportunity']['fields']['worst_case']['default']='';

 ?>