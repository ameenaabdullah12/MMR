<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['debrief_date_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['debrief_date_c']['enforced']='';
$dictionary['Opportunity']['fields']['debrief_date_c']['dependency']='equal($sales_stage,"Closed (Debriefed)")';

 ?>