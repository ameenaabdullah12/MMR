<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['qual_gp_c']['enforced']='false';
$dictionary['Opportunity']['fields']['qual_gp_c']['dependency']='equal($qual_req_c,"Yes")';

 ?>