<?php
 // created: 2014-01-29 10:24:59
$dictionary['Opportunity']['fields']['auto_number'] =array (
'required' => true,
'name' => 'auto_number',
'vname' => 'LBL_OPP_AUTO_NUMBER',
'type' => 'varchar',
'len' => 30,
'massupdate' => 0,
'comments' => '',
'help' => '',
'importable' => 'true',
'duplicate_merge' => 'disabled',
'duplicate_merge_dom_value' => '0',
'audited' => false,
'reportable' => true,
'calculated' => false,
'disable_num_format'=>true,
'merge_filter'=>'disabled',
'enable_range_search'=>false,
'min'=>false,
'max'=>false,
'disable_num_format'=>'',
);

 ?>