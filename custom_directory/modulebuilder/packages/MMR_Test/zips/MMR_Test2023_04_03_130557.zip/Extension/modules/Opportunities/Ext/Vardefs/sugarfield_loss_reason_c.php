<?php
 // created: 2021-09-28 12:21:05
$dictionary['Opportunity']['fields']['loss_reason_c']['labelValue']='Loss Reason';
$dictionary['Opportunity']['fields']['loss_reason_c']['dependency']='isInList($sales_stage,
createList("Closed (Lost Proposal)","Closed (Aborted)")
)';
$dictionary['Opportunity']['fields']['loss_reason_c']['visibility_grid']='';

 ?>