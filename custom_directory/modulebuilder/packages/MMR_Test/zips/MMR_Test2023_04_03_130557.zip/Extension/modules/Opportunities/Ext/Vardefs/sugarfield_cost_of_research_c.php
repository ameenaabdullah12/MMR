<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['cost_of_research_c']['enforced']='';
$dictionary['Opportunity']['fields']['cost_of_research_c']['dependency']='';

 ?>