<?php
 // created: 2017-10-06 14:26:27
$dictionary['Opportunity']['fields']['rp_complete_date_c']['labelValue']='Date marked complete on RP';
$dictionary['Opportunity']['fields']['rp_complete_date_c']['enforced']='';
$dictionary['Opportunity']['fields']['rp_complete_date_c']['dependency']='';

 ?>