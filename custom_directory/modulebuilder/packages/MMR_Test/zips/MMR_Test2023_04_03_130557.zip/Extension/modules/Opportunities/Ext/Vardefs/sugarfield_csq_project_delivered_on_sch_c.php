<?php
 // created: 2019-04-11 13:47:15
$dictionary['Opportunity']['fields']['csq_project_delivered_on_sch_c']['labelValue']='Project Delivered on Schedule';
$dictionary['Opportunity']['fields']['csq_project_delivered_on_sch_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_project_delivered_on_sch_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_project_delivered_on_sch_c']['dependency']='';

 ?>