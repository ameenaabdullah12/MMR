<?php
 // created: 2017-10-12 16:42:59
$dictionary['Opportunity']['fields']['csq_complete_date_c']['labelValue']='CSQ complete date';
$dictionary['Opportunity']['fields']['csq_complete_date_c']['enforced']='false';
$dictionary['Opportunity']['fields']['csq_complete_date_c']['dependency']='';

 ?>