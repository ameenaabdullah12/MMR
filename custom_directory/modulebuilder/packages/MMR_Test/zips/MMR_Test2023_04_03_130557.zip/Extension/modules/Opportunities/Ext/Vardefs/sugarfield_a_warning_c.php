<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['a_warning_c']['dependency']='not(equal($contact_c,"Array"))';

 ?>