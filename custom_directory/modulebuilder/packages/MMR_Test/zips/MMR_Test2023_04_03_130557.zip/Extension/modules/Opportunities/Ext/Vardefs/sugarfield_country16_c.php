<?php
 // created: 2017-09-13 12:46:05
$dictionary['Opportunity']['fields']['country16_c']['labelValue']='Country 16';
$dictionary['Opportunity']['fields']['country16_c']['dependency']='greaterThan(strlen($country15_c),0)';
$dictionary['Opportunity']['fields']['country16_c']['visibility_grid']='';

 ?>