<?php
 // created: 2017-09-13 12:30:16
$dictionary['Opportunity']['fields']['country8_c']['labelValue']='Country 8';
$dictionary['Opportunity']['fields']['country8_c']['dependency']='greaterThan(strlen($country7_c),0)';
$dictionary['Opportunity']['fields']['country8_c']['visibility_grid']='';

 ?>