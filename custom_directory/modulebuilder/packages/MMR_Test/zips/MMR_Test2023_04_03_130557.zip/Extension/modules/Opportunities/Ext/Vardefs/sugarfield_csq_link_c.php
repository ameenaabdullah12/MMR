<?php
 // created: 2021-02-23 11:57:14
$dictionary['Opportunity']['fields']['csq_link_c']['labelValue']='CSQ Link MMR';
$dictionary['Opportunity']['fields']['csq_link_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_link_c']['dependency']='';

 ?>