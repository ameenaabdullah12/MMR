<?php
 // created: 2021-12-02 15:11:23
$dictionary['Opportunity']['fields']['hc_salesvalue_c']['labelValue']='Sales Value (home currency)';
$dictionary['Opportunity']['fields']['hc_salesvalue_c']['enforced']='';
$dictionary['Opportunity']['fields']['hc_salesvalue_c']['dependency']='';

 ?>