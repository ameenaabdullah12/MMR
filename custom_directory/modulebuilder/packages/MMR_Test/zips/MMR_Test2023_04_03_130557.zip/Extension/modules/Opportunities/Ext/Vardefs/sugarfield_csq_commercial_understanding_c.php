<?php
 // created: 2020-07-30 08:04:24
$dictionary['Opportunity']['fields']['csq_commercial_understanding_c']['labelValue']='Commercial understanding';
$dictionary['Opportunity']['fields']['csq_commercial_understanding_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_commercial_understanding_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_commercial_understanding_c']['dependency']='';

 ?>