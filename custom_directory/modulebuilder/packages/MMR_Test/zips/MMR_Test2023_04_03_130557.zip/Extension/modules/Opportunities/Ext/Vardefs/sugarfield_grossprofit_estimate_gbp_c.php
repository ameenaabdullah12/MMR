<?php
 // created: 2020-12-10 14:52:36
$dictionary['Opportunity']['fields']['grossprofit_estimate_gbp_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['grossprofit_estimate_gbp_c']['labelValue']='Estimated Gross Profit GBP';
$dictionary['Opportunity']['fields']['grossprofit_estimate_gbp_c']['calculated']='true';
$dictionary['Opportunity']['fields']['grossprofit_estimate_gbp_c']['formula']='round(divide($grossprofit_estimate_c,related($currencies,"conversion_rate")),2)';
$dictionary['Opportunity']['fields']['grossprofit_estimate_gbp_c']['enforced']='true';
$dictionary['Opportunity']['fields']['grossprofit_estimate_gbp_c']['dependency']='equal("Unposted Enquiry",$sales_stage)';

 ?>