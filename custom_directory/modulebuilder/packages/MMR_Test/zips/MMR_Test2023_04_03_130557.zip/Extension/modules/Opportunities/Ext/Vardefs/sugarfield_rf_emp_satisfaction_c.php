<?php
 // created: 2019-02-26 16:37:55
$dictionary['Opportunity']['fields']['rf_emp_satisfaction_c']['labelValue']='Emp. / Customer Satisfaction';
$dictionary['Opportunity']['fields']['rf_emp_satisfaction_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['rf_emp_satisfaction_c']['enforced']='';
$dictionary['Opportunity']['fields']['rf_emp_satisfaction_c']['dependency']='';

 ?>