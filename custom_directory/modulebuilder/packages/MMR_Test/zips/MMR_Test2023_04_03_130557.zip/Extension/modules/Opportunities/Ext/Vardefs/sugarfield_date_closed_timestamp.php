<?php
 // created: 2017-08-22 17:29:58
$dictionary['Opportunity']['fields']['date_closed_timestamp']['audited']=false;
$dictionary['Opportunity']['fields']['date_closed_timestamp']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['date_closed_timestamp']['duplicate_merge_dom_value']=1;
$dictionary['Opportunity']['fields']['date_closed_timestamp']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['date_closed_timestamp']['formula']='timestamp($date_closed)';
$dictionary['Opportunity']['fields']['date_closed_timestamp']['enable_range_search']=false;
$dictionary['Opportunity']['fields']['date_closed_timestamp']['min']=false;
$dictionary['Opportunity']['fields']['date_closed_timestamp']['max']=false;
$dictionary['Opportunity']['fields']['date_closed_timestamp']['disable_num_format']='';

 ?>