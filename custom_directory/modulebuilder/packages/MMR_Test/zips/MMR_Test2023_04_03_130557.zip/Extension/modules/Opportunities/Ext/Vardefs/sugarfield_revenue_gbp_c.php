<?php
 // created: 2020-12-10 14:53:54
$dictionary['Opportunity']['fields']['revenue_gbp_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['revenue_gbp_c']['labelValue']='Estimated Sales GBP';
$dictionary['Opportunity']['fields']['revenue_gbp_c']['calculated']='true';
$dictionary['Opportunity']['fields']['revenue_gbp_c']['formula']='round(divide($revenue_c,related($currencies,"conversion_rate")),2)';
$dictionary['Opportunity']['fields']['revenue_gbp_c']['enforced']='true';
$dictionary['Opportunity']['fields']['revenue_gbp_c']['dependency']='equal("Unposted Enquiry",$sales_stage)';

 ?>