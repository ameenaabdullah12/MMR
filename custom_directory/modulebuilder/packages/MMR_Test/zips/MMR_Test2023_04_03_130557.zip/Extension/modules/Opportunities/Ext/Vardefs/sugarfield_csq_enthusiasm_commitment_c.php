<?php
 // created: 2020-07-30 08:01:37
$dictionary['Opportunity']['fields']['csq_enthusiasm_commitment_c']['labelValue']='Enthusiasm & commitment';
$dictionary['Opportunity']['fields']['csq_enthusiasm_commitment_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_enthusiasm_commitment_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_enthusiasm_commitment_c']['dependency']='';

 ?>