<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['a_project_trans']['override_subpanel_name'] = 'Opportunity_subpanel_a_project_trans';
?>