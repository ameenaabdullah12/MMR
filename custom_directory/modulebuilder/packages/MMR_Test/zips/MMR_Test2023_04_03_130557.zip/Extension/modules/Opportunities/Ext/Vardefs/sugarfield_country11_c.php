<?php
 // created: 2017-09-13 12:31:55
$dictionary['Opportunity']['fields']['country11_c']['labelValue']='Country 11';
$dictionary['Opportunity']['fields']['country11_c']['dependency']='greaterThan(strlen($country10_c),0)';
$dictionary['Opportunity']['fields']['country11_c']['visibility_grid']='';

 ?>