<?php
// created: 2017-04-19 14:06:18
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_UDEF_DETAILCOSTS_TITLE',
  'context' => 
  array (
    'link' => 'udef_detailcosts_opportunities',
  ),
);

$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UDEF_DETAILCOSTS_OPPORTUNITIES_FROM_UDEF_DETAILCOSTS_TITLE',
  'context' => 
  array (
    'link' => 'udef_detailcosts_opportunities',
  ),
);