<?php
 // created: 2017-09-13 12:26:35
$dictionary['Opportunity']['fields']['country3_c']['labelValue']='Country 3';
$dictionary['Opportunity']['fields']['country3_c']['dependency']='greaterThan(strlen($country2_c),0)';
$dictionary['Opportunity']['fields']['country3_c']['visibility_grid']='';

 ?>