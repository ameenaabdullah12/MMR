<?php
 // created: 2017-09-13 12:33:35
$dictionary['Opportunity']['fields']['country13_c']['labelValue']='Country 13';
$dictionary['Opportunity']['fields']['country13_c']['dependency']='greaterThan(strlen($country12_c),0)';
$dictionary['Opportunity']['fields']['country13_c']['visibility_grid']='';

 ?>