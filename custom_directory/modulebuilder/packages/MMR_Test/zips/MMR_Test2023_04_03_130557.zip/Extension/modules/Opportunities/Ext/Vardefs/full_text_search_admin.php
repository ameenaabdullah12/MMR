<?php
 // created: 2022-07-21 11:17:11
$dictionary['Opportunity']['full_text_search']=true;
