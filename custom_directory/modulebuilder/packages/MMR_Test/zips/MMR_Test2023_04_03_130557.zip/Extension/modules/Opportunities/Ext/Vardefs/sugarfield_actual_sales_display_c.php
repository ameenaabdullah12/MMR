<?php
 // created: 2017-09-11 12:02:30
$dictionary['Opportunity']['fields']['actual_sales_display_c']['labelValue']='Total billed';
$dictionary['Opportunity']['fields']['actual_sales_display_c']['enforced']='false';
$dictionary['Opportunity']['fields']['actual_sales_display_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>