<?php
 // created: 2020-10-29 12:22:47
$dictionary['Opportunity']['fields']['rp_complete_c']['labelValue']='Research Complete?';
$dictionary['Opportunity']['fields']['rp_complete_c']['enforced']='';
$dictionary['Opportunity']['fields']['rp_complete_c']['dependency']='isInList($sales_stage,createList("Commissioned","Closed (Debriefed)","Closed (Fully Invoiced)"))';

 ?>