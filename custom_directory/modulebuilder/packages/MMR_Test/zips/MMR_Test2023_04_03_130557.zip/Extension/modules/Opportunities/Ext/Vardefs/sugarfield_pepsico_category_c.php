<?php
 // created: 2020-01-23 15:19:01
$dictionary['Opportunity']['fields']['pepsico_category_c']['labelValue']='PepsiCo Category';
$dictionary['Opportunity']['fields']['pepsico_category_c']['dependency']='equal(related($accounts,"name"),"PEPSICO")';
$dictionary['Opportunity']['fields']['pepsico_category_c']['visibility_grid']='';

 ?>