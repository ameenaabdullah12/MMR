<?php
 // created: 2017-08-22 17:30:57
$dictionary['Opportunity']['fields']['research_description_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['research_description_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['research_description_c']['calculated']='1';
$dictionary['Opportunity']['fields']['research_description_c']['formula']='"MAKE SURE BOXES IN EACH SECTION ADD UP TO 100."';
$dictionary['Opportunity']['fields']['research_description_c']['enforced']='1';
$dictionary['Opportunity']['fields']['research_description_c']['dependency']='';

 ?>