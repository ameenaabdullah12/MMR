<?php
 // created: 2017-08-22 17:30:58
$dictionary['Opportunity']['fields']['test_display_1a_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['test_display_1a_c']['enforced']='';
$dictionary['Opportunity']['fields']['test_display_1a_c']['dependency']='equal($test_dropdown_c,"Option_1")';

 ?>