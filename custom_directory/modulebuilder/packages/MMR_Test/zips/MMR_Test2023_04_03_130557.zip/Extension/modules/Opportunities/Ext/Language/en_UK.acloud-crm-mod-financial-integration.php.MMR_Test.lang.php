<?php

$mod_strings['LBL_OPPORTUNITIES_A_PROJECT_TRANSACTION_1_FROM_OPPORTUNITIES_TITLE'] = 'Project Transactions';
$mod_strings['LBL_PROJECT_TEMPLATE'] = 'Project Template';