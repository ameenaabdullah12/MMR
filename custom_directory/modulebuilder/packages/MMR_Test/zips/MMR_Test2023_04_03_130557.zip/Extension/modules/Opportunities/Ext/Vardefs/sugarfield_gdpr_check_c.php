<?php
 // created: 2018-07-05 14:49:30
$dictionary['Opportunity']['fields']['gdpr_check_c']['labelValue']='GDPR check';
$dictionary['Opportunity']['fields']['gdpr_check_c']['dependency']='';
$dictionary['Opportunity']['fields']['gdpr_check_c']['visibility_grid']='';

 ?>