<?php
 // created: 2022-04-27 15:39:42
$dictionary['Opportunity']['fields']['opportunity_programme_c']['labelValue']='Programme:';
$dictionary['Opportunity']['fields']['opportunity_programme_c']['dependency']='';
$dictionary['Opportunity']['fields']['opportunity_programme_c']['visibility_grid']='';

 ?>