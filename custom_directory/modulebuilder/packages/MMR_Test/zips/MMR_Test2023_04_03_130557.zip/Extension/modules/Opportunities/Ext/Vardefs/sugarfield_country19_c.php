<?php
 // created: 2017-09-13 12:40:08
$dictionary['Opportunity']['fields']['country19_c']['labelValue']='Country 19';
$dictionary['Opportunity']['fields']['country19_c']['dependency']='greaterThan(strlen($country18_c),0)';
$dictionary['Opportunity']['fields']['country19_c']['visibility_grid']='';

 ?>