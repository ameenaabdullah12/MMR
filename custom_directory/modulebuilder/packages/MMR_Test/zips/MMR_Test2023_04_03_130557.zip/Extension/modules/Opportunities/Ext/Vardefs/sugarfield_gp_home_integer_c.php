<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['gp_home_integer_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['gp_home_integer_c']['full_text_search']=array (
  'boost' => 1,
  'enabled' => true,
);
$dictionary['Opportunity']['fields']['gp_home_integer_c']['calculated']='true';
$dictionary['Opportunity']['fields']['gp_home_integer_c']['formula']='$hc_grossprofit_c';
$dictionary['Opportunity']['fields']['gp_home_integer_c']['enforced']='true';
$dictionary['Opportunity']['fields']['gp_home_integer_c']['dependency']='';

 ?>