<?php
// created: 2012-11-08 14:02:59
$dictionary["Opportunity"]["fields"]["a_order_header_opportunities"] = array (
  'name' => 'a_order_header_opportunities',
  'type' => 'link',
  'relationship' => 'a_order_header_opportunities',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_A_ORDER_HEADER_OPPORTUNITIES_FROM_A_ORDER_HEADER_TITLE',
);
