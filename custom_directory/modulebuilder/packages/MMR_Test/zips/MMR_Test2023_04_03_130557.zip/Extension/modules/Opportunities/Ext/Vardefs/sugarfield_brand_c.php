<?php
 // created: 2021-11-09 12:50:44
$dictionary['Opportunity']['fields']['brand_c']['labelValue']='Brand';
$dictionary['Opportunity']['fields']['brand_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['brand_c']['enforced']='';
$dictionary['Opportunity']['fields']['brand_c']['dependency']='not(isInList($mmr_group_lead_c,createList("Together")))';

 ?>