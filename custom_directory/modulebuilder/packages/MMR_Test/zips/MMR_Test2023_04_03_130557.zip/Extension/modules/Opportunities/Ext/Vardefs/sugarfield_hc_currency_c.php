<?php
 // created: 2017-09-11 12:04:35
$dictionary['Opportunity']['fields']['hc_currency_c']['labelValue']='Home Currency';
$dictionary['Opportunity']['fields']['hc_currency_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['hc_currency_c']['enforced']='';

 ?>