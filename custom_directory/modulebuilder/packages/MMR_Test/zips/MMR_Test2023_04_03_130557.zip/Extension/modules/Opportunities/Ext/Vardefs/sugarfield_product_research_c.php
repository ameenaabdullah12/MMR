<?php
 // created: 2019-01-04 16:06:25
$dictionary['Opportunity']['fields']['product_research_c']['labelValue']='Could this project include testing product(s)?';
$dictionary['Opportunity']['fields']['product_research_c']['dependency']='';
$dictionary['Opportunity']['fields']['product_research_c']['visibility_grid']='';

 ?>