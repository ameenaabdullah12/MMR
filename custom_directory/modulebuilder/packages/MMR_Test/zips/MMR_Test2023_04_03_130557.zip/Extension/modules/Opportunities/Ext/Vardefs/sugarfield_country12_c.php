<?php
 // created: 2017-09-13 12:32:58
$dictionary['Opportunity']['fields']['country12_c']['labelValue']='Country 12';
$dictionary['Opportunity']['fields']['country12_c']['dependency']='greaterThan(strlen($country11_c),0)';
$dictionary['Opportunity']['fields']['country12_c']['visibility_grid']='';

 ?>