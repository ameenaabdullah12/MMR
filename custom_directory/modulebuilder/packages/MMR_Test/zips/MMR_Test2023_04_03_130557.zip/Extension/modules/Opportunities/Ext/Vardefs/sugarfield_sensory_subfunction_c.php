<?php
 // created: 2023-02-01 15:28:16
$dictionary['Opportunity']['fields']['sensory_subfunction_c']['labelValue']='Sub-function';
$dictionary['Opportunity']['fields']['sensory_subfunction_c']['visibility_grid']=array (
  'trigger' => 'project_function_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Quant' => 
    array (
    ),
    'Qual' => 
    array (
    ),
    'Sensory_Qual' => 
    array (
    ),
    'Sensory' => 
    array (
      0 => '',
      1 => 'Sensory_SSC',
      2 => 'Sensory_CM',
    ),
    'CCS' => 
    array (
    ),
  ),
);

 ?>