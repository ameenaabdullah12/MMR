<?php
 // created: 2023-02-06 18:35:06
$dictionary['Opportunity']['fields']['cm_panels_c']['labelValue']='Client Panels';
$dictionary['Opportunity']['fields']['cm_panels_c']['dependency']='';
$dictionary['Opportunity']['fields']['cm_panels_c']['visibility_grid']=array (
  'trigger' => 'sensory_subfunction_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Sensory_SSC' => 
    array (
    ),
    'Sensory_CM' => 
    array (
      0 => '',
      1 => 'Haleon_US',
      2 => 'LOreal_US',
      3 => 'Tate_n_Lyle_US',
      4 => 'Keurig _Dr_Pepper_US',
      5 => 'MARS_UK',
      6 => 'Pladis_UK',
      7 => 'Diageo_UK',
      8 => 'IIF_NL',
      9 => 'Danone_NL',
      10 => 'Tate_n_Lyle_EMEA',
      11 => 'P_n_G_SG',
      12 => 'Diageo_IN',
      13 => 'Diageo_CN',
      14 => 'Mars_CN',
      15 => 'Tate_n_Lyle_CN',
    ),
  ),
);

 ?>