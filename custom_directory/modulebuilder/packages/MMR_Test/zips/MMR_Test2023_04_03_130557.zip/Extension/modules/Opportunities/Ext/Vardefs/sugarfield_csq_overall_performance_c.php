<?php
 // created: 2020-07-30 08:03:12
$dictionary['Opportunity']['fields']['csq_overall_performance_c']['labelValue']='How would you rate the team\'s overall performance on this project?';
$dictionary['Opportunity']['fields']['csq_overall_performance_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['csq_overall_performance_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_overall_performance_c']['dependency']='';

 ?>