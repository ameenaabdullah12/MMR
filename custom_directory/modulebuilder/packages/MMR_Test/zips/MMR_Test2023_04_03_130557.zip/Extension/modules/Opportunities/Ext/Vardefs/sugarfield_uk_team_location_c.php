<?php
 // created: 2023-02-06 21:04:51
$dictionary['Opportunity']['fields']['uk_team_location_c']['labelValue']='Team Location';
$dictionary['Opportunity']['fields']['uk_team_location_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['uk_team_location_c']['enforced']='false';
$dictionary['Opportunity']['fields']['uk_team_location_c']['dependency']='';

 ?>