<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['grossprofit_display_c']['formula']='$grossprofit_c';
$dictionary['Opportunity']['fields']['grossprofit_display_c']['enforced']='false';
$dictionary['Opportunity']['fields']['grossprofit_display_c']['dependency']='not(equal("Unposted Enquiry",$sales_stage))';

 ?>