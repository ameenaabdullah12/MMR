<?php
 // created: 2018-01-17 14:13:55
$dictionary['Opportunity']['fields']['test_display_1_c']['labelValue']='TEST DISPLAY 1';
$dictionary['Opportunity']['fields']['test_display_1_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['test_display_1_c']['enforced']='';

 ?>