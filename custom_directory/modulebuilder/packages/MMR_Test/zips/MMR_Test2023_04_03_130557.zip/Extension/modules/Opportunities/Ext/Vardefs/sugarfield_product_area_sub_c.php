<?php
 // created: 2023-03-21 20:58:30
$dictionary['Opportunity']['fields']['product_area_sub_c']['labelValue']='Product Sub-Area';
$dictionary['Opportunity']['fields']['product_area_sub_c']['visibility_grid']=array (
  'trigger' => 'product_area_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Food' => 
    array (
    ),
    'Beverage' => 
    array (
      0 => 'Beverage-Alcoholic-Beers',
      1 => 'Beverage-Alcoholic-Ciders',
      2 => 'Beverage-Alcoholic-Spirits',
      3 => 'Beverage-Alcoholic-Wines',
      4 => 'Beverage-Alcoholic-OtherAlcoholicBeverages',
      5 => 'Beverage-Non-AlcoholicCold-EnergyBeverages',
      6 => 'Beverage-Non-AlcoholicCold-Juices',
      7 => 'Beverage-Non-AlcoholicCold-Smoothies',
      8 => 'Beverage-Non-AlcoholicCold-SoftBeverages',
      9 => 'Beverage-Non-AlcoholicCold-Waters+Vit.Enriched',
      10 => 'Beverage-Non-AlcoholicCold-YoghurtBeverages',
      11 => 'Beverage-Non-AlcoholicCold-OtherColdBeverages',
      12 => 'Beverage-Non-AlcoholicHot-Coffee',
      13 => 'Beverage-Non-AlcoholicHot-Tea',
      14 => 'Beverage-Non-AlcoholicHot-OtherHotBeverages',
    ),
    'PersonalCare' => 
    array (
    ),
    'HouseholdCare' => 
    array (
    ),
    'Pet' => 
    array (
    ),
    'Automotive' => 
    array (
    ),
    'Travel' => 
    array (
    ),
    'FinancialServices' => 
    array (
    ),
    'Charity' => 
    array (
    ),
    'Media' => 
    array (
    ),
    'Technology' => 
    array (
    ),
    'OtherFmcg' => 
    array (
    ),
    'OtherNonFmcg' => 
    array (
    ),
  ),
);

 ?>