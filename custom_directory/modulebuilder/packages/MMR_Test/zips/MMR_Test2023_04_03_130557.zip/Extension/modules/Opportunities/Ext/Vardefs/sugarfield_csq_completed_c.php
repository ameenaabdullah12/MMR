<?php
 // created: 2017-10-11 16:26:08
$dictionary['Opportunity']['fields']['csq_completed_c']['labelValue']='CSQ completed?';
$dictionary['Opportunity']['fields']['csq_completed_c']['enforced']='';
$dictionary['Opportunity']['fields']['csq_completed_c']['dependency']='';

 ?>