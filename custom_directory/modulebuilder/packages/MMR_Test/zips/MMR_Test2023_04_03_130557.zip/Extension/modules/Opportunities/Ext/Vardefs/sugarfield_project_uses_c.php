<?php
 // created: 2020-10-23 10:16:12
$dictionary['Opportunity']['fields']['project_uses_c']['labelValue']='Project Uses';
$dictionary['Opportunity']['fields']['project_uses_c']['dependency']='';
$dictionary['Opportunity']['fields']['project_uses_c']['visibility_grid']=array (
  'trigger' => 'mmr_group_lead_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'MMR' => 
    array (
    ),
    'Cubo' => 
    array (
      0 => 'FIS',
      1 => 'GSR',
      2 => 'MMR',
      3 => 'Express',
      4 => 'Huxly',
      5 => 'Other',
      6 => 'None',
    ),
    'Huxly' => 
    array (
      0 => 'MMR qual',
      1 => 'MMR sensory qual',
      2 => 'MMR other',
      3 => 'Cubo',
      4 => 'Together',
      5 => 'Other',
      6 => 'None',
    ),
  ),
);

 ?>