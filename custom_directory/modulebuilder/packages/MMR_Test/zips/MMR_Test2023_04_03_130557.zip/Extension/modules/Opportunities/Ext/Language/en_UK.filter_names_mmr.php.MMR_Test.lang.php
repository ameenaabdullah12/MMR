<?php
$mod_strings['LBL_COMMISSIONED_DEBRIEFED_PROJECTS'] = '* Commissioned or Debriefed Projects';