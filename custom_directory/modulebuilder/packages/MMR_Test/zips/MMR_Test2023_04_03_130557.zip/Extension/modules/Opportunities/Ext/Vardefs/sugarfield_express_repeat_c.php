<?php
 // created: 2018-08-07 08:48:15
$dictionary['Opportunity']['fields']['express_repeat_c']['labelValue']='Express repeat';
$dictionary['Opportunity']['fields']['express_repeat_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['express_repeat_c']['enforced']='';
$dictionary['Opportunity']['fields']['express_repeat_c']['dependency']='';

 ?>