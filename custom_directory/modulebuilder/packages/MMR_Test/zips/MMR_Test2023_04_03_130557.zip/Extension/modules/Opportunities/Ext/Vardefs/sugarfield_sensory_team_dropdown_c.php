<?php
 // created: 2022-10-11 11:09:00
$dictionary['Opportunity']['fields']['sensory_team_dropdown_c']['labelValue']='Sensory Team:';
$dictionary['Opportunity']['fields']['sensory_team_dropdown_c']['dependency']='equal($expert_sensory_checkbox_c,true)';
$dictionary['Opportunity']['fields']['sensory_team_dropdown_c']['visibility_grid']='';

 ?>