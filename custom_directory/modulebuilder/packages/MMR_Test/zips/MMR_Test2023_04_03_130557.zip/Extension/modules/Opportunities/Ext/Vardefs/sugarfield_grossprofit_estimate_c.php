<?php
 // created: 2017-09-14 14:14:50
$dictionary['Opportunity']['fields']['grossprofit_estimate_c']['labelValue']='Estimated Gross Profit';
$dictionary['Opportunity']['fields']['grossprofit_estimate_c']['enforced']='';
$dictionary['Opportunity']['fields']['grossprofit_estimate_c']['dependency']='equal("Unposted Enquiry",$sales_stage)';
$dictionary['Opportunity']['fields']['grossprofit_estimate_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>