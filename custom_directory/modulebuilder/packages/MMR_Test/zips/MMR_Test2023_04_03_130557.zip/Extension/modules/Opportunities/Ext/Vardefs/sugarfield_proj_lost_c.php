<?php
 // created: 2017-08-22 17:30:56
$dictionary['Opportunity']['fields']['proj_lost_c']['enforced']='';
$dictionary['Opportunity']['fields']['proj_lost_c']['dependency']='';

 ?>