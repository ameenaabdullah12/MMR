<?php
 // created: 2017-08-22 16:49:38
$dictionary['Opportunity']['fields']['description']['required'] = true;
$dictionary['Opportunity']['fields']['description']['comments'] = 'Full text of the note';
$dictionary['Opportunity']['fields']['description']['merge_filter'] = 'disabled';
$dictionary['Opportunity']['fields']['description']['calculated'] = false;
$dictionary['Opportunity']['fields']['description']['full_text_search']['enabled'] = true;
$dictionary['Opportunity']['fields']['description']['full_text_search']['searchable'] = true;
$dictionary['Opportunity']['fields']['description']['full_text_search']['boost'] = 0.59;

