<?php
 // created: 2020-10-15 14:21:53
$dictionary['Opportunity']['fields']['norms_status_c']['labelValue']='Norms Status';
$dictionary['Opportunity']['fields']['norms_status_c']['dependency']='isInList($mmr_group_lead_c,createList("","MMR"))';
$dictionary['Opportunity']['fields']['norms_status_c']['visibility_grid']='';

 ?>