<?php
 // created: 2017-08-22 17:30:55
$dictionary['Opportunity']['fields']['client_services_director_c']['dependency']='';

 ?>