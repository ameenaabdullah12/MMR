<?php
$viewdefs['Opportunities'] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'list' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'label' => 'LBL_PANEL_DEFAULT',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'auto_number',
                'default' => true,
                'enabled' => true,
                'type' => 'int',
                'label' => 'LBL_OPP_AUTO_NUMBER',
              ),
              1 => 
              array (
                'name' => 'name',
                'link' => true,
                'label' => 'LBL_LIST_OPPORTUNITY_NAME',
                'enabled' => true,
                'default' => true,
                'related_fields' => 
                array (
                  0 => 'total_revenue_line_items',
                  1 => 'closed_revenue_line_items',
                  2 => 'included_revenue_line_items',
                ),
              ),
              2 => 
              array (
                'name' => 'description',
                'label' => 'LBL_DESCRIPTION',
                'enabled' => true,
                'sortable' => false,
                'default' => true,
              ),
              3 => 
              array (
                'name' => 'account_name',
                'link' => true,
                'label' => 'LBL_LIST_ACCOUNT_NAME',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
                'id' => 'ACCOUNT_ID',
                'ACLTag' => 'ACCOUNT',
                'contextMenu' => 
                array (
                  'objectType' => 'sugarAccount',
                  'metaData' => 
                  array (
                    'return_module' => 'Contacts',
                    'return_action' => 'ListView',
                    'module' => 'Accounts',
                    'parent_id' => '{$ACCOUNT_ID}',
                    'parent_name' => '{$ACCOUNT_NAME}',
                    'account_id' => '{$ACCOUNT_ID}',
                    'account_name' => '{$ACCOUNT_NAME}',
                  ),
                ),
                'related_fields' => 
                array (
                  0 => 'account_id',
                ),
              ),
              4 => 
              array (
                'name' => 'contacts_opportunities_1_name',
                'label' => 'LBL_CONTACTS_OPPORTUNITIES_1_FROM_CONTACTS_TITLE',
                'enabled' => true,
                'id' => 'CONTACTS_OPPORTUNITIES_1CONTACTS_IDA',
                'link' => true,
                'sortable' => false,
                'default' => true,
              ),
              5 => 
              array (
                'name' => 'sales_stage',
                'label' => 'LBL_LIST_SALES_STAGE',
                'enabled' => true,
                'default' => true,
              ),
              6 => 
              array (
                'name' => 'hc_salesvalue_c',
                'label' => 'LBL_HC_SALESVALUE',
                'enabled' => true,
                'default' => true,
              ),
              7 => 
              array (
                'name' => 'hc_grossprofit_c',
                'label' => 'LBL_HC_GROSSPROFIT',
                'enabled' => true,
                'default' => true,
              ),
              8 => 
              array (
                'name' => 'revenue_c',
                'default' => true,
                'enabled' => true,
                'type' => 'currency',
                'label' => 'LBL_REVENUE',
                'currency_format' => true,
              ),
              9 => 
              array (
                'name' => 'grossprofit_estimate_c',
                'label' => 'LBL_GROSSPROFIT_ESTIMATE',
                'enabled' => true,
                'related_fields' => 
                array (
                  0 => 'currency_id',
                  1 => 'base_rate',
                ),
                'currency_format' => true,
                'default' => true,
              ),
              10 => 
              array (
                'name' => 'date_entered',
                'label' => 'LBL_DATE_ENTERED',
                'enabled' => true,
                'default' => true,
                'readonly' => true,
              ),
              11 => 
              array (
                'name' => 'assigned_user_name',
                'label' => 'LBL_LIST_ASSIGNED_USER',
                'id' => 'ASSIGNED_USER_ID',
                'enabled' => true,
                'default' => true,
                'sortable' => true,
              ),
              12 => 
              array (
                'name' => 'commissioned_date_c',
                'default' => true,
                'enabled' => true,
                'type' => 'date',
                'label' => 'LBL_COMMISSIONED_DATE',
              ),
              13 => 
              array (
                'name' => 'norms_status_c',
                'label' => 'LBL_NORMS_STATUS',
                'enabled' => true,
                'default' => true,
              ),
              14 => 
              array (
                'name' => 'csd_team_c',
                'label' => 'LBL_CSD_TEAM',
                'enabled' => true,
                'default' => true,
              ),
              15 => 
              array (
                'name' => 'p_number_c',
                'label' => 'LBL_P_NUMBER',
                'enabled' => true,
                'default' => true,
              ),
              16 => 
              array (
                'name' => 'modified_by_name',
                'label' => 'LBL_MODIFIED',
                'enabled' => true,
                'default' => true,
                'readonly' => true,
                'sortable' => true,
              ),
              17 => 
              array (
                'name' => 'mmr_group_lead_c',
                'label' => 'LBL_MMR_GROUP_LEAD',
                'enabled' => true,
                'default' => true,
              ),
              18 => 
              array (
                'name' => 'exclude_acloud_invrep_c',
                'label' => 'LBL_EXCLUDE_ACLOUD_INVREP',
                'enabled' => true,
                'default' => true,
              ),
              19 => 
              array (
                'name' => 'invoice_tracker_comments_c',
                'label' => 'LBL_INVOICE_TRACKER_COMMENTS',
                'enabled' => true,
                'sortable' => false,
                'default' => true,
              ),
              20 => 
              array (
                'name' => 'invoice_tracker_comments_tex_c',
                'label' => 'LBL_INVOICE_TRACKER_COMMENTS_TEX',
                'enabled' => true,
                'default' => true,
              ),
              21 => 
              array (
                'name' => 'tag',
                'label' => 'LBL_TAGS',
                'enabled' => true,
                'default' => true,
              ),
              22 => 
              array (
                'name' => 'opportunity_programme_c',
                'label' => 'LBL_OPPORTUNITY_PROGRAMME',
                'enabled' => true,
                'default' => false,
              ),
              23 => 
              array (
                'name' => 'opportunity_type',
                'label' => 'LBL_TYPE',
                'enabled' => true,
                'default' => false,
              ),
              24 => 
              array (
                'name' => 'hc_currency_c',
                'label' => 'LBL_HC_CURRENCY',
                'enabled' => true,
                'default' => false,
              ),
              25 => 
              array (
                'name' => 'date_modified',
                'label' => 'LBL_DATE_MODIFIED',
                'enabled' => true,
                'readonly' => true,
                'default' => false,
              ),
              26 => 
              array (
                'name' => 'lead_source',
                'label' => 'LBL_LEAD_SOURCE',
                'enabled' => true,
                'default' => false,
              ),
              27 => 
              array (
                'name' => 'revenue_gbp_c',
                'label' => 'LBL_REVENUE_GBP',
                'enabled' => true,
                'default' => false,
              ),
              28 => 
              array (
                'name' => 'grossprofit_estimate_gbp_c',
                'label' => 'LBL_GROSSPROFIT_ESTIMATE_GBP',
                'enabled' => true,
                'default' => false,
              ),
              29 => 
              array (
                'name' => 'loss_reason_c',
                'label' => 'LBL_LOSS_REASON',
                'enabled' => true,
                'default' => false,
              ),
              30 => 
              array (
                'name' => 'project_type_c',
                'label' => 'LBL_PROJECT_TYPE',
                'enabled' => true,
                'default' => false,
              ),
              31 => 
              array (
                'name' => 'next_step',
                'label' => 'LBL_NEXT_STEP',
                'enabled' => true,
                'default' => false,
              ),
              32 => 
              array (
                'name' => 'probability',
                'label' => 'LBL_PROBABILITY',
                'enabled' => true,
                'default' => false,
              ),
              33 => 
              array (
                'name' => 'bd_stage_c',
                'label' => 'LBL_BD_STAGE',
                'enabled' => true,
                'default' => false,
              ),
              34 => 
              array (
                'name' => 'created_by_name',
                'label' => 'LBL_CREATED',
                'enabled' => true,
                'default' => false,
                'readonly' => true,
                'sortable' => true,
              ),
              35 => 
              array (
                'name' => 'team_name',
                'type' => 'teamset',
                'label' => 'LBL_LIST_TEAM',
                'enabled' => true,
                'default' => false,
              ),
              36 => 
              array (
                'name' => 'defined_methods_c',
                'label' => 'LBL_DEFINED_METHODS',
                'enabled' => true,
                'default' => false,
              ),
              37 => 
              array (
                'name' => 'fieldwork_location_c',
                'label' => 'LBL_FIELDWORK_LOCATION',
                'enabled' => true,
                'default' => false,
              ),
              38 => 
              array (
                'name' => 'rf_total_c',
                'label' => 'LBL_RF_TOTAL',
                'enabled' => true,
                'default' => false,
              ),
              39 => 
              array (
                'name' => 'product_area_c',
                'label' => 'LBL_PRODUCT_AREA',
                'enabled' => true,
                'default' => false,
              ),
              40 => 
              array (
                'name' => 'rm_total_c',
                'label' => 'LBL_RM_TOTAL',
                'enabled' => true,
                'default' => false,
              ),
              41 => 
              array (
                'name' => 'profit_margin_c',
                'label' => 'LBL_PROFIT_MARGIN',
                'enabled' => true,
                'default' => false,
              ),
              42 => 
              array (
                'name' => 'debrief_date_c',
                'label' => 'LBL_DEBRIEF_DATE',
                'enabled' => true,
                'default' => false,
              ),
              43 => 
              array (
                'name' => 'grossprofit_c',
                'default' => false,
                'enabled' => true,
                'type' => 'currency',
                'label' => 'LBL_GROSSPROFIT',
                'currency_format' => true,
              ),
              44 => 
              array (
                'name' => 'actual_sales_c',
                'default' => false,
                'enabled' => true,
                'type' => 'currency',
                'label' => 'LBL_ACTUAL_SALES',
                'currency_format' => true,
              ),
              45 => 
              array (
                'name' => 'date_closed',
                'label' => 'LBL_DATE_CLOSED',
                'enabled' => true,
                'default' => false,
                'width' => '10',
              ),
              46 => 
              array (
                'name' => 'rp_complete_c',
                'label' => 'LBL_RP_COMPLETE',
                'enabled' => true,
                'default' => false,
              ),
              47 => 
              array (
                'name' => 'actual_sales_display_c',
                'default' => false,
                'enabled' => true,
                'type' => 'currency',
                'label' => 'LBL_ACTUAL_SALES_DISPLAY',
                'currency_format' => true,
              ),
              48 => 
              array (
                'name' => 'currencytest_c',
                'label' => 'LBL_CURRENCYTEST',
                'enabled' => true,
                'related_fields' => 
                array (
                  0 => 'currency_id',
                  1 => 'base_rate',
                ),
                'currency_format' => true,
                'default' => false,
              ),
              49 => 
              array (
                'name' => 'c_primary_key',
                'label' => 'LBL_A_PRIMARY_KEY',
                'enabled' => true,
                'default' => false,
              ),
              50 => 
              array (
                'name' => 'qual_percent_new_c',
                'label' => 'LBL_QUAL_PERCENT_NEW',
                'enabled' => true,
                'default' => false,
              ),
              51 => 
              array (
                'name' => 'second_team_c',
                'label' => 'LBL_SECOND_TEAM',
                'enabled' => true,
                'default' => false,
              ),
              52 => 
              array (
                'name' => 'expressyesno_c',
                'label' => 'LBL_EXPRESSYESNO',
                'enabled' => true,
                'default' => false,
              ),
              53 => 
              array (
                'name' => 'actual_sales_gbp_c',
                'label' => 'LBL_ACTUAL_SALES_GBP',
                'enabled' => true,
                'default' => false,
              ),
              54 => 
              array (
                'name' => 'grossprofit_gbp_c',
                'label' => 'LBL_GROSSPROFIT_GBP',
                'enabled' => true,
                'default' => false,
              ),
              55 => 
              array (
                'name' => 'base_rate',
                'label' => 'LBL_CURRENCY_RATE',
                'enabled' => true,
                'readonly' => true,
                'sortable' => false,
                'default' => false,
              ),
              56 => 
              array (
                'name' => 'default_dim_db_c',
                'label' => 'LBL_DEFAULT_DIM_DB',
                'enabled' => true,
                'default' => false,
              ),
              57 => 
              array (
                'name' => 'import_tag_c',
                'label' => 'LBL_IMPORT_TAG',
                'enabled' => true,
                'default' => false,
              ),
              58 => 
              array (
                'name' => 'currency_override_c',
                'label' => 'LBL_CURRENCY_OVERRIDE',
                'enabled' => true,
                'related_fields' => 
                array (
                  0 => 'currency_id',
                  1 => 'base_rate',
                ),
                'currency_format' => true,
                'default' => false,
              ),
            ),
          ),
        ),
      ),
    ),
  ),
);
