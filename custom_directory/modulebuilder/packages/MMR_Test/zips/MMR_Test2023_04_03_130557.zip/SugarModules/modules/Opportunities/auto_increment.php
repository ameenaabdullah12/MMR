<?php   

class increment
{
    function autoIncrement(&$bean, $event, $arguments)
    {
        
        //Table Name
	$table = 'opportunities';
	//Boolean to determine if join should happen
	$customTableExists = true;
	//Field you want to increment
	$fieldToIncrement = 'auto_number';
	//Define a string for the beginning and/or end here
	$preString = '';
	$postString = '';
        
	if (empty($bean->$fieldToIncrement))
            {
		$db =  DBManagerFactory::getInstance();
		$query = " select ifnull(convert(replace(replace($fieldToIncrement,'$preString',''),'$postString',''),UNSIGNED INTEGER),0)+1 as num from $table t ";
				
                    if ($customTableExists)
                        {
                        $GLOBALS['log']->fatal('### aCloudOpportunityHooks.increment started?3:');
                            $query .= 	
                            " join $table"."_cstm tc on t.id = tc.id_c ";
				}
				$query .= 	
				" where t.deleted = 0
				order by num desc
				limit 1";
				$result = $db->query($query);	
				$row = $db->fetchByAssoc($result);
                                    if ($row)
                                        {
                                        $GLOBALS['log']->fatal('### aCloudOpportunityHooks.increment started4:');
                                            $newNum = $row[num];
                                            $bean->$fieldToIncrement = $preString.$newNum.$postString;
                                        }
                                    else
                                        {
					sugar_upgrade_exit($db->lastDbError().'<br>'.	$query);
                                        }
            }
                        
    }
}              
?>