<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*
 * Creates a Project from a given Opportunity, and populates the Opportunity with the project id
 */

require_once('modules/Opportunities/Opportunity.php');

// Retrieve the Opportunity bean
$id = $_REQUEST['record'];
$opp = new Opportunity();
$opp->retrieve($id);

createProject($opp);

function createProject($opp)
{
    // add fields to this array if wish to populate additional fields on the project from the opportunity
    // key is project field name, value is opportunity field name
    $fieldsToCopy = array(
        'name' => 'name',
        'description' => 'description'
    );

    // return_* parameters are used to redirect the user back cleanly to the original opportunity,
    // but also for populating the new project ID on the opportunity after creation
    $redirectUrl = "Location: index.php?module=Project&action=EditView&" .
        "return_module=Opportunities&" .
        "return_action=DetailView&" .
        "return_id=" . urlencode($opp->id);

    if (isset($_GET['template']) && !empty($_GET['template']))
        $redirectUrl .= "&a_project_template=" . urlencode($_GET['template']);

    foreach ($fieldsToCopy as $key=>$value)
        $redirectUrl .= "&" . $key . "=" . urlencode($opp->$value);

    header($redirectUrl);

    die();
    /*
    require_once('modules/Project/Project.php');

    $project = new Project();
    $project->name = $opp->name;
    $project->description = $opp->description;

    $project->save();

    $opp->a_primary_project_id = $project->id;
    $opp->save();
    */
}