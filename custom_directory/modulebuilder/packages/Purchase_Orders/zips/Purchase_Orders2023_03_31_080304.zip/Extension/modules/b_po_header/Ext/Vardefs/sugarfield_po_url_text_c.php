<?php
 // created: 2020-10-16 09:47:32
$dictionary['b_po_header']['fields']['po_url_text_c']['labelValue']='PO URL Text';
$dictionary['b_po_header']['fields']['po_url_text_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['po_url_text_c']['formula']='concat("https://mmr-research.acrm.accessacloud.com/#b_po_header/","5fb71bce-d817-11ea-9cc1-00163e104c13")';
$dictionary['b_po_header']['fields']['po_url_text_c']['enforced']='false';
$dictionary['b_po_header']['fields']['po_url_text_c']['dependency']='';

 ?>