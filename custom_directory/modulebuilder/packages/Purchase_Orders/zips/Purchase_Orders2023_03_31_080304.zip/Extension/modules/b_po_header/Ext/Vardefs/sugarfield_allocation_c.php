<?php
 // created: 2021-06-28 12:07:03
$dictionary['b_po_header']['fields']['allocation_c']['labelValue']='Shared/Investment - Allocation';
$dictionary['b_po_header']['fields']['allocation_c']['dependency']='';
$dictionary['b_po_header']['fields']['allocation_c']['visibility_grid']='';

 ?>