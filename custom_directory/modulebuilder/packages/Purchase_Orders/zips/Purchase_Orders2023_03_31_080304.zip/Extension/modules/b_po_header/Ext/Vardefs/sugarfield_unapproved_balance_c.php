<?php
 // created: 2020-12-17 11:08:10
$dictionary['b_po_header']['fields']['unapproved_balance_c']['duplicate_merge_dom_value']=0;
$dictionary['b_po_header']['fields']['unapproved_balance_c']['labelValue']='Unapproved Balance';
$dictionary['b_po_header']['fields']['unapproved_balance_c']['calculated']='1';
$dictionary['b_po_header']['fields']['unapproved_balance_c']['formula']='subtract($grand_total_c,$approved_value_c)';
$dictionary['b_po_header']['fields']['unapproved_balance_c']['enforced']='1';
$dictionary['b_po_header']['fields']['unapproved_balance_c']['dependency']='';

 ?>