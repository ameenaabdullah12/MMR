<?php
 // created: 2020-10-15 23:20:17
$dictionary['b_po_header']['fields']['po_link_c']['labelValue']='PO link';
$dictionary['b_po_header']['fields']['po_link_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['po_link_c']['dependency']='';

 ?>