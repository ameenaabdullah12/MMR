<?php
require_once('modules/b_po_header/b_po_header.php');
class Customb_po_header extends b_po_header
{
function send_assignment_notifications($notify_user, $admin) {
}
}