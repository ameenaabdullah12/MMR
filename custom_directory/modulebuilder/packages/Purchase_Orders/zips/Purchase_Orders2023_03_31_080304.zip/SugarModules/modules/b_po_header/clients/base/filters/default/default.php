<?php
// created: 2020-12-21 10:25:13
$viewdefs['b_po_header']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'created_by_name' => 
    array (
    ),
    'dimensions_database_c' => 
    array (
    ),
    'a_supplier_b_po_header_1_name' => 
    array (
    ),
    'grand_total_c' => 
    array (
    ),
    'unapproved_balance_c' => 
    array (
    ),
    'request_approval_c' => 
    array (
    ),
    'approved_c' => 
    array (
    ),
    'approved_value_c' => 
    array (
    ),
    'created_by_id_c' => 
    array (
    ),
    'tag' => 
    array (
    ),
    'c_primary_key' => 
    array (
    ),
    'assigned_user_name' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
    'poh_status_c' => 
    array (
    ),
    'po_number_c' => 
    array (
    ),
    'auto_number' => 
    array (
    ),
    'sync_error_c' => 
    array (
    ),
  ),
);