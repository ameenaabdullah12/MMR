<?php 
$app_list_strings['mmr_analysis'] = array (
  '' => '',
  40850 => 'Shared - Marketing',
  40851 => 'Shared - NOVA',
  40852 => 'Shared - Recruitment',
  40853 => 'Investment - Marketing',
  40854 => 'Investment - NOVA',
  40855 => 'Investment - Recruitment',
  40856 => 'Shared - Training',
);