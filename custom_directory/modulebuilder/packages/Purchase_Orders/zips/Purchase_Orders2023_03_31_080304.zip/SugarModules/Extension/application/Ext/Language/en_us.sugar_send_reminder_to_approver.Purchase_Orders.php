<?php 
$app_list_strings['send_reminder_to_approver'] = array (
  'Yes' => 'Yes please!',
  'No' => 'No happy to wait',
);