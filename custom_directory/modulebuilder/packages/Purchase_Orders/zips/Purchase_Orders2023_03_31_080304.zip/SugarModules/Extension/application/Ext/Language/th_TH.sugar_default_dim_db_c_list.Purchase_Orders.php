<?php 
$app_list_strings['default_dim_db_c_list'] = array (
  '' => '',
  'UK' => 'EMEA',
  'US' => 'AMER',
  'CHINA' => 'APAC',
  'SA' => 'SA',
  'PTE' => 'Singapore',
  'IN' => 'India',
  'BR' => 'Brazil',
  'Cubo' => 'Cubo',
  'TOG' => 'Together',
  'COL' => 'Columbia',
  'TH' => 'Thailand',
  'NL' => 'Netherlands',
);