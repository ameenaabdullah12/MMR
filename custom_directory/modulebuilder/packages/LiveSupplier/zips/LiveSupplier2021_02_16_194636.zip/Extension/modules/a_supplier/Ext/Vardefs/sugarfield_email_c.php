<?php
 // created: 2019-12-18 09:07:57
$dictionary['a_supplier']['fields']['email_c']['labelValue']='Email';
$dictionary['a_supplier']['fields']['email_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['email_c']['enforced']='';
$dictionary['a_supplier']['fields']['email_c']['dependency']='';

 ?>