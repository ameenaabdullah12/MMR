<?php
 // created: 2019-12-18 09:11:42
$dictionary['a_supplier']['fields']['supplier_code_c']['labelValue']='Supplier Code';
$dictionary['a_supplier']['fields']['supplier_code_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['supplier_code_c']['enforced']='';
$dictionary['a_supplier']['fields']['supplier_code_c']['dependency']='';

 ?>