<?php
 // created: 2020-08-10 12:52:37
$dictionary['a_supplier']['fields']['sort_key_c']['labelValue']='Sort Key';
$dictionary['a_supplier']['fields']['sort_key_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['a_supplier']['fields']['sort_key_c']['enforced']='';
$dictionary['a_supplier']['fields']['sort_key_c']['dependency']='';

 ?>