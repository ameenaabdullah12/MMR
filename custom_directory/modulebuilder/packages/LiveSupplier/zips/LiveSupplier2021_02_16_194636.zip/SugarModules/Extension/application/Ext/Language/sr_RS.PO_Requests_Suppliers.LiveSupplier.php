<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analitičar',
  'Competitor' => 'Konkurent',
  'Customer' => 'Korisnik',
  'Integrator' => 'Integrator',
  'Investor' => 'Investitor',
  'Partner' => 'Partner',
  'Press' => 'Novinar',
  'Prospect' => 'Verovatni Kupac',
  'Reseller' => 'Preprodavac',
  'Other' => 'Ostalo',
  '' => '',
);