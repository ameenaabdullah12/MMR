<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analytiker',
  'Competitor' => 'Mitbewerber',
  'Customer' => 'Kunde',
  'Integrator' => 'Integrator',
  'Investor' => 'Investor',
  'Partner' => 'Partner',
  'Press' => 'Presse',
  'Prospect' => 'Potentieller Kunde',
  'Reseller' => 'Wiederverkäufer',
  'Other' => 'Andere',
  '' => '',
);