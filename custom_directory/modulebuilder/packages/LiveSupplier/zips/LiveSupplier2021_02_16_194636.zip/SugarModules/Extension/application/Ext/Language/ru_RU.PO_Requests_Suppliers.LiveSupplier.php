<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Аналитик',
  'Competitor' => 'Competitor',
  'Customer' => 'Customer',
  'Integrator' => 'Integrator',
  'Investor' => 'Investor',
  'Partner' => 'Партнер',
  'Press' => 'Press',
  'Prospect' => 'Prospect',
  'Reseller' => 'Reseller',
  'Other' => 'Другой',
  '' => '',
);