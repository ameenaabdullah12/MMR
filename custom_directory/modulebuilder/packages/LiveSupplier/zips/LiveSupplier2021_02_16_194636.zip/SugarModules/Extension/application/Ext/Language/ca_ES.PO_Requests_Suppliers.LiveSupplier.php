<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analista',
  'Competitor' => 'Competència',
  'Customer' => 'Client',
  'Integrator' => 'Integrador',
  'Investor' => 'Inversor',
  'Partner' => 'Soci',
  'Press' => 'Premsa',
  'Prospect' => 'Possible client',
  'Reseller' => 'Revenedor',
  'Other' => 'Un altre',
  '' => '',
);