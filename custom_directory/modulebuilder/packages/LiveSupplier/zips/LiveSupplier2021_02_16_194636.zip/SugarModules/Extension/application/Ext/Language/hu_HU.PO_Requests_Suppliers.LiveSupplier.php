<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Elemző',
  'Competitor' => 'Versenytárs',
  'Customer' => 'Ügyfél',
  'Integrator' => 'Integrátor',
  'Investor' => 'Befektető',
  'Partner' => 'Partner',
  'Press' => 'Sajtó',
  'Prospect' => 'Potenciális üzleti partner',
  'Reseller' => 'Viszonteladó',
  'Other' => 'Egyéb',
  '' => '',
);