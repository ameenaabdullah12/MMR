<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => '分析人士',
  'Competitor' => '竞争对手',
  'Customer' => '客户',
  'Integrator' => '整合商',
  'Investor' => '投资者',
  'Partner' => '合作伙伴',
  'Press' => '新闻',
  'Prospect' => '前景',
  'Reseller' => '经销商',
  'Other' => '其他',
  '' => '',
);