<?php 
$app_list_strings['a_supplier_type_dom'] = array (
  'Analyst' => 'Analytiker',
  'Competitor' => 'Konkurent',
  'Customer' => 'Kund',
  'Integrator' => 'Integratör',
  'Investor' => 'Investerare',
  'Partner' => 'Partner',
  'Press' => 'Press',
  'Prospect' => 'Kandidat',
  'Reseller' => 'Återförsäljare',
  'Other' => 'Annan',
  '' => '',
);