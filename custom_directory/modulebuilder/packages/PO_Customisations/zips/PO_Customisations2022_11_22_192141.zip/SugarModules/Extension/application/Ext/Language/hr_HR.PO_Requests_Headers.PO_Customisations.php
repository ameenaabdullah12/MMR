<?php 
$app_list_strings['b_po_header_type_dom'] = array (
  'Existing Business' => 'Postojeće poduzeće',
  'New Business' => 'Novo poduzeće',
  '' => '',
);