<?php

$dictionary['b_po_header']['fields']['assigned_user_id']['default']='';
$dictionary['b_po_header']['fields']['assigned_user_id']['required']=true;

 ?>