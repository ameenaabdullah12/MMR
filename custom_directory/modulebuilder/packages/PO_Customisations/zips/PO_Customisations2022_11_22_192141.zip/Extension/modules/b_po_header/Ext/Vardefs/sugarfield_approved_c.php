<?php
 // created: 2020-10-28 23:28:39
$dictionary['b_po_header']['fields']['approved_c']['labelValue']='Approved';
$dictionary['b_po_header']['fields']['approved_c']['enforced']='';
$dictionary['b_po_header']['fields']['approved_c']['dependency']='';

 ?>