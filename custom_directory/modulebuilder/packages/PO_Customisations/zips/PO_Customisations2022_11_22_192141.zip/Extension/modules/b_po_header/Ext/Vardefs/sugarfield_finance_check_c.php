<?php
 // created: 2020-12-02 22:54:11
$dictionary['b_po_header']['fields']['finance_check_c']['labelValue']='Finance check';
$dictionary['b_po_header']['fields']['finance_check_c']['enforced']='';
$dictionary['b_po_header']['fields']['finance_check_c']['dependency']='';

 ?>