<?php
 // created: 2019-12-18 14:20:30
$dictionary['b_po_header']['fields']['batch_ref_c']['labelValue']='Batch Ref';
$dictionary['b_po_header']['fields']['batch_ref_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['batch_ref_c']['enforced']='';
$dictionary['b_po_header']['fields']['batch_ref_c']['dependency']='';

 ?>