<?php
 // created: 2020-08-07 10:16:46
$dictionary['b_po_header']['fields']['warning_c']['labelValue']='Approval Warning';
$dictionary['b_po_header']['fields']['warning_c']['dependency']='and(equal($request_approval_c,0),greaterThan($grand_total_c,0))';

 ?>