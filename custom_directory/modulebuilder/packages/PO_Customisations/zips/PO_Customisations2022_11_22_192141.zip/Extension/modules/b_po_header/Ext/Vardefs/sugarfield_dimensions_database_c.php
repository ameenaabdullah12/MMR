<?php
 // created: 2020-10-28 23:29:47
$dictionary['b_po_header']['fields']['dimensions_database_c']['labelValue']='Dimensions Database';
$dictionary['b_po_header']['fields']['dimensions_database_c']['dependency']='';
$dictionary['b_po_header']['fields']['dimensions_database_c']['visibility_grid']='';

 ?>