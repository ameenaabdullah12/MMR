<?php

$hook_array['before_save'][] = Array(150,'Update record to sync','custom/modules/b_po_header/po_header_hooks.php','updatePO_header','update_record_to_sync');
