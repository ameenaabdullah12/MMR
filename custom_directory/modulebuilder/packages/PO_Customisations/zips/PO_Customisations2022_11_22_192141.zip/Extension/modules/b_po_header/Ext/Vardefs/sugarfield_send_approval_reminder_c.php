<?php
 // created: 2020-10-19 14:14:20
$dictionary['b_po_header']['fields']['send_approval_reminder_c']['labelValue']='Send your approver a reminder?';
$dictionary['b_po_header']['fields']['send_approval_reminder_c']['dependency']='and(equal(1,$request_approval_c),equal(0,$approved_c))';

 ?>