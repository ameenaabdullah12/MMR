<?php
 // created: 2019-12-18 13:57:47
$dictionary['b_po_header']['fields']['line_value_increase_c']['labelValue']='Line Value Increase';
$dictionary['b_po_header']['fields']['line_value_increase_c']['enforced']='';
$dictionary['b_po_header']['fields']['line_value_increase_c']['dependency']='';

 ?>