<?php
 // created: 2019-12-18 14:43:44
$dictionary['c_po_detail']['fields']['dimensions_received_qty_c']['labelValue']='Dimensions Received Qty';
$dictionary['c_po_detail']['fields']['dimensions_received_qty_c']['enforced']='';
$dictionary['c_po_detail']['fields']['dimensions_received_qty_c']['dependency']='';

 ?>