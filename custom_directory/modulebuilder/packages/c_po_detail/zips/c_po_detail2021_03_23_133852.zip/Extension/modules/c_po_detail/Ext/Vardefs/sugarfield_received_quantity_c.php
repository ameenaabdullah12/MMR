<?php
 // created: 2020-10-28 23:07:44
$dictionary['c_po_detail']['fields']['received_quantity_c']['labelValue']='Received Quantity';
$dictionary['c_po_detail']['fields']['received_quantity_c']['enforced']='';
$dictionary['c_po_detail']['fields']['received_quantity_c']['dependency']='';

 ?>