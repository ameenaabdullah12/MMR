<?php
 // created: 2021-03-16 12:17:12
$dictionary['c_po_detail']['fields']['price_c']['labelValue']='Price';
$dictionary['c_po_detail']['fields']['price_c']['enforced']='';
$dictionary['c_po_detail']['fields']['price_c']['dependency']='';
$dictionary['c_po_detail']['fields']['price_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>