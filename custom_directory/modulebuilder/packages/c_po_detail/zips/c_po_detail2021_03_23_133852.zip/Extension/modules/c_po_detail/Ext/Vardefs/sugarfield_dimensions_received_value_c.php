<?php
 // created: 2020-02-06 17:04:14
$dictionary['c_po_detail']['fields']['dimensions_received_value_c']['labelValue']='Dimensions Received Value';
$dictionary['c_po_detail']['fields']['dimensions_received_value_c']['enforced']='';
$dictionary['c_po_detail']['fields']['dimensions_received_value_c']['dependency']='';
$dictionary['c_po_detail']['fields']['dimensions_received_value_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>