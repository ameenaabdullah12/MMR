<?php
 // created: 2020-12-14 13:18:50
$dictionary['c_po_detail']['fields']['c_primary_key']['audited']=true;

 ?>