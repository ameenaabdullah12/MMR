<?php
 // created: 2020-10-08 22:31:57
$dictionary['c_po_detail']['fields']['project_calc_c']['duplicate_merge_dom_value']=0;
$dictionary['c_po_detail']['fields']['project_calc_c']['labelValue']='Project calc';
$dictionary['c_po_detail']['fields']['project_calc_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['c_po_detail']['fields']['project_calc_c']['calculated']='true';
$dictionary['c_po_detail']['fields']['project_calc_c']['formula']='related($opportunities_c_po_detail_1,"auto_number")';
$dictionary['c_po_detail']['fields']['project_calc_c']['enforced']='true';
$dictionary['c_po_detail']['fields']['project_calc_c']['dependency']='';

 ?>