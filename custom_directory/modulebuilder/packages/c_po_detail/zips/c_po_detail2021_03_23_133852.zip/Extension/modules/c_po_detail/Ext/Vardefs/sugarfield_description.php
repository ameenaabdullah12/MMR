<?php
 // created: 2020-06-25 15:37:23
$dictionary['c_po_detail']['fields']['description']['required']=true;
$dictionary['c_po_detail']['fields']['description']['audited']=false;
$dictionary['c_po_detail']['fields']['description']['massupdate']=false;
$dictionary['c_po_detail']['fields']['description']['comments']='Description of the sale';
$dictionary['c_po_detail']['fields']['description']['duplicate_merge']='enabled';
$dictionary['c_po_detail']['fields']['description']['duplicate_merge_dom_value']='1';
$dictionary['c_po_detail']['fields']['description']['merge_filter']='disabled';
$dictionary['c_po_detail']['fields']['description']['unified_search']=false;
$dictionary['c_po_detail']['fields']['description']['full_text_search']=array (
  'enabled' => true,
  'boost' => '0.58',
  'searchable' => true,
);
$dictionary['c_po_detail']['fields']['description']['calculated']=false;
$dictionary['c_po_detail']['fields']['description']['rows']='6';
$dictionary['c_po_detail']['fields']['description']['cols']='80';

 ?>