<?php
 // created: 2020-10-28 23:06:28
$dictionary['c_po_detail']['fields']['po_status_c']['labelValue']='PO Status';
$dictionary['c_po_detail']['fields']['po_status_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['c_po_detail']['fields']['po_status_c']['enforced']='';
$dictionary['c_po_detail']['fields']['po_status_c']['dependency']='';

 ?>