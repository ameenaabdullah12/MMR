<?php
$dictionary['c_po_detail']['duplicate_check']['enabled'] = false;