<?php
 // created: 2020-11-06 11:40:43
$dictionary['c_po_detail']['fields']['po_link_url_correct_c']['labelValue']='po link url correct';
$dictionary['c_po_detail']['fields']['po_link_url_correct_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['c_po_detail']['fields']['po_link_url_correct_c']['dependency']='';

 ?>