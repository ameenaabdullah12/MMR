<?php
 // created: 2021-03-16 12:17:12
$dictionary['c_po_detail']['fields']['cancel_line_c']['labelValue']='Cancel Line';
$dictionary['c_po_detail']['fields']['cancel_line_c']['enforced']='false';
$dictionary['c_po_detail']['fields']['cancel_line_c']['dependency']='not(greaterThan(number($po_status_c),1))';

 ?>