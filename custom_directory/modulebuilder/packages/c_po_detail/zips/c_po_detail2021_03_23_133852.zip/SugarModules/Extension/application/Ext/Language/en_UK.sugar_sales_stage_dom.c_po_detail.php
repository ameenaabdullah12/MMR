<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Unposted Enquiry' => 'Opportunity',
  'Posted Proposal' => 'Proposal Sent',
  'Commissioned' => 'Commissioned',
  'Closed (Debriefed)' => 'Closed (Debriefed)',
  'Closed (Aborted)' => 'Closed Lost',
  'Closed (Fully Invoiced)' => 'Closed (Fully Invoiced)',
  '' => '',
);