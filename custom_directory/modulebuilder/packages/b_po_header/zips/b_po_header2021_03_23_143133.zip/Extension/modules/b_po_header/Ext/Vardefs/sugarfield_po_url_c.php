<?php
 // created: 2020-11-06 11:33:45
$dictionary['b_po_header']['fields']['po_url_c']['labelValue']='po url';
$dictionary['b_po_header']['fields']['po_url_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['po_url_c']['dependency']='';

 ?>