<?php

$dependencies['b_po_header']['b_po_header_read_only'] = array(
    'hooks' => array("edit"),
    'trigger' => 'true',
    'triggerFields' => 'dimensions_database_c',
    'onload' => true,
    'actions' => array(
		
		//***** ALWAYS ReadOnly
		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'a_supplier_b_po_header_1_name',
                'value' => 'or(equal($dimensions_database_c,""),not(equal($c_primary_key,"")))',
            ),
        ),
		
		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'dimensions_database_c',
                'value' => 'not(equal($c_primary_key,""))',
            ),
        ),

		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'approved_c',
                'value' => 'true',
            ),
        ),
		
		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'currency_id',
                'value' => 'true',
            ),
        ),
		
		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'date_approved_c',
                'value' => 'true',
            ),
        ),
		
		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'po_number_c',
                'value' => 'true',
            ),
        ),
		
		//approved_value
		array(
            'name' => 'ReadOnly',
            'params' => array(
                'target' => 'approved_value_c',
                'value' => 'true',
            ),
        ),
    ),
);