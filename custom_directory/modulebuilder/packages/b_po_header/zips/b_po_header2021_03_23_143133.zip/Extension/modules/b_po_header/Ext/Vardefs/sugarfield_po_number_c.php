<?php
 // created: 2020-04-16 12:28:26
$dictionary['b_po_header']['fields']['po_number_c']['labelValue']='PO Number';
$dictionary['b_po_header']['fields']['po_number_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['po_number_c']['enforced']='';
$dictionary['b_po_header']['fields']['po_number_c']['dependency']='';

 ?>