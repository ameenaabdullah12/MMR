<?php
$dictionary['b_po_header']['fields']['assigned_user_name']['help']='Please check database and approval limit before picking an approver';
