<?php 
$app_list_strings['default_dim_db_c_list'] = array (
  '' => '',
  'US' => 'AMER',
  'CHINA' => 'APAC',
  'BR' => 'Brazil',
  'UK' => 'EMEA',
  'IN' => 'India',
  'PTE' => 'Singapore',
  'SA' => 'South Africa',
  'Cubo' => 'Cubo',
);