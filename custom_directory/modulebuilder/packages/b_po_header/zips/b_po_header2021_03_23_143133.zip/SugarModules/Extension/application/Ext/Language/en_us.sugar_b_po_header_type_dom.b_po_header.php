<?php 
$app_list_strings['b_po_header_type_dom'] = array (
  '' => '',
  'Project' => 'Project',
  'Non Project' => 'Non Project',
);