<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Unposted Enquiry' => 'Unposted Enquiry',
  'Posted Proposal' => 'Posted Proposal',
  'Commissioned' => 'Commissioned',
  'Closed (Aborted)' => 'Closed - Zero Value',
  'Closed (Debriefed)' => 'Closed (Debriefed)',
  'Closed (Fully Invoiced)' => 'Closed (Fully Invoiced)',
  '' => '',
);