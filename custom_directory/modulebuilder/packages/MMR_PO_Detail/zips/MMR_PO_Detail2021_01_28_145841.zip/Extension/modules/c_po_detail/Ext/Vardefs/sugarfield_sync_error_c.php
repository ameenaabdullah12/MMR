<?php
 // created: 2020-12-14 13:20:17
$dictionary['c_po_detail']['fields']['sync_error_c']['labelValue']='Sync Error';
$dictionary['c_po_detail']['fields']['sync_error_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['c_po_detail']['fields']['sync_error_c']['enforced']='';
$dictionary['c_po_detail']['fields']['sync_error_c']['dependency']='';

 ?>