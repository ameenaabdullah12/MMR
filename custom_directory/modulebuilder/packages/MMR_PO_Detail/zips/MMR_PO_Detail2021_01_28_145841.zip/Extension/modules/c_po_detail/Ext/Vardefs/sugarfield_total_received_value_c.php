<?php
 // created: 2020-04-16 15:32:33
$dictionary['c_po_detail']['fields']['total_received_value_c']['labelValue']='Total Received Value';
$dictionary['c_po_detail']['fields']['total_received_value_c']['enforced']='';
$dictionary['c_po_detail']['fields']['total_received_value_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>