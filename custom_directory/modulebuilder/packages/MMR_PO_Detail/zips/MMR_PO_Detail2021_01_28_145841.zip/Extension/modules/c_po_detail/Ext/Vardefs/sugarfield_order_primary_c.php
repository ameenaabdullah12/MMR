<?php
 // created: 2019-12-18 14:43:12
$dictionary['c_po_detail']['fields']['order_primary_c']['labelValue']='Order Primary';
$dictionary['c_po_detail']['fields']['order_primary_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['c_po_detail']['fields']['order_primary_c']['enforced']='';
$dictionary['c_po_detail']['fields']['order_primary_c']['dependency']='';

 ?>