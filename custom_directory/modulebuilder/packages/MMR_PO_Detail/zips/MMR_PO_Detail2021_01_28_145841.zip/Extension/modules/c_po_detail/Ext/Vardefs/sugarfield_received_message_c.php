<?php
 // created: 2020-04-30 16:16:58
$dictionary['c_po_detail']['fields']['received_message_c']['labelValue']='Received Message';
$dictionary['c_po_detail']['fields']['received_message_c']['dependency']='greaterThan($total_received_value_c,$price_c)';

 ?>