<?php
 // created: 2019-12-18 14:37:54
$dictionary['c_po_detail']['fields']['currency_rate_c']['labelValue']='Currency Rate';
$dictionary['c_po_detail']['fields']['currency_rate_c']['enforced']='';
$dictionary['c_po_detail']['fields']['currency_rate_c']['dependency']='';

 ?>