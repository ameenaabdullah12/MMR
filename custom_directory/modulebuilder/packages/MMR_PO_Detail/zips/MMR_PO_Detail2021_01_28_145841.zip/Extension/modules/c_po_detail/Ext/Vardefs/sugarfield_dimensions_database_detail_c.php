<?php
 // created: 2019-12-18 14:40:50
$dictionary['c_po_detail']['fields']['dimensions_database_detail_c']['labelValue']='Dimensions Database Detail';
$dictionary['c_po_detail']['fields']['dimensions_database_detail_c']['dependency']='';
$dictionary['c_po_detail']['fields']['dimensions_database_detail_c']['calculated']=true;
$dictionary['c_po_detail']['fields']['dimensions_database_detail_c']['formula']='related($b_po_header_c_po_detail_1,"dimensions_database_c")'; 
$dictionary['c_po_detail']['fields']['dimensions_database_detail_c']['visibility_grid']='';

 ?>