<?php
 // created: 2020-12-17 10:53:42
$dictionary['c_po_detail']['fields']['price_c']['labelValue']='Price';
$dictionary['c_po_detail']['fields']['price_c']['enforced']='';
$dictionary['c_po_detail']['fields']['price_c']['dependency']='';
$dictionary['c_po_detail']['fields']['price_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>