<?php 
$app_list_strings['mmr_analysis'] = array (
  '' => '',
  40850 => 'Shared - Marketing',
  40851 => 'Shared - NOVA',
  40852 => 'Shared - Recruitment',
  40856 => 'Shared - Training',
  40853 => 'Investment - Marketing',
  40854 => 'Investment - NOVA',
  40878 => 'Investment - ONVC',
  40855 => 'Investment - Recruitment',
  40872 => 'MEIT - Self Funded Projects',
  40873 => 'MEIT - Case Studies',
  40874 => 'MEIT - Subscriptions',
  40875 => 'MEIT - Conferences',
  40876 => 'MEIT - Engagement',
  40877 => 'MEIT - Consultancy',
);