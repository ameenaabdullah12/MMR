<?php
 // created: 2020-04-16 20:47:48
$dictionary['b_po_header']['fields']['warning_project_c']['labelValue']='Project Warning';
$dictionary['b_po_header']['fields']['warning_project_c']['dependency']='and(equal($b_po_header_type,"Project"),equal($c_primary_key,""))';

 ?>