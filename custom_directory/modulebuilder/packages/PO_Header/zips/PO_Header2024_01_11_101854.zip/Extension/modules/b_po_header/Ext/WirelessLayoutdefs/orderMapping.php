<?php
// created: 2023-09-25 15:32:58
$extensionOrderMap = array (
  'custom/Extension/modules/b_po_header/Ext/WirelessLayoutdefs/b_po_header_notes_1_b_po_header.php' => 
  array (
    'md5' => 'd55c43f67a7bee2f3c5da7bae3256f7f',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/WirelessLayoutdefs/b_po_header_c_po_detail_1_b_po_header.php' => 
  array (
    'md5' => '31c4d0c7e26a146c243a9855ebf79515',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
);