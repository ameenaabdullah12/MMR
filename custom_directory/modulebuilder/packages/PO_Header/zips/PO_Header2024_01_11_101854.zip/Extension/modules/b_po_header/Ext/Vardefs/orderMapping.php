<?php
// created: 2023-11-29 12:46:14
$extensionOrderMap = array (
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_batch_ref_c.php' => 
  array (
    'md5' => 'f9fcc73f04a513ba7f071ec9565f9c77',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_date_c.php' => 
  array (
    'md5' => '8267aa0a0c0fba8cfacc852a86848b1e',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_warning_project_c.php' => 
  array (
    'md5' => '7f0aabc6653c8eacf2eb76f6862177f0',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_name.php' => 
  array (
    'md5' => '96661624642ee83937a6c44c996111bc',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/b_po_header_notes_1_b_po_header.php' => 
  array (
    'md5' => 'b279567f7d9fac54d5381b30c6260c8f',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_line_value_increase_c.php' => 
  array (
    'md5' => '41bc0dcf1bf385665348a3a55e24e98c',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/b_po_header_c_po_detail_1_b_po_header.php' => 
  array (
    'md5' => '3530a8d8a75cfa8f7d214f6c677f29d8',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_b_po_header_type.php' => 
  array (
    'md5' => '0ade89aee3e2c50c682fe751e27fff1b',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_number_c.php' => 
  array (
    'md5' => '2131bcdb935d0a62aae84fa90afaa568',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_created_by_id_c.php' => 
  array (
    'md5' => 'e1e74c4d56a464ecf76305800d4dde99',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/disable_dup_check.php' => 
  array (
    'md5' => '5cb9b4ba4dea460964a52fd6cede3475',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_assigned_to.php' => 
  array (
    'md5' => '6631cb74265df19a5bc35d21a3be8a23',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_amount.php' => 
  array (
    'md5' => 'c2ec613ae940ba77b1d60883c379c849',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_supplier_ref_c.php' => 
  array (
    'md5' => '80c45f2b40215c94a809d4237e51667d',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/Autoincrement.php' => 
  array (
    'md5' => '60be58b8f7a96e7fa7b691e8e4f395f7',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_auto_number.php' => 
  array (
    'md5' => '1b4fdb9ce60cfe2a0c195cd6669ec626',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_a_supplier_id_c.php' => 
  array (
    'md5' => 'ecf7b133fcee241dbd87dc25a48d171d',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_order_primary_c.php' => 
  array (
    'md5' => '6bcdc2303b7e213e1c43906d356fead5',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/opportunities_b_po_header_1_b_po_header.php' => 
  array (
    'md5' => '652244fd75fe1e3975f3dd3010f09571',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_date_approved_c.php' => 
  array (
    'md5' => '8263c65c2dfacf99e6cbc041991dc26a',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_warning_approver_c.php' => 
  array (
    'md5' => '7d133c0d3f282f62764838461d9f5ea9',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_total_received_value_c.php' => 
  array (
    'md5' => 'a7fd2451d9c3ddccee1ef8ffaede9d27',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_warning_c.php' => 
  array (
    'md5' => '5223767dae1310a98c66fc8d9db78588',
    'mtime' => 1596795406,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_approver_error_c.php' => 
  array (
    'md5' => 'c93000e41d18aa0178549ba42e2b4277',
    'mtime' => 1599816607,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_currency_name_c.php' => 
  array (
    'md5' => '2e7ce7d60bdd665f6d86659e28e4c897',
    'mtime' => 1599839078,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_assigned_to_user_calc_c.php' => 
  array (
    'md5' => '1d7852d5264abba6affd643d51f2d597',
    'mtime' => 1600724023,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_created_by_c.php' => 
  array (
    'md5' => '9186689020ea12ba123f22319965cc6f',
    'mtime' => 1602075278,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_project_c.php' => 
  array (
    'md5' => 'a828018ad86ebf7532a5519a3cb5dbb6',
    'mtime' => 1602196634,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_link_c.php' => 
  array (
    'md5' => 'c8250f855658b64509563330a0d6a2ea',
    'mtime' => 1602804017,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_url_text_c.php' => 
  array (
    'md5' => 'bd1717834aba73cb23ef180c65730f5c',
    'mtime' => 1602841652,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_send_approval_reminder_c.php' => 
  array (
    'md5' => 'aaa7e954bdd7d1107399eb8220649ae2',
    'mtime' => 1603116860,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_approved_c.php' => 
  array (
    'md5' => '2779d33f074b48af420d67fdd1e137c8',
    'mtime' => 1603927719,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_c_primary_key.php' => 
  array (
    'md5' => '9371deedcf52a28f64c938693bef357f',
    'mtime' => 1603927764,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_dimensions_database_c.php' => 
  array (
    'md5' => 'c0cc410370129cb3f79351580f472f73',
    'mtime' => 1603927787,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_request_approval_c.php' => 
  array (
    'md5' => 'f022ccdeaadd9f77d6a0d5cac1c28f3d',
    'mtime' => 1603927838,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_supplier_c.php' => 
  array (
    'md5' => 'b7a5712c340fe44d10d2d68eca9b8022',
    'mtime' => 1603927945,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_url_c.php' => 
  array (
    'md5' => 'f162c46aa094e3a7d5b803d21c99da80',
    'mtime' => 1604662425,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_invoiced_grand_total_c.php' => 
  array (
    'md5' => '921578c3a58c98a9a7f7078e6d0fefbd',
    'mtime' => 1604962911,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_to_be_invoiced_c.php' => 
  array (
    'md5' => '5eef1b8fd76770ac400890835e2506fe',
    'mtime' => 1604964751,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_status_c.php' => 
  array (
    'md5' => 'b1c55e1aecbd491758f3b0a5fea292d3',
    'mtime' => 1604965131,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_finance_check_c.php' => 
  array (
    'md5' => 'd4a1020e420622eeac949ab664a8df64',
    'mtime' => 1606949651,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_poh_status_c.php' => 
  array (
    'md5' => '8bd18ce7620e381813bc606ded9b4b8a',
    'mtime' => 1607000248,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_unapproved_balance_c.php' => 
  array (
    'md5' => '97c519eeea43fc496eeaaf54563b9b1f',
    'mtime' => 1608203290,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_approved_value_c.php' => 
  array (
    'md5' => 'a7f1e8dda86082009ff224919079c8fb',
    'mtime' => 1608203327,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_po_approval_link_c.php' => 
  array (
    'md5' => 'b07f64bdc6e7ff7f381530c0429bfa3b',
    'mtime' => 1608206025,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_grand_total_c.php' => 
  array (
    'md5' => 'abddd1fdd846d5c5f740a26ca241d052',
    'mtime' => 1608212303,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_supplier_db_c.php' => 
  array (
    'md5' => '960eedc8313953995f450d92825757bb',
    'mtime' => 1608251212,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/extra_grand_total_gbp_c.php' => 
  array (
    'md5' => 'ec01ecd6a09ea185de28cde2d42c48a9',
    'mtime' => 1611259425,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_grand_total_gbp_c.php' => 
  array (
    'md5' => '61bc580fd8103315b14839020cc1e847',
    'mtime' => 1611259425,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/extra_grand_total_c.php' => 
  array (
    'md5' => '78417b2e100beed031742c57013aa730',
    'mtime' => 1611259425,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/custom_assigned_user_name.php' => 
  array (
    'md5' => '81fb151d85e459bbfa28dd68278ed9c5',
    'mtime' => 1611862248,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_grand_total_orig_c.php' => 
  array (
    'md5' => '0deefdbc07269a9258528ed9e22d4aea',
    'mtime' => 1622745623,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/a_supplier_b_po_header_1_b_po_header.php' => 
  array (
    'md5' => 'c43d3ff2abee17cc68b5cb44b6445d39',
    'mtime' => 1622759918,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_allocation_c.php' => 
  array (
    'md5' => '93a7ac0b04b1c9a24cafcb5c0ccc1f6c',
    'mtime' => 1624882023,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_sync_error_c.php' => 
  array (
    'md5' => 'b527c5e7a5a8306aecf3cea6b87a63f1',
    'mtime' => 1669073900,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_amount_usdollar.php' => 
  array (
    'md5' => '78194f62bae0cb7c2508e0ffbb380813',
    'mtime' => 1695656085,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/sugarfield_approver_limit_c.php' => 
  array (
    'md5' => '220aae65541ac8ed3e13df546bbc101d',
    'mtime' => 1695812153,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Vardefs/full_text_search_admin.php' => 
  array (
    'md5' => 'f984218fd6fdfae8878a28893b17056d',
    'mtime' => 1701261973,
    'is_override' => false,
  ),
);