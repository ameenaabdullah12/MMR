<?php
 // created: 2023-11-29 12:46:13
$dictionary['b_po_header']['full_text_search']=true;
