<?php
// created: 2023-09-25 15:32:57
$extensionOrderMap = array (
  'custom/Extension/modules/b_po_header/Ext/Layoutdefs/b_po_header_notes_1_b_po_header.php' => 
  array (
    'md5' => '5414b970c3836106912b9eb3c673c167',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Layoutdefs/b_po_header_c_po_detail_1_b_po_header.php' => 
  array (
    'md5' => '2dc1eef90a1cb18fd6925c67a861900c',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Layoutdefs/_overrideb_po_header_subpanel_b_po_header_c_po_detail_1.php' => 
  array (
    'md5' => '7eda9ca251824e6d8d96a239829389bf',
    'mtime' => 1616668782,
    'is_override' => true,
  ),
);