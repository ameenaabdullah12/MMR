<?php
 // created: 2023-09-27 10:55:53
$dictionary['b_po_header']['fields']['approver_limit_c']['duplicate_merge_dom_value']=0;
$dictionary['b_po_header']['fields']['approver_limit_c']['labelValue']='Approver Limit';
$dictionary['b_po_header']['fields']['approver_limit_c']['calculated']='1';
$dictionary['b_po_header']['fields']['approver_limit_c']['formula']='related($assigned_user_link,"approval_level_gbp_c")';
$dictionary['b_po_header']['fields']['approver_limit_c']['enforced']='1';
$dictionary['b_po_header']['fields']['approver_limit_c']['dependency']='';
$dictionary['b_po_header']['fields']['approver_limit_c']['required_formula']='';
$dictionary['b_po_header']['fields']['approver_limit_c']['readonly_formula']='';

 ?>