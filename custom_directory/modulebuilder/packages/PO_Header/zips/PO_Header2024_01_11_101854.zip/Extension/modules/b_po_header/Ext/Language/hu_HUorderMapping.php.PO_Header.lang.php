<?php
// created: 2023-09-25 15:35:50
$extensionOrderMap = array (
  'custom/Extension/modules/b_po_header/Ext/Language/hu_HU.customopportunities_b_po_header_1.php' => 
  array (
    'md5' => '1ccc5a77b2bc1fd0c4b7096021bf9ae2',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Language/hu_HU.customb_po_header_c_po_detail_1.php' => 
  array (
    'md5' => '193a723b6f3ba2a52e233b35547b0a10',
    'mtime' => 1695656149,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Language/hu_HU.customb_po_header_notes_1.php' => 
  array (
    'md5' => 'af735a2eb3f737473bb182c6905ed642',
    'mtime' => 1695656149,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Language/hu_HU.customa_supplier_b_po_header_1.php' => 
  array (
    'md5' => 'd6b624f5b3e580bade764c446e44d3e9',
    'mtime' => 1695656149,
    'is_override' => false,
  ),
);