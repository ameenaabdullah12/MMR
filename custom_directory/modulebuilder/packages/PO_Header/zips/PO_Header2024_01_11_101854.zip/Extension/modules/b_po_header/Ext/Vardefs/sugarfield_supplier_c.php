<?php
 // created: 2020-10-28 23:32:25
$dictionary['b_po_header']['fields']['supplier_c']['labelValue']='Supplier';
$dictionary['b_po_header']['fields']['supplier_c']['dependency']='';

 ?>