<?php
$dictionary['b_po_header']['duplicate_check']['enabled'] = false;