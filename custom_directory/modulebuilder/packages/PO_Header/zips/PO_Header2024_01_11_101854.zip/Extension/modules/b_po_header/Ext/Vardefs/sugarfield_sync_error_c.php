<?php
 // created: 2022-11-21 23:38:20
$dictionary['b_po_header']['fields']['sync_error_c']['labelValue']='Sync Error';
$dictionary['b_po_header']['fields']['sync_error_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['sync_error_c']['enforced']='';
$dictionary['b_po_header']['fields']['sync_error_c']['dependency']='';

 ?>