<?php
 // created: 2021-06-03 18:40:23
$dictionary['b_po_header']['fields']['grand_total_orig_c']['labelValue']='Grand Total Orig';
$dictionary['b_po_header']['fields']['grand_total_orig_c']['enforced']='';
$dictionary['b_po_header']['fields']['grand_total_orig_c']['dependency']='';
$dictionary['b_po_header']['fields']['grand_total_orig_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>