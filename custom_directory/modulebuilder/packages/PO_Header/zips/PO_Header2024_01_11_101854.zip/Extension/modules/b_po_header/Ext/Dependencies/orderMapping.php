<?php
// created: 2023-09-25 15:32:57
$extensionOrderMap = array (
  'custom/Extension/modules/b_po_header/Ext/Dependencies/required_fields.php' => 
  array (
    'md5' => 'c5a158a4ac7ca7870a0195aee1d84ca2',
    'mtime' => 1596734731,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Dependencies/read_only_field.php' => 
  array (
    'md5' => '5f90629b3991182795811622c0d676ae',
    'mtime' => 1622759918,
    'is_override' => false,
  ),
  'custom/Extension/modules/b_po_header/Ext/Dependencies/allocation_field.php' => 
  array (
    'md5' => '5f246ecb7973903aac5f302a3586ba5b',
    'mtime' => 1623320730,
    'is_override' => false,
  ),
);