<?php
$dictionary['b_po_header']['fields']['grand_total_gbp_c']['group'] = 'grand_total';
$dictionary['b_po_header']['fields']['grand_total_gbp_c']['readonly'] = 'readonly';
$dictionary['b_po_header']['fields']['grand_total_gbp_c']['is_base_currency'] = true;
$dictionary['b_po_header']['fields']['grand_total_gbp_c']['disable_num_format'] = true;
 ?>