<?php
 // created: 2020-12-03 12:57:28
$dictionary['b_po_header']['fields']['poh_status_c']['labelValue']='POH Status';
$dictionary['b_po_header']['fields']['poh_status_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['poh_status_c']['enforced']='';
$dictionary['b_po_header']['fields']['poh_status_c']['dependency']='';

 ?>