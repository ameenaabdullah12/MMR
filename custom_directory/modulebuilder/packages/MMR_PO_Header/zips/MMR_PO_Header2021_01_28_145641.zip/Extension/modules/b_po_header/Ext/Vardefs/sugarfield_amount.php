<?php
 // created: 2020-03-26 13:18:41
$dictionary['b_po_header']['fields']['amount']['default']=0.0;
$dictionary['b_po_header']['fields']['amount']['audited']=false;
$dictionary['b_po_header']['fields']['amount']['massupdate']=false;
$dictionary['b_po_header']['fields']['amount']['help']='Amount';
$dictionary['b_po_header']['fields']['amount']['comments']='Unconverted amount of the sale';
$dictionary['b_po_header']['fields']['amount']['merge_filter']='disabled';
$dictionary['b_po_header']['fields']['amount']['unified_search']=false;
$dictionary['b_po_header']['fields']['amount']['calculated']=false;
$dictionary['b_po_header']['fields']['amount']['enable_range_search']=false;

 ?>