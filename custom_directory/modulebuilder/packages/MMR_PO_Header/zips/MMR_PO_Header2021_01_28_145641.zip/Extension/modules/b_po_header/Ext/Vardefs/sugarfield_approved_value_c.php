<?php
 // created: 2020-12-17 11:08:47
$dictionary['b_po_header']['fields']['approved_value_c']['labelValue']='Approved Value';
$dictionary['b_po_header']['fields']['approved_value_c']['enforced']='';
$dictionary['b_po_header']['fields']['approved_value_c']['dependency']='';
$dictionary['b_po_header']['fields']['approved_value_c']['related_fields']=array (
  0 => 'currency_id',
  1 => 'base_rate',
);

 ?>