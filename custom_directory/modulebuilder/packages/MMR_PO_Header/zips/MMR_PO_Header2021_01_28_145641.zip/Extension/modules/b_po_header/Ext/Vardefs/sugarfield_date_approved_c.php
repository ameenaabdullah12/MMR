<?php
 // created: 2019-12-18 13:51:37
$dictionary['b_po_header']['fields']['date_approved_c']['labelValue']='Date Approved';
$dictionary['b_po_header']['fields']['date_approved_c']['enforced']='';
$dictionary['b_po_header']['fields']['date_approved_c']['dependency']='';

 ?>