<?php
 // created: 2019-12-18 14:23:16
$dictionary['b_po_header']['fields']['order_primary_c']['labelValue']='Order Primary';
$dictionary['b_po_header']['fields']['order_primary_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['b_po_header']['fields']['order_primary_c']['enforced']='';
$dictionary['b_po_header']['fields']['order_primary_c']['dependency']='';

 ?>