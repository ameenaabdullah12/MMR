<?php
 // created: 2020-09-11 09:30:07
$dictionary['b_po_header']['fields']['approver_error_c']['labelValue']='Approver Error';
$dictionary['b_po_header']['fields']['approver_error_c']['dependency']='ifElse(related($assigned_user_link,"approver_c"),false,true)';

 ?>