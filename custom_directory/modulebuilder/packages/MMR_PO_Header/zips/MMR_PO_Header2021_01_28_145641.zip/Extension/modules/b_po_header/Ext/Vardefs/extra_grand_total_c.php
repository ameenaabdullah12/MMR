<?php
$dictionary['b_po_header']['fields']['grand_total_c']['currency_field'] = 'currency_id';
$dictionary['b_po_header']['fields']['grand_total_c']['group'] = 'grand_total';
//$dictionary['b_po_header']['fields']['grand_total_c']['convertToBase'] = true;

 ?>