<?php 
$app_list_strings['b_po_header_type_dom'] = array (
  'Existing Business' => 'Vykdomas verslas',
  'New Business' => 'Naujas verslas',
  '' => '',
);